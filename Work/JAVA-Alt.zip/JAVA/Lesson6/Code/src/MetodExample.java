public class MetodExample {
    public static void main(String[] args) {
        System.out.println("Perimetr of усефтпеу цшер ьуещв");
        int a = 100, b = 300;
        int per = perimeter(a,b);
        System.out.println(per);

    }
    // ---------------- metod ----------
    public static int perimeter( int x, int y){
        //int p = (x+y)*2;
        //return p;
        return  (x+y)*2;
    }

    // end ----------- metod -----------
}