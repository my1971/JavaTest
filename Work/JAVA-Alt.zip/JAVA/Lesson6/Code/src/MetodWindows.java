import javax.swing.*;
import java.awt.*;

public class MetodWindows {
    public static void main(String[] args) {
        int a = 100, b = 300;
        int per = newWindows(a,b);
        System.out.println(per);
    }
    public static int newWindows( int x, int y){
        JFrame frame = new JFrame();
        JLabel label = new JLabel("Hello!");
        label.setBounds(50,20,100,100);
        label.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700,600);
        frame.setLayout(null);
        frame.setVisible(true);

        //int p = (x+y)*2;
        //return p;
        return  (x+y)*2;
    }

    // end ----------- metod -----------
}