public class Main {
    public static void main(String[] args) {
     //   WindowList myWindow = new WindowList();
     //   JLabel label = new JLabel("Hello!");

       // System.out.println("Hello world!");
    }
}