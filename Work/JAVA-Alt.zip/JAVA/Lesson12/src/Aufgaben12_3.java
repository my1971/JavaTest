public class Aufgaben12_3 {
    public static void main(String[] args) {
        /*  Задача 3. Создайте массив из 20 случайных целых чисел в интервале от 10 до 20.
            Выведите массив на печать. Поменяйте местами первый и последний элементы массива
             и снова выведите массив на печать..
             (примечание: если при перемещении первого и последнего элементы совпадают, ввести модуль снова)*/
        System.out.println("=========================================================================================================================");
       int[] arr = new int[20];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * 10+10);
            if (i<11){
                System.out.print("In" + i + " - " + arr[i] + " | ");
            } else if (i == 11) {
                System.out.println("");
                System.out.print( "In" + i + " - " + arr[i] + " | ");
            }else {
                System.out.print( "In" + i + " - " + arr[i] + " | ");
            }

        }
        System.out.println("");
        System.out.println("=========================================================================================================================");
        int arr1 = arr[19];
        arr[19] = arr[0];
        arr[0] = arr1;
        for (int i = 0; i < arr.length; i++) {
            if (i<11){
                System.out.print("In" + i + " - " + arr[i] + " | ");
            } else if (i == 11) {
                System.out.println("");
                System.out.print( "In" + i + " - " + arr[i] + " | ");
            }else {
                System.out.print( "In" + i + " - " + arr[i] + " | ");
            }
        }
        System.out.println("");
        System.out.println("=========================================================================================================================");
    }
}
