public class Main {
    public static void main(String[] args) {
        int[] marks = {1, 2, 3, 4, 5, 6, 7 ,8 ,9};
        int a = marks.length;
        for (int i = 0; i < marks.length; i++) {
            System.out.print(i + ") " + marks[i] + "  |  ");
        }
        System.out.println(" ");
        System.out.println("======================");
        System.out.println(marks[marks.length - 1]);
      //  System.out.println(marks + "//////" + a);
    }
}