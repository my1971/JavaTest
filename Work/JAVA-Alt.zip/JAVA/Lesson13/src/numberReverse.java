import java.util.Scanner;

public class numberReverse {
    public static void main(String[] args) {
        //  Задача 3. Пользователь вводит натуральное число. Распечатайте это число в обратном порядке.
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input integer positive number: ");
        int n = scanner.nextInt();
        int digits = 0, nd = n;
        while (n > 0) {
            digits++;
            n = n / 10;
        }
        System.out.println(digits);
        int[] digit = new int[digits];
        for (int i = 0; i < digit.length; i++) {
            System.out.println(nd);
            digit[i] = nd % 10;
            nd /= 10;
        }
        printArray(digit);
        System.out.println(" ");
        printArrayRevers(digit);
    }

    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " | ");
        }
    }

    public static void printArrayRevers(int[] arr) {
        for (int i = arr.length - 1; 0 <= i; i--) {
            System.out.print(arr[i] + " | " );
        }

    }
}
