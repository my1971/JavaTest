import java.util.Scanner;

public class Exercise13_2 {
    public static void main(String[] args) {
        /*  Задача 2. Задайте массив из 10 случайных натуральных чисел в интервале от 1 до 100.
         Запросите у пользователя какое-то натуральное число. Определите, есть ли это число в массиве.
          Создайте и используйте метод searchInArray, который получает на вход массив и искомое число,
          а возвращает ответ - нашлось ли это число в массиве.
    double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
    double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
    int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
          */
        Scanner scanner = new Scanner(System.in);
       int[] num = new int[10];
       int a = 1, b = 100;
       for (int i = 0; i < num.length; i++) {
            num[i] = (int)(Math.random() * (b - a + 1) + a);
       }
       printArray(num);
       System.out.println(" ");
        System.out.print(" Input number: ");
       int n = scanner.nextInt();
       if (searchInArray(num, n)){
           System.out.println("We find the number!");
       }else{
           System.out.println("We didn`t find the number!");
       }
    }
    public static boolean searchInArray (int[] num, int n){
        for (int i = 0; i < num.length; i++) {
            if (n == num[i]){
                return true;
            }
        }
        return false;
    }
    public static void printArray(int[] arr){
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " | ");
        }
    }
}
