import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Обработка чисел");
        Scanner sc = new Scanner(System.in);
        // Считывание числа
        System.out.print("Введите целое число из 5 цифр :  ");
        int PerNummer = sc.nextInt(); // переменная переменная числа
        System.out.println("Вы ввели : " + PerNummer + " Число");
        String PerStr = Integer.toString(PerNummer);
        System.out.println("Колличество символов - " + PerStr.length());
        if (PerStr.length() == 5) {
            System.out.println("первая цифра - " + PerStr.charAt(0) + "; вторая цифра - " + PerStr.charAt(1) +
                    "; третья цифра - " + PerStr.charAt(2) + "; четвертая цифра - " +
                    PerStr.charAt(3) + "; пятая цифра - " + PerStr.charAt(4));
        }else {
            System.out.println("Неверное число");
        }
    }
}