import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {

        System.out.println("Математический расчет прямоугольника - периметр и площади");

        BufferedReader PerBR = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Введите ширину периметра: ");
        String PerNumSt1 = PerBR.readLine();
        System.out.println("Ширина равна : " + PerNumSt1 + " !");
        int PerNum1 = Integer.parseInt(PerNumSt1); //преобразовываем строку в число.

        System.out.println("Введите длину периметра: ");
        String PerNumSt2 = PerBR.readLine();
        System.out.println("Ширина равна : " + PerNumSt2 + " !");
        int PerNum2 = Integer.parseInt(PerNumSt2); //преобразовываем строку в число.

        System.out.println("Периметр равен : " + ((PerNum1+PerNum2)*2 ));
        System.out.println("Площадь равена : " + (PerNum1*PerNum2 ));

        System.out.println("Спасибо, что воспользовались нашим расчетом!");
    }
}