import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("- - - * * * Б О Т * * * - - -");
        Scanner sc = new Scanner(System.in);
        // Считывание числа
        System.out.print("что Вы планируете делать ? - ");
        String PerLine1 = sc.nextLine(); // переменная первый ответ
        System.out.print("Во сколько вы планируете " + PerLine1+"    ");
        String PerTime = sc.nextLine(); // переменная времени
        System.out.print("Вам будет удобно " + PerLine1+" в " + PerTime + "   ");
        String PerLine2 = sc.nextLine();// переменная времени
        System.out.print("Ваше решение " + PerLine2 + " в " + PerTime + "   " + PerLine1 + "  Оптимальное");
    }
}