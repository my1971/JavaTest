import java.util.Scanner;

public class Aufgabe22 {
    public static void main(String[] args) {
// Задача 2. Вводится положительное целое число, найдите сумму его цифр.
        Scanner sc = new Scanner(System.in);
        System.out.print("Input number: ");
        int perN = sc.nextInt();
        String perSt = Integer.toString(perN);
        int perL = perSt.length(), i=0, perSum = 0, perSymbol = 0;
        while (i <perL){
            perSymbol = perN % 10;
            perN = perN / 10;
            perSum = perSum + perSymbol;
            i++;
        } //end of while
        System.out.println("Sum number: " + perSt + " = " + perSum);
    }
}
