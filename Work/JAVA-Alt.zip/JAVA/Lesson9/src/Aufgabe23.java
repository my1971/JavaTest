import java.util.Scanner;

public class Aufgabe23 {
    public static void main(String[] args) {
// Задача 2. Вводится положительное целое число, найдите сумму его цифр( Используя charAt).
        Scanner sc = new Scanner(System.in);
        System.out.print("Input number: ");
        int perN = sc.nextInt();
        String perSt = Integer.toString(perN), perLine = "";
        int perL = perSt.length(), i=0, perSum = 0;
        while (i <perL){
            perSum = perSum + Integer.parseInt(String.valueOf(perSt.charAt(i))); //использование [charAt]
            perLine = (i <perL-1) ? perLine + perSt.charAt(i) + " + "
                    : perLine + perSt.charAt(i) +" = "; //использование тернарного оператора.
            i++;
        } //end of while
        System.out.println("Sum number: " + perLine + perSum);
   }
}
