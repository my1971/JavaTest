import java.util.Scanner;

public class Aufgabe1 {
    public static void main(String[] args) {
/* Задача 1. Программа получает на вход строку и число повторений этой строки
         Программа должна вывести эту строку нужное количество раз.*/
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text: ");
        String perS = sc.next();
        System.out.println("Input quantity of repetitions: ");
        int perQuantity = sc.nextInt();
        int n = 0;
        while (n < perQuantity){
            n++;
            System.out.println(n + ") " +  perS);
        } //end of while
    }
}
