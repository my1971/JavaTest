import java.util.Scanner;

public class Apples {
    public static void main(String[] args) {
    /*    Практикум: Задача 1. Задача о яблоках (начальное значение 30 яблок). Запустить цикл, в котором
    яблоки беруться из корзины до тех пор, пока они там есть. Последнее сообщение: "Яблоки кончились!".*/
        int perApples = 30;
        Scanner sc = new Scanner(System.in);
        int perTake;
        while (perApples > 0){
            System.out.println("Take apple from backet");
            perTake = sc.nextInt();
            perApples = perApples - perTake;
            System.out.println("In basket left = " + perApples + " apples.");
        } //end of while
        System.out.println("Apples are finished. Backet is emty");
    }
}