import java.util.Scanner;

public class Aufgabe4 {
    public static void main(String[] args) {
//Задача 4 (*)
//Вводится шестизначное число (номер автобусного билета). Определите, является ли этот билет "счастливым"
// (сумма первых трех цифр равна сумме трех последних цифр).
        Scanner sc = new Scanner(System.in);
        boolean perLog = true;
        int perN = 0;
        String perNtoString = "";
        while (perLog){
            System.out.print("Input 6-digit number: ");
            perN = sc.nextInt();
            perNtoString = Integer.toString(perN);
            if (perNtoString.length() == 6){break;} else {System.out.println("wrong number, input again");}
        }
        int perSum1 = metodSumNumber(perNtoString.substring(0, 3));
        int perSum2 = metodSumNumber(perNtoString.substring(3));
        if (perSum1 == perSum2){
            System.out.println("*********************************************");
            System.out.println("Congratulations !!! you have a winning ticket");
            System.out.println("*********************************************");
        }else {
            System.out.println("-------------------------------");
            System.out.println("You don't have a winning ticket");
            System.out.println("-------------------------------");
        }
    }
    public static int metodSumNumber(String perS) {
        int i = 0;
        int perSum = 0;
        while (i <3){
            perSum = perSum + Integer.parseInt (perS.substring(i,i+1));
            i++;
        } //end of while
    return perSum;
    }
}
