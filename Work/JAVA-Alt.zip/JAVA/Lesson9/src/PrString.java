import java.util.Scanner;

public class PrString {
    public static void main(String[] args) {
    //   Задача 5. Пользователь вводит строку. Распечатайте каждую букву строки на новой строчке.
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text - ");
        String perS = sc.next();
        int  l = perS.length();
        int pointer = 0;
        while (l > 0){
            System.out.println(perS.charAt(pointer));
            pointer++;
            l--;
        } //end of while
    }
}