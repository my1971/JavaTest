import javax.swing.*;

public class sum {
    public static void main(String[] args) {
        long n = 10000000;
        double i = 1;
        double sum = 0;
        // начинаем цикл
        while ( i < n ) {
            sum = sum + 1/i;
            System.out.println(i + "------" + sum + "-----//" + 1/i );
            i++;
        }
        System.out.println("Sum is: " + sum);
    }
}