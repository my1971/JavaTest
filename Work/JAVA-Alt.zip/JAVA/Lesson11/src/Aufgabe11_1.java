import java.util.Scanner;

public class Aufgabe11_1 {
    public static void main(String[] args) {
/* Задача 1. Составьте программу, которая вычисляет сумму чисел от 1 до 1/n. n вводится с клавиатуры.
Пример: n = 10 sum = 1 + 1/2 + 1/3 + ... + 1/10 Для вычисления sum используйте метод. */
        System.out.println("Methods Practice");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input number: ");
        long num = scanner.nextInt();
        long sumD = sumDenominator(num); // определяет общий знаменатель
        long sumN = sumNumerator(num, sumD);
        if (num == 1){
            System.out.println("The sum of fractions from 1 to 1 is: 1");
        } else if (num<1) {
            System.out.println("Invalid number");
        }else {
            System.out.printf("The sum of fractions from 1 to %d is: %d  + %d / %d"
                    , num,(sumN / sumD),(sumN % sumD), sumD);
        }
    }
    public static long sumDenominator(long n){
        long sum = 1, i = 1;
        while (n > i){
            if ((sum * 2) % (i + 1) == 0 & sum % (i+1) > 0) {sum *=2;
            } else if (sum % (i + 1) > 0) {sum = sum * (i+1);}
            i++;
        }
        return sum;
    }
    public static long sumNumerator(long n, long sumD) {
        long sum = sumD, i = 1;
        while (n > i) {
            sum = sum +(sumD / (i + 1));
            i++;
        }
        return sum;
    }
    //-----------End of Methods
}