public class NummerRaus {
    public static void main(String args[]) {
    String perN;
    perN = FuncNummerRaus("   ит 23ывыв980sdfok9dfфыв2а цац77ExampleExample33а ");
        System.out.println(perN);
    }
    public static String FuncNummerRaus(String par1)
    {
        String perAll = "", perLength = "", perStr = par1.replaceAll("\\s","");
        for (int i = 0; i < perStr.length(); i++){
            perLength = "" + perStr.charAt(i); //так глупо работает
            if (perLength.matches("[0-9]*")){perAll = perAll + perLength;}
         }
         return perAll;
    }
}
// String PerStr = Integer.toString(PerNummer); - пример перевода числа в строку