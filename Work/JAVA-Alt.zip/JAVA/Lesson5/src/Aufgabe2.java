import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class Aufgabe2 {
    public static void main(String[] args) throws IOException  {
        /*
        Написать программу для перевода градусов по Фаренгейту в шкалу Цельсия.
        Формула для перевода С = 5*(F-32)/9. Запросить у пользователя темпаратуру.
        */
        System.out.println("Расчет перевода градусов по Фаренгейту в шкалу Цельсия");

        BufferedReader PerBR = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Input a Fahrenheit temperature value: ");
        double perTemperatureF = Double.parseDouble(PerBR.readLine()); // параметр ввода Double
        System.out.printf(" Значение температуры по Фарегейту  =  " + perTemperatureF + "!" );
        System.out.println("------------------------------------------");
        System.out.printf("Celsius temperature value [С = 5*(F-32)/9] = %.2f !" , (5*(perTemperatureF-32)/9));
        System.out.println();
        System.out.printf("Celsius temperature value [С = (F-32)/1.8)] = %.2f !", (perTemperatureF - 32) / 1.8);
    }
}