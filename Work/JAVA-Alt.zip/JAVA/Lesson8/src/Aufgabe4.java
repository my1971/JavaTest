import javax.swing.*;
import java.util.Scanner;

public class Aufgabe4 {
    public static void main(String[] args) {
/*Задача 4 (*)
    В задаче про калькулятор все действия оформить методами. Если вводятся целые числа,
    то вычислять целочисленное частное и остаток от деления.*/
//        System.out.println("Calculator");
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Input 1st number");
//        int  a = sc.nextInt(); // считываем строку, которую написал пользователь
//        System.out.println("chose operation 1 - +, 2 - -, 3 - *, 4 - / ");
//        String perOperation = sc.next();
//        System.out.println("Input 2st number");
//        int  b = sc.nextInt(); // считываем строку, которую написал пользователь
//
        String perA = JOptionPane.showInputDialog("Input 1st number: ");
        String perOperation = JOptionPane.showInputDialog("chose operation 1 - +, 2 - -, 3 - *, 4 - / ");
        String perB = JOptionPane.showInputDialog("Input 2st number: ");
        int a = Integer.parseInt(perA);
        int b = Integer.parseInt(perB);
        switch (perOperation){
            case "+": {
                metodCalc("Sum is = " + (a+b));
                break;}
            case "-": {
                metodCalc("Subtraction is = " + (a-b));
                break;}
            case "*": {
                metodCalc("Multiplication is = " +(a*b));
                break;}
            case "/": {
                metodcalcDiv(a , b);
                break;}
            default: {
                System.out.println("Wrong input!");
                break;}
        }
    }
    public static int metodCalc(String perSt){
        JOptionPane.showMessageDialog(null, perSt );
        //System.out.println(perSt);
        return 0;
    }
    public static int metodcalcDiv(int per1 , int per2){
//        System.out.println("-------------------------------------------------");
//        System.out.println("Division is = " + (per1 / per2) + " with remainder = " + (per1 % per2));
//        System.out.println("-------------------------------------------------");
//        double perDiv = (double) per1/per2;
//        System.out.println("Division is = " + perDiv);
//        System.out.println("-------------------------------------------------");
        //String perSt = ("Division is = " + (per1 / per2) + " with remainder = " + (per1 % per2));
        JOptionPane.showMessageDialog(null, "Division is = " + (per1 / per2) + " with remainder = " + (per1 % per2)) ;
        return 0;
    }
}
