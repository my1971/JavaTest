import java.util.Scanner;

public class Сalculator {
    public static void main(String[] args) {

        System.out.println("Calculator");
/*Задача 2. Написать приложение-калькулятор для 4-х математических действий: +, -, *,
/ Использовать switch ... case на основе int, char*/

        Scanner sc = new Scanner(System.in);
        System.out.println("Input 1st number");
        double  a = sc.nextDouble(); // считываем строку, которую написал пользователь
        System.out.println("Input 2st number");
        double  b = sc.nextDouble(); // считываем строку, которую написал пользователь
        System.out.println("chose operation 1 - +, 2 - -, 3 - *, 4 - / ");
        String perOperation = sc.next();

        switch (perOperation){
            case "+": {
                System.out.println("Sum is = " + (a+b));
                break;
            }
            case "-": {
                System.out.println("Subtraction is " +(a-b));
                break;
            }
            case "*": {
                System.out.println("Multiplication is " +(a*b));
                break;
            }
            case "/": {
                double perDiv = (double) a/b;
                System.out.println("Division is " +perDiv);
                break;
            }
            default: {
                System.out.println("Wrong input!");
                break;
            }
        }
    }
}