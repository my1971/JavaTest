import java.util.Scanner;

public class Aufgabe3 {
    public static void main(String[] args) {

        System.out.println("Parsing IP-address");
/*Задача 3.
    Написать программу, в которую пользователь вводит имя и фамилию в одну строку через пробел.
    Программа должна выводить имя и фамилию на разных строках. Первая буква имени и фамилии больжны быть большими
    не зависимо от того, как их ввел пользователь, лишние пробелы должны быть удалены. (повторение методов String)*/
        Scanner sc = new Scanner(System.in);
        System.out.println("Imput firstname and lastname");
        String perName = sc.nextLine();
        perName = perName.trim(); // убираем пробелы
        int perSpaseIndex = perName.indexOf(' '); // нашли пробел 1-й позиции
        System.out.println("------------------------------------------------------------------------");
        System.out.println(metStrErsteSymbol(perName.substring(0, perSpaseIndex)));
        System.out.println(metStrErsteSymbol(perName.substring(perSpaseIndex+1)));
        System.out.println("------------------------------------------------------------------------");
    }
    public static String metStrErsteSymbol (String perStr){
        String perFirstLetter = perStr.substring(0,1);
        return (perFirstLetter.toUpperCase()) + perStr.substring(1);
    }
}
