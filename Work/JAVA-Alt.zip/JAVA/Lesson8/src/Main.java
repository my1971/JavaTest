import java.util.Scanner;

public class Main {
    // использование тернарного оператора.
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("haw old are you : ");
        int perAge = sc.nextInt();
        String securityAnswer = (perAge >= 18) ? "Все в порядке, проходите!" : "Этот фильм не подходит для вашего возраста!";
        System.out.println(securityAnswer);
    }
}