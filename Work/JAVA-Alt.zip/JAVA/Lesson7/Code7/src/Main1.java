import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {

        System.out.println("if - else practice");
    /*  Задание 2: Объявите две переменные целого типа a и b и присвойте им значения с клавиатуры.
        Создайте третью переменную sum и выведите ее значение на экран таким образом: Если a = b,
        то sum будет равно 2*(a+b) a если нет, то sum= a+b.     */
        Scanner sc = new Scanner(System.in);
        System.out.print("Input first number: ");
        int perA = sc.nextInt();
        System.out.print("Input second number: ");
        int perB = sc.nextInt();
        int perSum;
        if (perA == perB){
            perSum = 2*(perA + perB);
        } else {
            perSum = perA + perB;
        }
        System.out.println(perSum);
    }
}