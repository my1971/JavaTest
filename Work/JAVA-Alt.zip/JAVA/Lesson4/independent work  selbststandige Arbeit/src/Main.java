/*
import java.util.regex.Pattern;

class Main
{
    private static final Pattern LTRIM = Pattern.compile("^\\s+");
    private static final Pattern RTRIM = Pattern.compile("\\s+$");
    private static final String EMPTY_STRING = "";

    public static String ltrim(String str) {
        return LTRIM.matcher(str).replaceAll(EMPTY_STRING);
    }

    public static String rtrim(String str) {
        return RTRIM.matcher(str).replaceAll(EMPTY_STRING);
    }

    public static void main(String[] args)
    {
        String str = "  Hello World  ";

        System.out.println("Left Trim :" + ltrim(str) +":");
        System.out.println("Right Trim :" + rtrim(str) +":");
    }
}

 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String PerStr = "    Ghbbbbbc    ";
        PerStr = LTRIM.matcher(str)
    }
}