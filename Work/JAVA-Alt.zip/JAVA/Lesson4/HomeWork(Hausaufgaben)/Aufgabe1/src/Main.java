import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("Вычисление площади квадрата и объем куба со стороной  - 'а'");

        Scanner sc = new Scanner(System.in);
        // Считывание числа
        System.out.print("Введите значене стороны квадрата 'а' - ");
        double PerSite = sc.nextDouble(); // Значене стороны
        System.out.println("Вы ввели значение - " + PerSite);
        System.out.printf("площадь квадрата с введенным значением - (%.3f) = %.3f%n", PerSite, Math.pow(PerSite,2));
        System.out.printf("объем куба с введенным значением - (%.3f) = %.3f%n", PerSite, Math.pow(PerSite,3));
    }
}

/*
        double x1 = 16;
        double x2 = 2.25;
        double x3 = 0.25;
        double x4 = 88.675;

        System.out.printf("sqrt(%.3f) = %.3f%n", x1, Math.sqrt(x1));
        System.out.printf("sqrt(%.3f) = %.3f%n", x2, Math.sqrt(x2));
        System.out.printf("sqrt(%.3f) = %.3f%n", x3, Math.sqrt(x3));
        System.out.printf("sqrt(%.3f) = %.3f%n", x4, Math.sqrt(x4));
*/