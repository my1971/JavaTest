import java.util.Scanner;

public class JavaStringToIntExample {
    public static void main(String[] args) throws Exception  {

        // String s = "fred";  // используйте это, если вам нужно протестировать //исключение ниже
        String s = "cvbcvb100";

        try
        {
            // именно здесь String преобразуется в int
            int i = Integer.parseInt(s.trim());

            // выведем на экран значение после конвертации
            System.out.println("int i = " + i + "das gut");
        }
        catch (NumberFormatException nfe)
        {
            System.out.println("NumberFormatException: " + nfe.getMessage());
        }
    }

}