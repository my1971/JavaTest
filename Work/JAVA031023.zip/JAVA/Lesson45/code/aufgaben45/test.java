package aufgaben45;

public class test {
    public static void main(String[] args) {
        int a;
        long l;
        a = Integer.MAX_VALUE;
        l = Long.MAX_VALUE;
        System.out.println(a);
        System.out.println(l);

    }
}
