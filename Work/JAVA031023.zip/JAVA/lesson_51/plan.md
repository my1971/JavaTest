# Lesson plan No. 51 dated 09/15/2023:

1. Tree data structure in Programming

2. Set practice, a task analysis showing the advantage of sets over sheets

_________________________________________________

# План урока № 51 от 15.09.2023:

1. Структура данных Tree в программировании

2. Практика Set, разбор задачи, показывающей преимущество множеств перед листами

