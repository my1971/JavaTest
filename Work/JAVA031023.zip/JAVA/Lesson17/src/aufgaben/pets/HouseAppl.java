package aufgaben.pets;

public class HouseAppl {
    public static void main(String[] args) {
        Dog dog1 = new Dog();
        Dog dog2 = new Dog();
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        Cat cat3 = new Cat();
        dog1.display("dog", 5,"on the street","Sharik","pooch",2);
        dog2.display("dog", 8,"at home","Rex","buldog",3);
        cat1.display("cat", 2,"on the street","Murka","mongrel",3);
        cat2.display("cat", 4,"at home","Matroskin","Siamskiy",3);
        cat3.display("cat", 3,"at home","Pushok","Persian cat",3);
        System.out.println("====================================================================================");

    }
}
