package aufgaben.dictionary;

import aufgaben.pets.Cat;
import aufgaben.pets.Dog;

public class BookAppl {
    public static void main(String[] args) {
        Dictionary word = new Dictionary();
        word.display("победа", "victory");
        word.display("март", "March");
        word.display("цветок", "flower");
        word.display("дорога", "road");
    }
}
