package inheritance_practice.computer;

public class CompAppl {
    public static void main(String[] args) {
        Computer comp1 = new Computer("i5",  16, 512, "Compaq");
        Laptop l1 = new Laptop("i5-1", 32,1024, "HP",13, 2,"Black");
        comp1.display(true);
        l1.display();
    }
}
