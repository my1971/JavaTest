package inheritance_practice.beverage;

public class BrotAppl {
    public static void main(String[] args) {
        Beverage brot1 = new Beverage();
        brot1.tobay("Cola", "Bottle" , 5);
        brot1.displayStock();
        Beverage brot2 = new Beverage();
        brot2.tobay("Brot","Stuck",3);
        brot2.displayStock();

        Brot brot3 = new Brot();
         brot3.toBuy("BrotBrot", "Stucking",5,"typing");
         brot3.displayStock();

    }
}
