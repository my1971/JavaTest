import java.io.*;
import java.util.Scanner;
// код с проверкой на ошибочный ввод числа (текст, ноль недопустимы)
public class Aufgabe1 {
    public static void main(String[] args) throws Exception  {
/*      Запросить у пользователя три стороны треугольника. Проверить выполнимость неравенства треугольника
        - любая из сторон должна быть меньше суммы двух других. Сообщить результат пользователю
        - существует или нет треугольник с введенными сторонами. */
        System.out.println("triangle");
        int perSite1 = metodNumberCheck("Input the first  side of the triangle: ");
        int perSite2 = metodNumberCheck("Input the second side of the triangle: ");
        int perSite3 = metodNumberCheck("Input the third  side of the triangle: ");
        if (perSite1 < perSite2 + perSite3 & perSite2 < perSite1 + perSite3 & perSite3 < perSite1 + perSite2){
            System.out.println("These value of the sides are correct.!!!");
            System.out.println("*******************************************");
        } else {
            System.out.println("the value of the sides cannot be this!!!");
            System.out.println("That is impossible!!!");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        }
    }
    public static int metodNumberCheck(String perLine) throws Exception{
        boolean perBool = true;
        Scanner sc = new Scanner(System.in);
        int perNum = 0;
        String perStr = "";
        while (perBool == true){
            System.out.print(perLine);
            try {
                perStr = sc.nextLine();
                perNum = Integer.parseInt(perStr.trim());
                if (perNum > 0){
                    System.out.println("-------------------------------------------");
                    return perNum;
                } else {
                    System.out.println("The number cannot be: [" + perStr + "] is not correct");
                }
            } catch (NumberFormatException nfe){
                System.out.println("The number: [" + perStr + "] is not correct");
            }
        }
        return 0;
    }
}

