import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        System.out.println("if - else practice");
        //  Задача 4. Решение квадратного уравнения по коэффициентам квадратного трехчлена а, b и с.
        Scanner sc = new Scanner(System.in);
        System.out.print("Input first number: ");
        int perA = sc.nextInt();
        System.out.print("Input second number: ");
        int perB = sc.nextInt();
        System.out.print("Input dritte number: ");
        int perC = sc.nextInt();
        int perD = perB * perB - 4 * perA * perC;
        if (perD < 0){
            System.out.println("There are no roots D ist negative " + perD);
        }else if (perD == 0){
            double perX = - perB / (2 * perA);
            System.out.println("X = " + perX);
        }else {
            double perX1 = - perB + (Math.sqrt(perD)) / (2 * perA);
            double perX2 = - perB - (Math.sqrt(perD)) / (2 * perA);
            System.out.println("X1 = " + perX1);
            System.out.println("X2 = " + perX2);
        }

    }
}