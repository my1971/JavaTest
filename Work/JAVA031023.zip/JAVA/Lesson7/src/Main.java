import java.awt.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("if - else practice");
    /*  1: Проверка четное или нечетное, положительное или отрицательное введенное пользователем число.
        Проверка возраста собеседника, возраст запросить у пользователя. Если пользователю нет 18 лет,
        то сообщить "Вам надо получить общее среднее образование", иначе - спросить дату дня рождения и
        вывести ее на экран.
     */
        Scanner sc = new Scanner(System.in);
        System.out.print("Input numer, pls: ");
        int number = sc.nextInt();
        if (number % 2 == 0){
            System.out.println("This number - "+ number + " is event.");
        } else {
            System.out.println("This number - "+ number + " is odd.");
        }
        if (number > 0){ // check positive or negative
            System.out.println("This number - "+ number + " is positive.");
        } else {
            System.out.println("This number - "+ number + " is negative.");
        }
        if (number > 0 & number % 2 == 0) { // check positive and event
            System.out.println("This number - "+ number + " is positive and event");
        }
        System.out.print("haw old are Yuo : ");
        int perAge = sc.nextInt();
        if (perAge > 17){ // check positive or negative
            System.out.println("You have to  finish school!");
        } else {
            System.out.println("What ist your of birthday?");
            String perDayOfBirth = sc.next();
            System.out.println("Your day of birthday is : " + perDayOfBirth);
        }
    }
}