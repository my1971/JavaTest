import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {

        System.out.println("if - else practice");
    /*  Задача 3. Написать метод, выводящий на экран максимальное из трех целых чисел.
        Числа должны вводится с клавиатуры..     */
        Scanner sc = new Scanner(System.in);
        System.out.print("Input first number: ");
        int perNum1 = sc.nextInt();
        System.out.print("Input second number: ");
        int perNum2 = sc.nextInt();
        System.out.print("Input dritte number: ");
        int perNum3 = sc.nextInt();
//        int perMax = perNum1;
//
//        if (perNum2>perMax){
//            perMax = perNum2;
//        }
//        if (perNum3 > perMax){Main2
//            perMax = perNum3;
//        }
        int perMax = maxABC(perNum1, perNum2, perNum3);
        System.out.println("Max from " + perNum1 + " ' " +perNum2 + " ' "+ perNum3 + " ist " + perMax);
        System.out.println(perMax);
    }

    public static int maxABC (int x, int y, int z){
        int max = x;
        if (y == max){
            max = y;
        } else {
            max = z;
        }
        return max;
    }
}