import java.util.Scanner;

public class SumOfAngles {
    public static void main(String[] args) {

        System.out.println("Задачи на вычисления");
// сумма углов треугольника наравна 180 градусов

        Scanner sc = new Scanner(System.in);
        // Считывание числа
        System.out.print("Input 1st angle :  ");
        int a1 = sc.nextInt();
        System.out.print("Input 2st angle :  ");
        int a2 = sc.nextInt();
        int a3 = 180 - a1 - a2;

        System.out.println("3 rd angle in triangle is - " + a3);

    }
}