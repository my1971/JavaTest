import java.util.Scanner;

public class Calculate {
    public static void main(String[] args) {

        System.out.println("Calculate length and ares of circle");

        Scanner sc = new Scanner(System.in);
        System.out.print("Input radius of circle :  ");
        int perRadius = sc.nextInt();
        double i = 2 * Math.PI * perRadius;
        double s = Math.PI * perRadius * perRadius;
        float s1 = (float)( Math.PI * Math.pow(perRadius, 2));

        System.out.println("Input 2st angle :  " + i);
        System.out.println("Input 2st angle :  " + s);
        System.out.println("Input 2st angle :  " + s1);

    }
}