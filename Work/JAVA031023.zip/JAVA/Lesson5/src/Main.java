import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Написать программу для вычисления средней стомости поездки по транспортному проездному.
//        Попросить пользователя ввести стоимость проездного на месяц
//        и количество рабочих дней в месяце. Считая, что в рабочий день в среднем две поездки,
//        и 1.5 поездки в выходной, посчитать и округлить общее число поездок в месяц
//        и посчитать среднюю стоимость одной поездки по проездному.
        System.out.println("Вычисление средней стоимости поездки");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input cost of City ticket  : ");
        double perPriceMonatKarte  = sc.nextDouble();
        System.out.println("input number of working : ");
        int perWorkingDays = sc.nextInt();

        int perTrip = perWorkingDays * 2;
        int perHolidays = 31 - perWorkingDays;
        int perHolidaysTrip = (int)Math.round(1.5 * perHolidays);
        int perTrips = 0;
        perTrips = perTrip + perHolidaysTrip;
        System.out.println("Number of trips in May = " + perTrips);
        double perAriaTripsPrice = perPriceMonatKarte / perTrips;
        System.out.println("Average price = " + perAriaTripsPrice);
        System.out.printf("Average price = %.2f" , perAriaTripsPrice);
    }
}