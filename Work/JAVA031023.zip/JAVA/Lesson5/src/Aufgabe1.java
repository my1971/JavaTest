import java.io.*;
import java.util.Scanner;

public class Aufgabe1 {
    public static void main(String[] args) throws IOException  {
       // Вычислите гипотенузу по двум катетам. Длину катетов запросите у пользователя.

        System.out.println("Расчет гипотенузы по двум катетам.");

        BufferedReader PerBR = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Введите  длину  первого катета : ");
        int perKat1 = Integer.parseInt(PerBR.readLine());
        System.out.println("Длина  первого катета  = " + perKat1 + " !");
        System.out.print("Введите  длину  второго  катета : ");
        int perKat2 = Integer.parseInt(PerBR.readLine());
        System.out.println("Длина  второго катета  = " + perKat2 + " !");
        System.out.println("-----------------------------------------------------");
        System.out.println("Гипотенуза = " + Math.sqrt((Math.pow(perKat1,2) + Math.pow(perKat2,2))));
       // System.out.printf("объем куба с введенным значением - (%.3f) = %.3f%n", PerSite, Math.pow(PerSite,3));
    }
}