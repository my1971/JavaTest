import java.util.Scanner;

public class Aufgabe3 {
    public static void main(String[] args) {
//        Вычислите площадь треугольника по формуле Герона: p = (a + b + с)/2; S = sqrt(p*(p-a)(p-b)(p-c));
        System.out.println("Вычисление площадь треугольника по формуле Герона: p = (a + b + с)/2");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the side A of the triangle : ");
        double perA = sc.nextInt();
        System.out.print("Input the side B of the triangle : ");
        double perB = sc.nextInt();
        System.out.print("Input the side C of the triangle : ");
        double perC = sc.nextInt();
        System.out.println("---------------------------");
        double perP = (perA + perB + perC)/2;
        System.out.println("[p = (a + b + с)/2]= " + perP);
        System.out.println("площадь треугольника по формуле Герона  = " +
                Math.sqrt(perP * (perP-perA) * (perP-perB) * (perP-perC)));
    }
}