import java.util.Scanner;

public class Aufgabe4 {
    public static void main(String[] args) {
//        Напишите приложение для решения квадратного уравнения, корни уравнения ищутся по коэффициентам a, b и с.
//        Коэффициенты запросить у пользователя.
        System.out.println("приложение для решения квадратного уравнения");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the side A of the triangle : ");
        int perA = sc.nextInt();
        System.out.print("Input the side B of the triangle : ");
        int perB = sc.nextInt();
        System.out.print("Input the side C of the triangle : ");
        int perC = sc.nextInt();
        System.out.println("---------------------------");
        System.out.println("quadratic equation is obtained - [" + perA + "x*x+" + perB + "x+" + perC + "=0]");
        System.out.println("---------------------------");
        double perD = Math.pow(perB,2) -  (4*perA * perC);
        System.out.println("D = b*b - 4ac = " + perD );
        if (perD < 0) {
            System.out.println("no solutions - [ D < 0 ]");
        } else if (perD == 0) {
            double perX = (-perB / (2 * perA));
            System.out.println("Value [ x ] = " + perX);
            int perSol = (int) ((perA * Math.pow(perX,2)) + (perB * perX) + perC);
            System.out.println("solution verification " + perSol);
        } else {
            double perX1 = (-perB + Math.sqrt(perD)) / (2 * perA);
            double perX2 = (-perB - Math.sqrt(perD)) / (2 * perA);
            System.out.println("Value [ x1 ] =" + perX1);
            System.out.println("Value [ x2 ] =" + perX2);
            int perSol1 = (int) ((perA * Math.pow(perX1,2)) + (perB * perX1) + perC);
            int perSol2 = (int) ((perA * Math.pow(perX2,2)) + (perB * perX2) + perC);
            System.out.println("solution verification X1 - " + perSol1);
            System.out.println("solution verification X2 - " + perSol2);
        }
    }
}

