package practice.city_bus;

import practice.city_bus.model.Bus;

import java.util.ArrayList;
import java.util.List;

public class CityBusAppl {
    public static void main(String[] args) {
        //Создадим список городских маршрутов
        // вывести на печать в отсортированном ввиде
        // Подсчитать общее количество перевозимых за день посажиров
        List<Bus> cityBuses = new ArrayList<Bus>();

        cityBuses.add(new Bus("Scania", "1000AG", "100", 90));
        cityBuses.add(new Bus("Man", "2000AG", "100A", 100));
        cityBuses.add(new Bus("Mercedes", "5000AG", "25", 105));
        cityBuses.add(new Bus("Ikarus", "3000AG", "B", 80));
        System.out.println("Quantity = " + cityBuses.size());
//        cityBuses.clear();
//        System.out.println(cityBuses.size());
//        System.out.println("Index = " + cityBuses.indexOf(new Bus("Man","2000AG","100A", 100)));
//        System.out.println("Index = " + cityBuses.indexOf(new Bus("Ikarus","3000AG","B", 80)));
        Bus bus1 = new Bus("ManN", "2000AG1", "100A", 100);
        cityBuses.add(bus1);
        System.out.println(cityBuses.indexOf(bus1));
        System.out.println("==============================");
//        for (int i = 0; i < cityBuses.size(); i++) {
//            System.out.println(cityBuses.get(i));
//        }
        for (Bus bus : cityBuses) {
            System.out.println(bus);
        }
        System.out.println("-=-=-=-=-=-=-=-=-==--=-==-=-");
        cityBuses.sort((Bus::compareTo));
        for (Bus bus : cityBuses) {
            System.out.println(bus);
        }
        System.out.println("///////////////////////////////");
        int totalCaopacity = 0;
        for (Bus bus : cityBuses) {
            totalCaopacity += bus.getCapacity();
        }
        System.out.println("Totel Capacity = " + totalCaopacity);

        Bus busToEdit = cityBuses.get(4);
        System.out.println(busToEdit);
        busToEdit.setModel("Ykarus");
        System.out.println("=====55555====");
        for (Bus bus : cityBuses) {
            System.out.println(bus);
        }
    }
}

