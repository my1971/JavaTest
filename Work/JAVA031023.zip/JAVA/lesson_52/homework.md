## Задача 1.
Работа с Map
Реализовать Map<String, LocalDate> birthdays;
где, в качестве ключа (key) будет выступать имя человека, 
а в качестеве значения (value) экземпляр класса LocalDate
(самостоятельное изучение! https://www.examclouds.com/ru/java/java-core-russian/klass-localdate)
Заполнить не менее 5 пар. 

практика с классами, имплементирующими Map, разбор методов:
- put()
- get()
- remove()
- containsKey()
- containsValue()
- keySet()
- remove()
практика перебора значений


