package student_code;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HomeClass1 {

    public static void main(String[] args) {
        // LocalDate newDate = LocalDate.of(2001,12,23);
        Map<String, LocalDate> birthdays = new HashMap<>();
//        Date per1 = 1971;
//        String per2 = "12";
//        String per3 = "23";
//
//        birthdays.put("Vasya", LocalDate.of(per1, per2, per3));
        birthdays.put("Fedya", LocalDate.of(1984, 10, 3));
        birthdays.put("Gena", LocalDate.of(1975, 5, 2));
        birthdays.put("Elene", LocalDate.of(1995, 6, 3));
        birthdays.put("Masha", LocalDate.of(2001, 8, 9));
        birthdays.put("Irina", LocalDate.of(2003, 5, 1));
        birthdays.put("Mitya", LocalDate.of(1998, 3, 8));
        birthdays.entrySet().forEach(i -> System.out.println(i));
        System.out.println("************** GET ******************");
        System.out.println("Vasyas birsday is " + birthdays.get("Vasya"));
        System.out.println("************** REMOVE 'Gena' ******************");
        birthdays.remove("Gena");
        birthdays.entrySet().forEach(i -> System.out.println(i));
        System.out.println("************** containsKey und containsValue ******************");
        System.out.println("Gena is " + birthdays.containsKey("Gena"));
        System.out.println("Irina is " + birthdays.containsKey("Irina"));
        System.out.println("Vasya is " + birthdays.containsValue(LocalDate.of(1971, 12, 23)));
        System.out.println("Irina is " + birthdays.containsValue(LocalDate.of(2023, 12, 23)));
        System.out.println("************** keySet ******************");
        System.out.println(birthdays.keySet());
    }
}
