package student_code;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class StudentCode {
    public static void main(String[] args) {
        Map <Integer, String> map = new HashMap<>();
        map.put(34, "Ilyas");
        map.put(20, "Alexandru");
        map.put(-3, "Dmitriy");
        map.put(40, "Elena");
        map.put(5, "Alla");
        map.put(60, "Natalia");
        map.put(7, "Radu");
        map.put(-80, "Sandor");
        map.put(9, "Sergey");
        map.put(0, "Vyacheslav");
        map.put(null, "AIT");
        map.put(null, "SCHOOL");
        if(!map.containsKey(34)) map.put(34,"Ilyas M");
        map.remove(0, "Vyacheslav");

        Map anotheMap = new HashMap<>();
        anotheMap.putAll(map);
        for (Object o : anotheMap.keySet()) {
            System.out.printf("Key : %d; value : %s\n", o, map.get(o));
        }
//        for ( Integer i : Map.keySet()) {
//            System.out.printf("Key %d : value %s\n", i, map.get(i));
//        }
        System.out.println(map.get(6000));

        System.out.println(map.size());
        System.out.println(map.keySet());
        System.out.println(map.entrySet());
        System.out.println(map.values());
        System.out.println("++++++++++++++++++++++");
        map.entrySet().forEach(i -> System.out.println(i));
    }
}
