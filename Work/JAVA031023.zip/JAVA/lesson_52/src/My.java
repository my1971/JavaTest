import java.util.ArrayList;
import java.util.Set;

public class My {

    public static void main(String[] args) {

//        ArrayList<Set<Integer>> listOfSet = new ArrayList<>();
//        Set<Integer> integerSet;
//        listOfSet.add(integerSet);

//        System.out.println(listOfSet.contains(integerSet));

        Set<Integer> integerSet  = Set.of(1, 2, 3);

        ArrayList<Set<Integer>> listOfSet = new ArrayList<>();

        listOfSet.add(integerSet);
        System.out.println(listOfSet.size());
//        for (int i = 0; i < listOfSet.size(); i++) {
//
//        }
//        System.out.println();
//        System.out.println(listOfSet.contains(integerSet));
    }
}
