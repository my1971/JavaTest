# Lesson plan No. 52 dated 09/18/2023:

1. Map data structure in Java

2. analysis of the Map application using the example of the FibonacciExample, MockService classes

_________________________________________________

# План урока № 51 от 18.09.2023:

1. Структура данных Map в Java

2. разбор применения Map на примере классов FibonacciExample, MockService

