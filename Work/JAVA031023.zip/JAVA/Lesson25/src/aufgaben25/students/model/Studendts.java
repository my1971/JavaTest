/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 //arr[i] = (int)(Math.random() * (b - a + 1) + a);
 **********************************************************************************************************************/

package aufgaben25.students.model;

public class Studendts {
/*  Task 3. There is a list of students with their last names (set inside the program).
            Distribute students into 2 approximately equal groups (+/- 1 person) randomly.
            -   first write in words an algorithm of how this will be done;
            -   implement the algorithm in code;
            -   when implementing, use the method(s);
            -   create tests.
Задача 3.   Имеется список студентов с их фамилиями (задать внутри программы).
            Распределить студентов на 2 примерно равных группы (+/- 1 человек) случайным образом.
            -   сначала написать словами алгоритм того, как это будет делаться;
            -   реализовать алгоритм в коде;
            -   при реализации использовать метод(ы);
            -   создать тесты. */
    String firstName, lastName;
    Integer group;
    public Studendts[] studendts;
    public Studendts(int capacity) {
        studendts = new Studendts[capacity];
        studendts[0] = new Studendts("Ivanov" ,"Vasya",0);
        studendts[1] = new Studendts("Petrov" ,"Vasya",0);
        studendts[2] = new Studendts("Schmidt" ,"Lisa",0);
        studendts[3] = new Studendts("Kvan" ,"Sergey",0);
        studendts[4] = new Studendts("Bass" ,"Roma",0);
        studendts[5] = new Studendts("Kron" ,"Vasil",0);
        studendts[6] = new Studendts("Mallen" ,"Milla",0);
        studendts[7] = new Studendts("Kammen" ,"Malu",0);
        studendts[8] = new Studendts("Lee" ,"Oleg",0);
        studendts[9] = new Studendts("Senken" ,"Russlan",0);
        studendts[10] = new Studendts("Kuleev" ,"David",0);
    }
    public void display(Studendts studendts){
        for (int i = 0; i < studendts.studendts.length; i++) {
            System.out.println((studendts.studendts[i]));
        }
    }
    public String groups(){
        Integer in = 0, group1 = studendts.length/2;
        Integer group2 = studendts.length - group1;
        String r = ("Quantity students in Group 1 = " + group1 + " | Quantity students in Group 2 = " + group2);
        for (int i = 0; i < studendts.length; i++) {
            if (in == 0) {in = (int)(Math.random()*2+1);}
            studendts[i].setGroup(in);
            if (in == 1){group1--;}else {group2--;}
            if (group1 == 0){in = 2;} else if (group2 == 0) {in = 1;}else {in = 0;}
        }
        return r;
    }
    public String groups(Studendts studendts){
        Integer in = 0, group1 = studendts.studendts.length/2;
        Integer group2 = studendts.studendts.length - group1;
        String r = ("Quantity students in Group 1 = " + group1 + " | Quantity students in Group 2 = " + group2);
        for (int i = 0; i < studendts.studendts.length; i++) {
            if (in == 0) {in = (int)(Math.random()*2+1);}
            studendts.studendts[i].setGroup(in);
            if (in == 1){group1--;}else {group2--;}
            if (group1 == 0){in = 2;} else if (group2 == 0) {in = 1;}else {in = 0;}
        }
        return r;
    }
    public Studendts(String firstName, String lastName, Integer group) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.group = group;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Integer getGroup() {
        return group;
    }
    public void setGroup(Integer group) {
        this.group = group;
    }
    @Override
    public String toString() {
        return "Students : ( " +
                "FirstName = '" + firstName + '\'' +
                ", LastName = '" + lastName + '\'' +
                ", in group = " + group +
                ')';
    }
}



