package aufgaben25.students;

import aufgaben25.students.model.Studendts;

public class StudentsAppl {
        public static void main(String[] args) {
            Studendts arrStud = new Studendts(11);
            System.out.println(arrStud.groups(arrStud));
            System.out.println("-------------------------------------------------------------------------------");
            arrStud.display(arrStud);
    }
}
