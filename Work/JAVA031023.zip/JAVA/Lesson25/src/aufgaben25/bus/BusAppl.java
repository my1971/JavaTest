package aufgaben25.bus;

import aufgaben25.bus.metod.Bus;

public class BusAppl {
    public static void main(String[] args) {

        // Bus[] bus = new Bus[10];
        Bus bus = new Bus(15, 100, 50, 30);
        System.out.println(bus.toString());
        System.out.println("Go with speed - " + bus.go(30));
        System.out.println(bus.toString());
        System.out.println("Go with speed - " + bus.stop());
        System.out.println(bus.toString());
        System.out.println("Go speed up to - " + bus.speedUp(50));
        System.out.println(bus.toString());
        System.out.println("Go speed down to - " + bus.speedDown(20));
        System.out.println(bus.toString());

    }


}
