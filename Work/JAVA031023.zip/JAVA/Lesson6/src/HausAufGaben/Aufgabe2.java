import java.util.Scanner;

public class Aufgabe2 {
    public static void main(String[] args) {
 /*     Запросить у пользователя длину радиуса окружности.
        Написать метод, который находит площадь круга для введенного радиуса (S = π × r2).
        Вычислить площадь круга, вызвав написанный метод.*/
        System.out.println("приложение для нахождения площади круга");
        System.out.println("-----------------------------------------");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the side Radius : ");
        int perR = sc.nextInt();
        System.out.println("---------------------------");
        System.out.printf("Te area of the circle is - [ %.2f ]" , (Math.PI * 2 * perR));
        System.out.println("");
        System.out.println("---------------------------");
    }
}

