import java.util.Scanner;

public class Aufgabe4 {
    public static void main(String[] args) {
 /*     Напишите программу, которая читает строку от пользователя, определяет левый индекс и правый
        индекс (концы строки) и выводит получившуюся в результате substring с левым и правым индексом.*/
        System.out.println("приложение для нахождения площади круга");
        System.out.println("-----------------------------------------");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input the line : ");
        String perLine = sc.nextLine();
        System.out.println("---------------------------");
        System.out.println( perLine.substring(0, perLine.length()));
        System.out.println("---------------------------");
    }
}

