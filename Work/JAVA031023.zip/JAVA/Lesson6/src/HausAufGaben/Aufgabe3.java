public class Aufgabe3 {
    public static void main(String[] args) {
 /*     Даны строки разной длины (длина - четное число), необходимо вернуть два средних знака этой строки.
        Например, если дана строка "string" результат будет "ri", для строки "code" результат "od",
        для "Practice" результат "ct".*/
        String perSt1 = "String", perSt2 = "Code", perSt3 = "Practice";
        System.out.println("приложение для нахождения  двух средних знаков ");
        System.out.println("-----------------------------------------");
        System.out.println("Первое значене - " + perSt1.substring(2,4));
        System.out.println("-----------------------------------------");
        System.out.println("Второе значене - " + perSt2.substring(1,3));
        System.out.println("-----------------------------------------");
        System.out.println("Третье значене - " + perSt3.substring(3,5));
        System.out.println("-----------------------------------------");
       }
}

