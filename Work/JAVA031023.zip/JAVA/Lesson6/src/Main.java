public class Main {
    public static void main(String[] args) {
        System.out.println("Type char - practic");
        char ch = 65;
        System.out.println("Symbol with number 65: " + ch);
        char ch1 = 93;
        System.out.println("Symbol with number 93: " + ch1);
        char ch3 = 176;
        System.out.println("За бортом -65" + ch3) ;
        char ch4 = 178;
        System.out.println("2x" + ch4) ;

       // int perN = 7845;

    }
}