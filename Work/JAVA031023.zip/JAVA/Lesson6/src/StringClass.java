public class StringClass {
    public static void main(String[] args) {
        Object St;
        System.out.println("String pratice");
      //  String st = ("I like JAva! JAva is the way to earn good salary in IT.");
        String st = ("I like Java! Java is the best way to earn good salary in IT.");
        System.out.println(st);
        int l = st.length();
        System.out.println("Lengt of string is: " + l);
        char lastSymbol = st.charAt(st.length()-1); // определение символа (charAT)
        System.out.println("Last symbol is : " + lastSymbol);
        String st1 = "I like Java!";
        int index = st1.indexOf("Java"); //  выдает номер расположения слова (index)
        System.out.println("Java start from index = " + index);
        int index2 = st1.indexOf("like");
        System.out.println("Like start from index = "+ index2);
        boolean yesOrNo = st.contains("Java!!!"); // находит в предложении слово (True или False)
        System.out.println(yesOrNo);
        //---------------------------------- Меняем "A" на "O"
        System.out.println(st.replace("a", "o"));
        //-----------
        String stNew1 = st.toLowerCase();
        System.out.println(stNew1);
        String stNew2 = st.toUpperCase();
        System.out.println(stNew2);
        String stNew3 = st.substring(7,11);
        System.out.println(stNew3);
//---------------------
        String stNew4 = "I like Java!!!";
        yesOrNo = stNew4.endsWith("!!!!");
        System.out.println(yesOrNo);
    }
}