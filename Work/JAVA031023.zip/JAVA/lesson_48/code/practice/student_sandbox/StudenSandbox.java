package practice.student_sandbox;

public class StudenSandbox {
}
