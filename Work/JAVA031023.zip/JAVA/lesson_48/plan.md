# Lesson plan No. 47 dated 09/04/2023:

1. Add LinkedList

2. We create our own LinkedList using the example of integers, strings.

3. Employee - Company - CompanyImpl - implementation based on LinkedList

_________________________________________________

# План урока № 47 от 04.09.2023:

1. Разбираем LinkedList

2. Создаем свой LinkedList на примере целых чисел, строк.

3. Employee - Company - CompanyImpl - реализация на базе LinkedList



















