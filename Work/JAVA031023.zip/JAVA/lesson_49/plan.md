# Lesson plan No. 49 dated 09/11/2023:

1. Practice Working with LinkedList

2. Implementing the MyLinkedList Interface

_________________________________________________

# План урока № 49 от 11.09.2023:

1. Практика работы с LinkedList

2. имплементируем интерфейс MyLinkedList





















