package Aufgaben49;


public class MyLinkedListAppl {
    public static void main(String[] args) {
        MyLinkedListImpl myLinked = new MyLinkedListImpl();

        myLinked.add("A");
        myLinked.add("B");
        myLinked.add("C");
        myLinked.add("D");
        myLinked.add("E");
        myLinked.add("F");
        myLinked.display();
        System.out.println("*********************************************");
//        myLinked.reverseLinkedList();
//        myLinked.display();

//        myLinked.reverseLinkedList(2);
//        myLinked.display();
        myLinked.reverseLinkedList(1,5);
        myLinked.display();

    }
}
