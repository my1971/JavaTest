package practice;

import java.io.*;

public class CopyFile {
    public static void main(String[] args) throws FileNotFoundException {
        //String pathFile = "C:\\Arbeit\\AIT\\JAVA\\Lesson39\\src\\practice\\text.txt";
        String pathFile = "Lesson39/src/practice/text.txt";
        PrintWriter pw = new PrintWriter(pathFile);
        pw.println("Test 10");
        pw.println("Test 20");
        pw.println("Test 30");
        pw.close();

    }

    public void SaveFaleKlass() throws IOException {
        String[] tasks = new String[10];
        //final String OUTPUT = "taskstxt.txt";
        //BufferedWriter bfWhiter = new BufferedWriter(new FileWriter(OUTPUT));
        BufferedWriter bfWhiter = new BufferedWriter(new FileWriter("taskstxt.txt"));
        for (int i = 0; i < 2; i++) {
            bfWhiter.write(String.valueOf(tasks[i]) + "\n");
        }
        bfWhiter.flush();
    }
}

/*
pab

 */