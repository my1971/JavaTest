package practice.timeAppl;


public class DateOperation {

    public static int getAge(String birthDate) {
        //TODO


        return 0;
    }

    public static String[] sortStringDates(String[] dates) {
        //TODO


        return null;
    }
}