package practice.timeAppl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;

public class TimeAppl {
    public static void main(String[] args) {
        LocalDate currentDate = LocalDate.now();
        System.out.println(currentDate);
        LocalTime currentTime = LocalTime.now();
        System.out.println(currentTime);
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime);
        LocalDate gagarin = LocalDate.of(1961, 4, 12);
        System.out.println(gagarin.getYear());
        System.out.println(gagarin.getDayOfYear());
        System.out.println(gagarin.getChronology());
        System.out.println("Gagarin Day of Month = " + gagarin.getDayOfMonth());
        System.out.println("Gagarin Day of Week = " + gagarin.getDayOfWeek());
        LocalDate WeekIsus = LocalDate.of(00, 1, 1);
        System.out.println("Week Isus Day of Week = " + gagarin.getDayOfWeek());
        System.out.println(gagarin.isBefore(currentDate)); // true
        System.out.println(gagarin.isAfter(currentDate)); // false
        System.out.println("===========================");

        LocalDate newDate = currentDate.plusDays(40000);
        System.out.println(newDate);
        newDate = currentDate.plusWeeks(12);
        System.out.println("Add 12 Weeks " + newDate);
        newDate = currentDate.minusMonths(2);
        System.out.println("Add 2 Manth ago " + newDate);
        System.out.println("Прошло дней " + localDateTime.plus(9, ChronoUnit.HALF_DAYS));
        newDate = currentDate.plus(10, ChronoUnit.CENTURIES);
        System.out.println("CENTURIES " + newDate);

        LocalDate lenin = LocalDate.of(1870, 4, 22);
        long res = ChronoUnit.YEARS.between(gagarin, lenin);
        System.out.println("разница " + res);
        System.out.println(lenin.compareTo(gagarin));
        LocalDate[] dates = {gagarin, currentDate, lenin};
        // сортировка даты
        Arrays.sort(dates);
        System.out.println(Arrays.toString(dates));
        DateTimeFormatter df = DateTimeFormatter.ISO_DATE;
        System.out.println(gagarin.format(df));


        df = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
        System.out.println(gagarin.format(df));

        String date1 = "06/07/2023";
        String date2 = "2023-02-02";
        System.out.println("====4=545345==345=34=534=5");
        // LocalDate localDate1 = dateParse(date1);
        // System.out.println(localDate1);
        LocalDate localDate2 = dateParse(date2);
        System.out.println(localDate2);

        System.out.println("*/*/*/*/*/**/*");
        LocalDate localDate1 = dateParse(date1);
        System.out.println(localDate1);
        df = DateTimeFormatter.ofPattern("dd.MMM.yyyy");
        System.out.println(localDate1.format(df));
    }

    private static LocalDate dateParse(String date) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("[yyyy-MM-dd][dd/MM/yyyy]");
        return LocalDate.parse(date, df);
//        if (date.contains("-")) {
//            return LocalDate.parse(date);
//        } else {
//            return LocalDate.parse(date, df);
//        }
    }
}
