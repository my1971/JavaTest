package practice.timeAppl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class dateFormat {

    public static void main(String[] args) {
        LocalDateTime dateTime;
        dateTime = inDate("1/1/23");
        System.out.println(dateTime);
    }

    public static LocalDateTime inDate(String date) {
        return (date == null || date.trim() == "") ? (LocalDateTime.now()) : (LocalDateTime.of(LocalDate.parse(date,
                DateTimeFormatter.ofPattern("[yyyy/M/d][yyyy.M.d][yyyy-M-d][yyyy:M:d][d-M-yy][d.M.yy][d/M/yy][d:M:yy]")), LocalTime.now()));


//        return (date == null || date.trim() == "") ? (LocalDateTime.now()) : (LocalDateTime.parse(date,
//                DateTimeFormatter.ofPattern("[yyyy/M/d][yyyy.M.d][yyyy-M-d][yyyy:M:d][d-M-yy][d.M.yy][d/M/yy][d:M:yy]")));
    }
}
/* public LocalDate inDate(String date) {
        return (date == null || date.trim() == "") ? (LocalDate.now()) : (LocalDate.parse(date,
                DateTimeFormatter.ofPattern("[yyyy/M/d][yyyy.M.d][yyyy-M-d][yyyy:M:d][d-M-yy][d.M.yy][d/M/yy][d:M:yy]")));
 //   */