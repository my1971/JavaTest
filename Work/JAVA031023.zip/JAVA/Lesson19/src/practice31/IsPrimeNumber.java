package practice31;

public class IsPrimeNumber {
    public static void main(String[] args) {
        int a = 120; // до 120 все числа делятся от 1 до 9. начинается 121 делится на 11
        while (a < 30000){
            for (int i = 2; i < a - 1; i++) {
                if (a % i == 0){
                    if (i>10){System.out.println(a + "-----" + i);}
                    break;
                }
            }
            a++;
        }
    }
}
