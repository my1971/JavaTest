public class Main {
    public static void main(String[] args) {
        int a = 1;

        System.out.println((a == 1) ? ("Првильно") : ("не првильно") );
    }
}