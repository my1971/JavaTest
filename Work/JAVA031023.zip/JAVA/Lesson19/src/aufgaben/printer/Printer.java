package aufgaben.printer;

public class Printer {
    /* Задча 3. Создайте собственный класс и его методы из классной групповой работы.
    Создайте несколько экземпляров объектов созданного класса. Выполните действия с помощью методов класса.*/
    public String textPrint, modelPrinter;
    public Boolean color;
    public int quantity;

    // Constructor und Special method (конструктор специальный метод)
    public static void Display(){
  //      if (PrinterRepair.setAddParer = "Ready")
    }
    public Printer(String textPrint, String modelPrinter, Boolean color, int quantity) {
        this.textPrint = textPrint;
        this.modelPrinter = modelPrinter;
        this.color = color;
        this.quantity = quantity;
    }

    public String getTextPrint() {
        return textPrint;
    }

    public void setTextPrint(String textPrint) {
        this.textPrint = textPrint;
    }

    public String getModelPrinter() {
        return modelPrinter;
    }

    public void setModelPrinter(String modelPrinter) {
        this.modelPrinter = modelPrinter;
    }

    public Boolean getColor() {
        return color;
    }

    public void setColor(Boolean color) {
        this.color = color;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
