package aufgaben.printer;

public class PrinterAppl19_3 {
    public static void main(String[] args) {

//        PrinterRepair CheckPrint = new PrinterRepair(20,"Ready");
//        Printer textPrint1 = new Printer("Hello world!", "HP Color", true, 2);
    }
}
