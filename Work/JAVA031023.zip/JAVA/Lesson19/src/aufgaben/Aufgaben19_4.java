/*  - encapsulation (инкапсуляция)
    - polymorphism (полиморфизм)
    - inheritance (наследование)*/
package aufgaben;
import java.util.Scanner;

public class Aufgaben19_4 {
    public static void main(String[] args) {
/* Задача 4.(*) (на повторение темы массивы, циклы и вычисления)
                Найти все простые числа меньше введенного числа n и занести их в массив.
                В консоли распечатать само число, количество найденных простых чисел и сами эти числа.
                Пример: дано число 30 простые числа, меньшие 30 это: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 таких чисел: 10 */
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("Input integer positive number: ");
            int n = scanner.nextInt();
            if (n > 0){display(CheckNumber(n));} else {break;} // выбор числа меньше или равно 0 дает выход из цикла
        }
    }
    public static int[] CheckNumber(int n){
        System.out.println(" ");
        System.out.println("Number = " + n);
        int l = 0, i1 = 0;
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0){l++;}
        }
        int[] arr = new int[l];
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0){
                arr[i1] = n / i;
                i1++;
            }
        }
        return arr;
    }
    public static void display(int[] arr){
        for (int i = 0; i < arr.length ; i++) {
            System.out.println("Number " + arr[i]);
        }
    }
}
/*
    - encapsulation (инкапсуляция)
    - polymorphism (полиморфизм)
    - inheritance (наследование)
      topic for today (тема на сегодня)

 */
