package practice31.sentence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SentenceTest {
    Sentence sentence; // определяем поле с типом тестируемого класса и создаем объект такого типа

    @BeforeEach
    void setUp() {
        sentence = new Sentence();
    }

    @Test
    void wordsInSentence() {
        String st = "Привет и пока";
        //int n = sentence.wordsInSentence(st);
        assertEquals(3, sentence.wordsInSentence(st));
    }

    @Test
    void lettersInSentence() {
        String st = "Я вам пишу, чего же более...";
        assertEquals(19, sentence.lettersInSentence(st));
    }
}