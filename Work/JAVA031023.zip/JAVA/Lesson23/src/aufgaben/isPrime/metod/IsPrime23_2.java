package aufgaben.isPrime.metod;

import javax.swing.*;

public class IsPrime23_2 {
    /*Task 2. For a method to check if a number is prime, write a test. Use assert for boolean expressions.(primary)
   Задача 2. Для метода проверки, является ли число простым, написать тест. Использовать assert для логических выражений.
       - Проcтое число - это число, которое делится только на себя и 1. Примеры: 2, 7, 11, 19, 47. */
     public void checkPrime(int n) {
        boolean isPrime = true;
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0) {
                isPrime = false;
                System.out.println(i);
            }
        }
        if (isPrime) {
            JOptionPane.showMessageDialog(null, "Number " + n + " is prime");
        } else {
            JOptionPane.showMessageDialog(null, "Number " + n + " is not prime");
        }
    }
}
