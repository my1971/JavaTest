package aufgaben.isPrime;

import javax.swing.*;
import aufgaben.isPrime.metod.IsPrime23_2;
public class IsPrimeAppl {
    public static void main(String[] args) {
        IsPrime23_2 isPrime = new IsPrime23_2();
        while (true) {
            String st = JOptionPane.showInputDialog("Input integer positive number:: ");
            if (st == null) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
            isPrime.checkPrime((Integer.parseInt(st)));
            int n = Integer.parseInt(st);

            int reply = JOptionPane.showConfirmDialog(null, "Continie?", "Question?", JOptionPane.YES_NO_OPTION);
            if (!(reply == JOptionPane.YES_OPTION)) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
        }
    }
}
