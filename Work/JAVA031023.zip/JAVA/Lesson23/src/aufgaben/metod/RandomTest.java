package aufgaben.metod;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

class RandomTest {
    Random random;

    @BeforeEach
    void setUp() {
        random = new Random();
    }

    @Test
    void display() {
    }

    @Test
    void sumNumberInArray() {
        assertEquals("5 2 4 1", random.sumNumberInArray(random.fillArray()));
    }

    @Test
    void fillArray() {
        int[] arr = {-10, 10, 5, 0, 7, 5, 3, -2};
        assertArrayEquals(arr, random.fillArray());
    }
}