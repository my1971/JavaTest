/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 **********************************************************************************************************************/

package aufgaben.metod;

import java.util.Arrays;

public class Random {

    /*  Task 1. Create an array of 100 random integers between -10 and 10. Calculate how many are in this array:
            -   positive numbers;
            -   negative numbers;
            -   even numbers;
            -   zero.
            Formulate a solution to this problem by methods and write tests for them.
    Задча 1. Создайте массив из 100 случайных целых чисел в интервале от -10 до 10. Подсчитайте, сколько в этом массиве оказалось:
            -   положительных чисел;
            -   отрицательных чисел;
            -   четных чисел;
            -   нулей.
            Оформите решение данной задачи методами и напишите для них тесты.*/
//  int num[] = fillArray(-10, 10, 100,1); // заполнение массива 10 Indexes (генерирует случайное число)
//  String[] sum = sumNumberInArray(num).split(" ");

    //Metods

    public void display(String [] sum) {
        System.out.println("Положительных чисел - [" + sum[0] + "]");
        System.out.println("Отрицательных чисел - [" + sum[1] + "]");
        System.out.println("Четных чисел        - [" + sum[2] + "]");
        System.out.println("Нулей               - [" + sum[3] + "]");
    }
    public String sumNumberInArray(int[] num) {
        String retSum;
        int sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0;
        for (int i = 0; i < num.length; i++) {
            if (num[i] > 0) {
                sum1++;
            } else if (num[i] < 0) {
                sum2++;
            } else {
                sum4++;
            }
            if (num[i] % 2 == 0) {
                sum3++;
            }
        }
        retSum = sum1 + " " + sum2 + " " + sum3 + " " + sum4;
        return retSum;
    }
    int num[] = fillArray(-10, 10, 100);
    public int[] fillArray(int a, int b, int x) { // заполнение массива (генерирует случайное число)
       int[] arr = new int[x];
       for (int i = 0; i < arr.length; i++) {
           arr[i] = (int) (Math.random() * (b - a + 1) + a);
       }
       return arr;
    }
    public int[] fillArray() { // заполнение массива (генерирует случайное число)
        int[] arr = {-10, 10, 5, 0, 7, 5, 3, -2};
        return arr;
    }
    public Random() {}
}


//    public int[] fillArray(int a, int b, int x, boolean test) { // заполнение массива (генерирует случайное число)
//        if (test) {
//            int[] arr = {-10, 10, 5, 0, 7, 5, 3, -2};
//            return arr;
//        } else {
//            int[] arr = new int[x];
//            for (int i = 0; i < arr.length; i++) {
//                arr[i] = (int) (Math.random() * (b - a + 1) + a);
//            }
//            return arr;
//        }
//    }
