package aufgaben;

public class Aufgaben23 {
}
/*
Task 1. Create an array of 100 random integers between -10 and 10. Calculate how many are in this array:
        -   positive numbers;
        -   negative numbers;
        -   even numbers;
        -   zero.
        Formulate a solution to this problem by methods and write tests for them.
Задча 1. Создайте массив из 100 случайных целых чисел в интервале от -10 до 10. Подсчитайте, сколько в этом массиве оказалось:
        -   положительных чисел;
        -   отрицательных чисел;
        -   четных чисел;
        -   нулей.
        Оформите решение данной задачи методами и напишите для них тесты.

Task 2. For a method to check if a number is prime, write a test. Use assert for boolean expressions.
Задача 2. Для метода проверки, является ли число простым, написать тест. Использовать assert для логических выражений.

Task 3.(*) Write tests for User class methods (email and password validation).
Задача 3.(*) Написать тесты для методов класса User (валидация email и password).
 */