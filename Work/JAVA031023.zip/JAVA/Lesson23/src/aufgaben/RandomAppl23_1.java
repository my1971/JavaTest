package aufgaben;
import aufgaben.metod.Random;
public class RandomAppl23_1 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] arr = random.fillArray(-20,20,100);
        String[] sum = random.sumNumberInArray(arr).split(" ");
        random.display(sum);
    }

}
