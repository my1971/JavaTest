package aufgaben30.garage.appl;

import aufgaben30.garage.dao.Garage;
import aufgaben30.garage.dao.GarageImpl;
import aufgaben30.garage.model.Buse;
import aufgaben30.garage.model.Cars;
import aufgaben30.garage.model.Transports;

public class GarageImplAppl {
    public static void main(String[] args) {


        Garage garage; // создали объект класса Company
        garage = new GarageImpl(5);
        Transports[] transport = new Transports[5];
        //firm = new Employee[14];
        transport[0] = new Cars(100, "John", "BE 144", "Scoda");
        transport[1] = new Cars(101, "Bread", "BN 5555", "AUDI");
        transport[2] = new Buse(102, "Julia", "BE 777", "SETRA");
        transport[3] = new Buse(186, "Peter", "Sa 5678", "SCANIA");
        garage.addTransport(transport[0]);
        garage.addTransport(transport[1]);
        garage.addTransport(transport[2]);
        garage.addTransport(transport[3]);
        garage.addTransport(transport[4]);
        garage.addTransport(transport[4]);
        garage.printTransport();

    }
}


