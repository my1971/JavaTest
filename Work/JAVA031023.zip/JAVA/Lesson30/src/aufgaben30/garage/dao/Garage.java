package aufgaben30.garage.dao;

import aufgaben30.garage.model.Transports;

public interface Garage {
    //перечень действий метода

    //берем на работу
    boolean addTransport(Transports transport); // добавить сотрудника в компанию

    Transports removeTransport(int id); //удоляет сотрудника из компании

    // найти сотрудника по его ID
    Transports findTransport(int id); //ищем  сотрудника в компании

    //размер компании
    int size();

    // печатаем список
    void printTransport();

}
