package aufgaben30.garage.dao;

import aufgaben30.garage.model.Transports;

public class GarageImpl implements Garage {
    private final Transports[] transports;
    private int size = 0;

    public GarageImpl(int capacity) {
        transports = new Transports[capacity]; // capacity становится длиной массива
    }

    @Override
    public boolean addTransport(Transports transport) {
        if (transport == null || size == transports.length || findTransport(transport.getId()) != null) return false;
        transports[size] = transport;
        size++;
        return true;
    }

    @Override
    public Transports removeTransport(int id) {
        for (int i = 0; i < transports.length; i++) {
            if (transports[i].getId() == id) {
                Transports remuve = transports[i];
                transports[i] = transports[size - 1];
                transports[size - 1] = null;
                size--;
                return remuve;
            }
        }
        return null;
    }

    @Override
    public Transports findTransport(int id) {
        for (int i = 0; i < size; i++) {
            if (transports[i].getId() == id) {
                return transports[i];
            }
        }
        return null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void printTransport() {
        for (int i = 0; i < transports.length; i++) {
            if (transports[i] != null) {
                System.out.println(transports[i]);
            }
        }
    }

}
