package aufgaben30.garage.model;

public class Cars extends Transports {

    // дополнительные поля
    private String modelAuto;


    // конструктор
    public Cars(int id, String driverName, String numberAuto, String modelAuto) {
        super(id, driverName, numberAuto);
        this.modelAuto = modelAuto;
    }

    public String getModelAuto() {
        return modelAuto;
    }

    public void setModelAuto(String modelAuto) {
        this.modelAuto = modelAuto;
    }
}

