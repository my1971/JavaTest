package aufgaben30.garage.model;

public abstract class Transports {

    // поля класса
    protected final int id; // это хорошо
    protected String driverName;
    protected String NumberAuto;

    // методы
    // метод - конструктор

    public Transports(int id, String driverName, String numberAuto) {
        this.id = id;
        this.driverName = driverName;
        NumberAuto = numberAuto;
    }

    public int getId() {
        return id;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getNumberAuto() {
        return NumberAuto;
    }

    public void setNumberAuto(String numberAuto) {
        NumberAuto = numberAuto;
    }

    @Override
    public String toString() {
        return "Transports{" +
                "id=" + id +
                ", driverName='" + driverName + '\'' +
                ", NumberAuto='" + NumberAuto + '\'' +
                '}';
    }
}