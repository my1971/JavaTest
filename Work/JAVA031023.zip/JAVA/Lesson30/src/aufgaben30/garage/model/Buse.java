package aufgaben30.garage.model;

public class Buse extends Transports {

    // поля
    private String modelBus;

    // конструктоор
    public Buse(int id, String driverName, String numberAuto, String modelBus) {
        super(id, driverName, numberAuto);
        this.modelBus = modelBus;
    }

    public String getModelBus() {
        return modelBus;
    }

    public void setModelBus(String modelBus) {
        this.modelBus = modelBus;
    }
}