package aufgaben30.garage.tests;

import aufgaben30.garage.dao.Garage;
import aufgaben30.garage.dao.GarageImpl;
import aufgaben30.garage.model.Buse;
import aufgaben30.garage.model.Cars;
import aufgaben30.garage.model.Transports;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GarageImplTest {

    Garage garage = new GarageImpl(6);
    // создали объект класса Company
    Transports[] transport = new Transports[5];

    @BeforeEach
    void setUp() {
        //company = new CompanyImpl(15);
        transport[0] = new Cars(100, "John", "BE 144", "Scoda");
        transport[1] = new Cars(101, "Bread", "BN 5555", "AUDI");
        transport[2] = new Buse(102, "Julia", "BE 777", "SETRA");
        transport[3] = new Buse(186, "Peter", "Sa 5678", "SCANIA");
        for (int i = 0; i < transport.length; i++) {

            garage.addTransport(transport[i]);
        }
    }

    @Test
    void addTransport() {
        assertFalse(garage.addTransport(null)); // нельзя добавить “пустого” сотрудника
        assertFalse(garage.addTransport(transport[0])); // можно добавить сотрудника
        assertFalse(garage.addTransport(transport[1])); // можно добавить сотрудника
        assertFalse(garage.addTransport(transport[2])); // можно добавить сотрудника
        assertFalse(garage.addTransport(transport[3])); // можно добавить сотрудника
        assertEquals(4, garage.size());
        Transports transport = new Buse(187, "Peter", "BE 144", "Scoda");
        assertTrue(garage.addTransport(transport));
        assertEquals(5, garage.size());
        assertFalse(garage.addTransport(transport));// нельзя добавить уже имеющегося сотрудник
        transport = new Buse(186, "Peter", "BE 144", "Scoda");
        assertFalse(garage.addTransport(transport)); //нельзя выйти за размер компании
    }

    @Test
    void removeTransport() {
        assertEquals(4, garage.size());
        assertEquals(transport[0], garage.removeTransport(100));
        System.out.println(garage.size());
    }

    @Test
    void findTransport() {
        assertEquals(transport[0], garage.findTransport(100));
    }

    @Test
    void size() {
    }

    @Test
    void printTransport() {
    }
}