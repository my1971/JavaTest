package practice31.dublicate_in_array;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DuplicateArrayTest {
    DuplicateArray duplicateArray;

    @BeforeEach
    void setUp() {
        duplicateArray = new DuplicateArray();
    }

    @Test
    void displayDuplicates() {
    }

    @Test
    void testDisplayDuplicates() {
        // Создаем масив с чмслами дубликатоми внутри
        // вызываем метод из тестируемого класса
        //
        int[] arr = {5, 4, 5, 3, 2};
        // int res = duplicateArray.displayDuplicates(arr,5);
        assertEquals(2, duplicateArray.displayDuplicates(arr, 5));
    }
}
