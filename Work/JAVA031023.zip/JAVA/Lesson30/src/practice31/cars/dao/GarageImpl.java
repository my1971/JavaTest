package practice31.cars.dao;

import practice31.cars.model.Car;

public class GarageImpl implements Garage {

    private final Car[] cars;
    private int size;

    public GarageImpl(int capacity) {
        cars = new Car[capacity];
    }

    @Override
    public boolean addCar(Car car) {
        if (car == null || size == cars.length || findCarByRegNumber(car.getRegNumber()) != null) {
            return false;
        }
//        cars[size - 1] = car;
//        size++;
        cars[size++] = car; // постфикация операция ++ увеличит size после присвоения
        return true;
    }

    @Override
    public Car removeCar(String regNumber) {
        for (int i = 0; i < size; i++) {
            if (regNumber.equals(cars[i].getRegNumber())) {
                Car remove = cars[i];
                size--;
                cars[i] = cars[size];
                cars[size] = null;

                return remove;
            }
        }
        return null;
    }

    @Override
    public Car findCarByRegNumber(String regNumber) {
        for (int i = 0; i < size; i++) {
            if (cars[i].getRegNumber().equals(regNumber)) {
                return cars[i];
            }
        }
        return null;
    }

    @Override
    public Car[] findCarsByModel(String model) {
        int len = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getModel() == model) {
                len++;
            }
        }
        Car[] carsTemp = new Car[len];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getModel() == model) {
                carsTemp[j] = cars[i];
                j++;
            }
        }
        return carsTemp;
    }

    @Override
    public Car[] findCarsByCompany(String company) {
        int len = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getCompany() == company) {
                len++;
            }
        }
        Car[] carsTemp = new Car[len];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getCompany() == company) {
                carsTemp[j] = cars[i];
                j++;
            }
        }
        return carsTemp;
    }

    @Override
    public Car[] findCarsByEngine(double min, double max) {
        int len = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getEngine() >= min && cars[i].getEngine() <= max) {
                len++;
            }
        }
        Car[] carsTemp = new Car[len];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getEngine() >= min && cars[i].getEngine() <= max) {
                carsTemp[j] = cars[i];
                j++;
            }
        }
        return carsTemp;
    }

    @Override
    public Car[] findCarsByColor(String color) {
        int len = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getColor() == color) {
                len++;
            }
        }
        Car[] carsTemp = new Car[len];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (cars[i].getColor() == color) {
                carsTemp[j] = cars[i];
                j++;
            }
        }
        return carsTemp;

    }

    public void printCar() {
        for (int i = 0; i < size; i++) {
            if (cars[i] != null) {
                System.out.println(cars[i]);
            }
        }
    }

    @Override
    public void printCar(Car[] car) {
        for (int i = 0; i < car.length; i++) {
            if (car[i] != null) {
                System.out.println(car[i]);
            }
        }
    }

    @Override
    public int size() {
        return size;
    }
}
