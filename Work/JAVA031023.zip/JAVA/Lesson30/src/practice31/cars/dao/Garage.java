package practice31.cars.dao;

import practice31.cars.model.Car;

public interface Garage {
    //перечень действий метода

    boolean addCar(Car car);

    Car removeCar(String regNumber);

    Car findCarByRegNumber(String regNumber);

    Car[] findCarsByModel(String model);

    Car[] findCarsByCompany(String company);

    Car[] findCarsByEngine(double min, double max);

    Car[] findCarsByColor(String color);

    void printCar();

    void printCar(Car[] car);

    int size();
}
//    boolean addTransport(Transports transport); // добавить сотрудника в компанию
//
//    Transports removeTransport(int id); //удоляет сотрудника из компании
//
//    // найти сотрудника по его ID
//    Transports findTransport(int id); //ищем  сотрудника в компании
//
//    //размер компании
//    int size();
//
//    // печатаем список
//    void printTransport();