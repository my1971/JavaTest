package practice31.cars.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice31.cars.dao.Garage;
import practice31.cars.dao.GarageImpl;
import practice31.cars.model.Car;

import static org.junit.jupiter.api.Assertions.*;

class GarageImplApplTestArc {
    Garage garage = new GarageImpl(6); // создали объект класса Company
    Car[] cars = new Car[6];

    @BeforeEach
    void setUp() {
        cars[0] = new Car("BA 5555", "AUDI", "HAV", 2.0, "White");
        cars[1] = new Car("BN 5235", "SCODA", "MURA", 1.6, "Black");
        cars[2] = new Car("BN 3215", "AUDI", "TCar", 3.0, "White");
        cars[3] = new Car("BN 5789", "Mersedes", "LIT", 3.5, "Black");
        cars[4] = new Car("BN 3218", "BMV", "TCar", 4.0, "White");
        cars[5] = new Car("BN 3248", "BMV", "MIR", 4.0, "Yellow");
        for (int i = 0; i < cars.length; i++) {
            garage.addCar(cars[i]);
        }
    }

    @Test
    void addCar() {
        assertFalse(garage.addCar(null)); // нельзя добавить “пустую” машину
        assertFalse(garage.addCar(cars[0]));
        assertFalse(garage.addCar(cars[1]));
        assertFalse(garage.addCar(cars[2]));
        assertFalse(garage.addCar(cars[3]));
        assertFalse(garage.addCar(cars[4]));
        assertFalse(garage.addCar(cars[5]));
        assertEquals(6, garage.size());
        assertFalse(garage.addCar(cars[5])); // нельзя добавить вторую машину с одним номером
        assertEquals(6, garage.size());
    }

    @Test
    void removeCar() {
        assertEquals(6, garage.size());
        assertEquals(cars[5], garage.removeCar("BN 3248"));
        assertEquals(5, garage.size());
    }

    @Test
    void findCarByRegNumber() {
        assertEquals(6, garage.size());
        assertEquals(cars[5], garage.findCarByRegNumber("BN 3248"));
        assertNull(garage.findCarByRegNumber("BN 3248-ANY")); // несуществующий объект
    }

    @Test
    void findCarsByModel() {
        String modelTest = "AUDI";
        Car[] carsTemp = new Car[garage.size()];
        int j = 0;
        for (int i = 0; i < garage.size(); i++) {
            if (cars[i].getModel() == modelTest) {
                carsTemp[j++] = cars[i];
            }
        }
        Car[] arrCars = new Car[j];
        System.arraycopy(carsTemp, 0, arrCars, 0, j);

//        for (int i = 0; i < arrCars.length; i++) {
//            System.out.println(arrCars[i]);
//        }
        int q = 0;
        for (Car i : arrCars) {
            System.out.println(i.toString());
        }
        assertEquals(2, garage.findCarsByModel("AUDI").length);
        assertArrayEquals(carsTemp, garage.findCarsByModel("AUDI"));
    }

    private void assertArrayEquals(Car[] carsTemp, Car[] audi) {
    }// Метод создала система для устранения ошибки

    @Test
    void findCarsByCompany() {

    }

    @Test
    void findCarsByEngine() {

    }

    @Test
    void findCarsByColor() {

    }
}