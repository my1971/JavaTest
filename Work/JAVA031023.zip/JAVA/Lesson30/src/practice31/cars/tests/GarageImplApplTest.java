package practice31.cars.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice31.cars.dao.Garage;
import practice31.cars.dao.GarageImpl;
import practice31.cars.model.Car;

import static org.junit.jupiter.api.Assertions.*;

class GarageImplApplTest {
    Garage garage = new GarageImpl(6); // создали объект класса Company
    Car[] carsTest = new Car[6];

    @BeforeEach
    void setUp() {
        carsTest[0] = new Car("BA 5555", "AUDI", "HAV", 2.0, "White");
        carsTest[1] = new Car("BN 5235", "SCODA", "MURA", 1.6, "Black");
        carsTest[2] = new Car("BN 3215", "AUDI", "TCar", 3.0, "White");
        carsTest[3] = new Car("BN 5789", "Mersedes", "LIT", 3.5, "Black");
        carsTest[4] = new Car("BN 3218", "BMV", "TCar", 4.0, "White");
        carsTest[5] = new Car("BN 3248", "BMV", "MIR", 4.0, "Yellow");
        for (int i = 0; i < carsTest.length; i++) {
            garage.addCar(carsTest[i]);
        }
    }

    @Test
    void addCar() {
        assertFalse(garage.addCar(null)); // нельзя добавить “пустую” машину
        assertFalse(garage.addCar(carsTest[0]));
        assertFalse(garage.addCar(carsTest[1]));
        assertFalse(garage.addCar(carsTest[2]));
        assertFalse(garage.addCar(carsTest[3]));
        assertFalse(garage.addCar(carsTest[4]));
        assertFalse(garage.addCar(carsTest[5]));
        assertEquals(6, garage.size());
        assertFalse(garage.addCar(carsTest[5])); // нельзя добавить вторую машину с одним номером
        assertEquals(6, garage.size());
    }

    @Test
    void removeCar() {
        assertEquals(6, garage.size());
        assertEquals(carsTest[5], garage.removeCar("BN 3248"));
        assertEquals(5, garage.size());
    }

    @Test
    void findCarByRegNumber() {
        assertEquals(6, garage.size());
        assertEquals(carsTest[5], garage.findCarByRegNumber("BN 3248"));
        assertNull(garage.findCarByRegNumber("BN 3248-ANY")); // несуществующий объект
    }

    @Test
    void findCarsMyModel() {
        assertEquals(2, garage.findCarsByModel("AUDI").length);
    }

    @Test
    void findCarsByCompany() {
        assertEquals(2, garage.findCarsByCompany("TCar").length);
    }

    @Test
    void findCarsByEngine() {
        assertEquals(5, garage.findCarsByEngine(2.0, 4.0).length);
    }

    @Test
    void findCarsByColor() {
        assertEquals(3, garage.findCarsByColor("White").length);
    }
}