package practice.cats;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;

class CatTest {
    Cat[] cats;

    @BeforeEach
    void setUp() {
        cats = new Cat[]{
                new Cat("Mursik", 5, "Black", 4.8),
                new Cat("Gar", 12, "Gray", 9.8),
                new Cat("Lusy", 3, "White", 4.5),
                new Cat("Pon", 6, "Red", 6.5),
                new Cat("Wasya", 9, "Black", 5.1),
                new Cat("Vasya", 5, "Black", 5.0),
                new Cat("Vasya", 3, "Black", 5.0),
                new Cat("Vasya", 2, "Black", 5.0)
        };
    }

    @Test
    void catSortTestName() {
        System.out.println("------------------ Cats unsorted------------------------");
        printArray(cats);
        Arrays.sort(cats); // подвергаем сортировке
        System.out.println(" ");
        System.out.println("------------------ Cats sorted by age ------------------------");
        printArray(cats);

    }

    @Test
    void catSortComporator() {
        printArray(cats);
        System.out.println("=====================================");
        Comparator<Cat> catComparator = new Comparator<Cat>() {
            @Override
            public int compare(Cat o1, Cat o2) {
                return Double.compare(o1.getWight(), o2.getWight());
            }
        };
        Arrays.sort(cats, catComparator);
        printArray(cats);
    }

    void catSortTestAge() {
        System.out.println("------------------ Cats unsorted------------------------");
        printArray(cats);
        Arrays.sort(cats); // подвергаем сортировке
        System.out.println(" ");
        System.out.println("------------------ Cats sorted by age ------------------------");
        printArray(cats);

    }

    public void printArray(Object[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}