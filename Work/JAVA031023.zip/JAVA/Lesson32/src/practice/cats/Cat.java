package practice.cats;

import java.util.Objects;

public class Cat implements Comparable<Cat> {
    // Создать класс Cat, 4 поля
// стандартные конструктор, геттеры и сеттеры
// toString - переопределить
// Создать класс для тестирования
// создать массив с представителями класса
// добавить интерфейс comparable в класс Cat, переопределить метод compareTo
// отсортировать массив кошек
    private String name;
    private int age;
    private String color;
    private double wight;

    public Cat(String name, int age, String color, double wight) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.wight = wight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getWight() {
        return wight;
    }

    public void setWight(double wight) {
        this.wight = wight;
    }

    @Override
    public String toString() {
        return "Cats{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                ", wight=" + wight +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cat cats = (Cat) o;
        return age == cats.age && Double.compare(wight, cats.wight) == 0 && Objects.equals(name, cats.name) && Objects.equals(color, cats.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, color, wight);
    }

    @Override
    public int compareTo(Cat o) {
        // сортировка по имени и по возрасту
        int res1 = this.name.compareTo(o.name);
        int res2 = o.age - this.age;
        int res = 0;
        if (res1 <= 0 && res2 <= 0) {
            res = 1;
        } else {
            res = -1;
        }
        return res;
    }

    //  public int compareTo(Cat o) {

    //return o.age - this.age; // сортировка по возрасту
    //return - this.name.compareTo(o.name); // сортирует по имени (инверсия добивается минусом)
    //}
}
