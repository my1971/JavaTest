package aufgaben32.cars;

import java.util.Objects;

public class Car implements Comparable<Car> {
    public String regNumber;
    public String model;
    public String company; // в гараже стоят машины разных компаний
    public double engine; // объем двигателя, либо мощность
    public String color;
    public int milage;

    public Car(String regNumber, String model, String company, double engine, String color, int milage) {
        this.regNumber = regNumber;
        this.model = model;
        this.company = company;
        this.engine = engine;
        this.color = color;
        this.milage = milage;
    }

    @Override
    public String toString() {
        return "Car{" +
                "regNumber='" + regNumber + '\'' +
                ", model='" + model + '\'' +
                ", company='" + company + '\'' +
                ", engine=" + engine +
                ", color='" + color + '\'' +
                ", milage=" + milage +
                '}';
    }

    public int getMilage() {
        return milage;
    }


    public String getModel() {
        return model;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return Objects.equals(regNumber, car.regNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(regNumber);
    }

    @Override
    public int compareTo(Car o) {
        return this.model.compareTo(o.model);
    }
}