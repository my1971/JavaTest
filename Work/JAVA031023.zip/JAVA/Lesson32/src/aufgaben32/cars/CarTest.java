package aufgaben32.cars;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;

class CarTest {
    Car[] cars;

    @BeforeEach
    void setUp() {
        cars = new Car[]{new Car("BA 5555", "AUDI", "HAV", 2.0, "White", 52495),
                new Car("BN 5235", "SCODA", "MURA", 1.6, "Black", 49325),
                new Car("AN 3215", "AUDI", "TCar", 3.0, "White", 26435),
                new Car("BN 5789", "Mersedes", "LIT", 3.5, "Black", 78942),
                new Car("AN 3218", "BMV", "TCar", 4.0, "White", 278954),
                new Car("BN 3248", "BMV", "MIR", 4.0, "Yellow", 851216)
        };
    }

    @Test
    void catSortTestName() {
        System.out.println("------------------ Cars unsorted------------------------");
        printArray(cars);
        Arrays.sort(cars); // подвергаем сортировке
        System.out.println(" ");
        System.out.println("------------------ Cars sorted by age ------------------------");
        printArray(cars);

    }

    @Test
    void carsSortByConditionsTest() {
        System.out.println("=========Unsorted=============");
        printArray(cars);

        Comparator<Car> modelComporatorFields = (o1, o2) -> {
            int modelCompare = o1.getModel().compareTo(o2.getModel()); // сортировка по модели
            if (modelCompare != 0) {
                return modelCompare;
            } else {
                return o1.getMilage() - o2.getMilage(); // сортировка по пробегу
            }

        };

        System.out.println("=========Sorted=============");
        Arrays.sort(cars, modelComporatorFields);
        printArray(cars);
    }

    public void printArray(Object[] arr) {
        for (Object o : arr) {
            System.out.println(o);
        }
    }
}