package practiceAlt41New.album.model;

import java.time.LocalDate;
import java.util.Objects;

public class Photo {
    private final int albumID;
    private final int photoID;
    private String title;
    private String url; //UnionCode rielese Locator
    private final LocalDate date;
    // constructor


    public Photo(int albumID, int photoID, String title, String url, LocalDate date) {
        this.albumID = albumID;
        this.photoID = photoID;
        this.title = title;
        this.url = url;
        this.date = date;
    }
    //Getter und Setter

    public int getAlbumID() {
        return albumID;
    }

    public int getPhotoID() {
        return photoID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDate getDate() {
        return date;
    }

    @Override //переопределяем или перегружаем (это полиморфизм)
    public String toString() {
        return "Photo{" +
                "albumID=" + albumID +
                ", photoID=" + photoID +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", date=" + date +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Photo photo = (Photo) o;
        return albumID == photo.albumID && photoID == photo.photoID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(albumID, photoID);
    }

    //***************  End Class **********************************
}
