package practiceAlt41New.album.dao;

import practiceAlt41New.album.model.Photo;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;

public class AlbumImpl implements Album {
    static Comparator<Photo> comparator = (p1, p2) -> {
        int res = p1.getDate().compareTo(p2.getDate());
        return res != 0 ? res : Integer.compare(p1.getPhotoID(), p2.getPhotoID());
    };
    //поля
    private final Photo[] photos;
    private int size;

    // конструктор
    public AlbumImpl(int Capacity) {
        photos = new Photo[Capacity];
    }

    @Override
    public boolean addPhoto(Photo photo) {
        if (photo == null || photos.length == size || getPhotoFromAlbum(photo.getPhotoID(), photo.getAlbumID()) != null) {
            return false;
        }
        int index = Arrays.binarySearch(photos, 0, size, photo, comparator); //нашли место куда надо вставть фото
        index = index >= 0 ? index : -index - 1;
        System.arraycopy(photos, index, photos, index + 1, size - index);
        photos[index] = photo;
        size++;
        return false;
    }

    @Override
    public boolean removePhoto(int photoID, int albumID) {
        for (int i = 0; i < size; i++) {
            if (photos[i].getPhotoID() == photoID && photos[i].getAlbumID() == albumID) {
                System.arraycopy(photos, i + 1, photos, i, size - 1 - i);
                photos[--size] = null;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean updatePhoto(int photoID, int albumID, String url) {
        Photo photo = getPhotoFromAlbum(photoID, albumID);
        if (photo == null) return false;
        photo.setUrl(url);
        return false;
    }

    @Override
    public Photo getPhotoFromAlbum(int photoID, int albumID) {
        Photo pattern = new Photo(albumID, photoID, null, null, null);
        for (int i = 0; i < size; i++) {
            if (pattern.equals(photos[i])) return photos[i];
        }
        return null;
    }

    @Override
    public Photo[] getAllPhotoFromAlbum(int albumID) {
        return findByPredicate(p -> p.getAlbumID() == albumID);
    }

    private Photo[] findByPredicate(Predicate<Photo> predicate) {
        Photo[] res = new Photo[size];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (predicate.test(photos[i])) res[j++] = photos[i];
        }
        return Arrays.copyOf(res, j); // копируем только ту часть, где нет null
    }

    @Override
    public Photo[] getPhotoBetweenDate(LocalDate dateFrom, LocalDate dateTo) {
        return new Photo[0];
    }

    @Override
    public int size() {
        return size;
    }
}
