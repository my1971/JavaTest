package practice31.cars.appl;

import practice31.cars.dao.Garage;
import practice31.cars.dao.GarageImpl;
import practice31.cars.model.Car;

public class GarageImplAppl {
    public static void main(String[] args) {


        Garage garage; // создали объект класса Company
        garage = new GarageImpl(5);
        Car[] cars = new Car[14];

        cars[0] = new Car("BA 5555", "AUDI", "HAV", 2.0, "White");
        cars[1] = new Car("BN 5235", "SCODA", "MURA", 1.6, "Black");
        cars[2] = new Car("BN 3215", "AUDI", "TCar", 3.0, "White");
        cars[3] = new Car("BN 5789", "Mersedes", "LIT", 3.5, "Black");
        cars[4] = new Car("BN 3218", "BMV", "TCar", 4.0, "White");
        cars[5] = new Car("BN 3248", "BMV", "MIR", 4.0, "Yellow");

        garage.addCar(cars[0]);
        garage.addCar(cars[1]);
        garage.addCar(cars[2]);
        garage.addCar(cars[3]);
        garage.addCar(cars[4]);
        garage.addCar(cars[5]);
        garage.addCar(cars[5]);

//        garage.printCar();
//        garage.removeCar("BN 5235");
//        System.out.println("------------------------------");
//        garage.printCar();
//        System.out.println("----------  findCarsMyModel  --------------------");
//        garage.printCar(garage.findCarsMyModel("AUDI"));
//        System.out.println("----------  findCarsByCompany  --------------------");
//        garage.printCar(garage.findCarsByCompany("TCar"));
//        System.out.println("----------  findCarsByEngine  --------------------");
//        garage.printCar(garage.findCarsByEngine(1.1, 3.9));
//        System.out.println("----------  findCarsByColor  --------------------");
//        garage.printCar(garage.findCarsByColor("White"));
    }
}


