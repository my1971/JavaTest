package practice31.cars.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice31.cars.dao.Garage;
import practice31.cars.dao.GarageImpl;
import practice31.cars.model.Car;

import static org.junit.jupiter.api.Assertions.*;

class GarageImplApplTest {
    Garage garage = new GarageImpl(6); // создали объект класса Company
    Car[] carsTest = new Car[5];

    @BeforeEach
    void setUp() {
        carsTest[0] = new Car("BV 100", "Audi", "BVB", 2.0, "Silver");
        carsTest[1] = new Car("BV 101", "Mercedes", "BVG", 3.5, "Blue");
        carsTest[2] = new Car("BV 102", "Opel", "BSR", 1.8, "White");
        carsTest[3] = new Car("BV 103", "BMW", "RES", 2.8, "Blue");
        carsTest[4] = new Car("BV 104", "Audi", "BVB", 1.8, "White");
        for (int i = 0; i < carsTest.length; i++) {
            garage.addCar(carsTest[i]);
        }
    }

    @Test
    void addCar() {
        assertFalse(garage.addCar(null)); // нельзя добавить “пустую” машину
        assertEquals(5, garage.size());
        Car car = new Car("BV 105", "Audi", "BVB", 1.8, "White");
        assertTrue(garage.addCar(car));
        assertEquals(6, garage.size());
        car = new Car("BV 106", "Audi", "BVB", 1.8, "White");
        assertFalse(garage.addCar(car));
    }

    @Test
    void removeCar() {
        assertEquals(5, garage.size());
        assertEquals(carsTest[0], garage.removeCar("BV 100"));
        assertEquals(4, garage.size());
    }

    @Test
    void findCarByRegNumber() {
        assertEquals(carsTest[0], garage.findCarByRegNumber("BV 100"));
        assertNull(garage.findCarByRegNumber("BN 3248-ANY")); // несуществующий объект
    }

    @Test
    void findCarsByModel() {
        assertEquals(2, garage.findCarsByModel("Audi").length);
        Car[] expected = {carsTest[0], carsTest[4]};
        Car[] mod = garage.findCarsByModel("Audi");
        assertArrayEquals(expected, mod);
    }

    @Test
    void findCarsByCompany() {
        Car[] expected = {carsTest[0], carsTest[4]};
        Car[] mod = garage.findCarsByCompany("BVB");
        assertArrayEquals(expected, mod);
        assertEquals(2, garage.findCarsByCompany("BVB").length);
    }

    @Test
    void findCarsByEngine() {
        assertEquals(5, garage.findCarsByEngine(2.0, 4.0).length);
    }

    @Test
    void findCarsByColor() {
        assertEquals(2, garage.findCarsByColor("White").length);
        Car[] expected = {carsTest[2], carsTest[4]};
        Car[] mod = garage.findCarsByColor("White");
        assertArrayEquals(expected, mod);
    }
}



