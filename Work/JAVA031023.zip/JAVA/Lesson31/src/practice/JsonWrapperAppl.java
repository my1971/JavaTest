package practice;

public class JsonWrapperAppl {
    public static void main(String[] args) {
        System.out.println("-------------  Test 1 ------------------");
        JsonWrapper<String> wrapper1 = new JsonWrapper<>("1000");
        System.out.println(wrapper1);

        String a = wrapper1.getValue();
        System.out.println(a + "333");
        System.out.println("-------------  Test 2 ------------------");
        JsonWrapper<Integer> wrapper2 = new JsonWrapper<>(111);
        System.out.println(wrapper2);

        int b = wrapper2.getValue();
        System.out.println(b + 1000);

        System.out.println("-------------  Test 3 ------------------");
        JsonWrapper<Double> wrapper3 = new JsonWrapper<>(111.0);
        System.out.println(wrapper3);

        double c = wrapper3.getValue();
        System.out.println(c + 1000);


    }
}