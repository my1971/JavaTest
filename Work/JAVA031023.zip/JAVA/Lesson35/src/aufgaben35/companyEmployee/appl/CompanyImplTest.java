package aufgaben35.companyEmployee.appl;

import aufgaben35.companyEmployee.dao.Company;
import aufgaben35.companyEmployee.dao.CompanyImpl;
import aufgaben35.companyEmployee.model.Employee;
import aufgaben35.companyEmployee.model.Engineer;
import aufgaben35.companyEmployee.model.Worker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Comparator;

class CompanyImplTest {
    Company company; // создали объект класса Company
    Employee[] firm;

    @BeforeEach
    void setUp() {
        company = new CompanyImpl(); //определение массива "employees" в "CompanyImpl" вызов конструктора
        firm = new Employee[6];
        firm[0] = new Worker(100, "John", 1990, "3.kein", 5, 8, 176);
        firm[1] = new Engineer(101, "Bread", 1995, "1.higher educated", 17, 25, 176);
        firm[2] = new Worker(102, "Julia", 1980, "3.kein", 4, 8, 176);
        firm[3] = new Engineer(103, "Robert", 1998, "1.higher educated", 3, 25, 176);
        firm[4] = new Worker(104, "Peter", 2000, "2.Technikal", 20, 17, 176);
        firm[5] = new Worker(105, "Denis", 2001, "2.Technikal", 12, 17, 176);
        for (int i = 0; i < firm.length; i++) {
            company.hireEmployee(firm[i]);
        }
    }

    @Test
    void hireEmployee() {
        System.out.println(company.hireEmployee(new Engineer(106, "Make", 2004, "Student", 1, 12, 176)));
        System.out.println(company.hireEmployee(firm[0]));
        company.printEmployee("print a list of employees.напечатать список сотрудников.");
    }

    @Test
    void fireEmployee() {
        System.out.println(company.fireEmployee(105));
        System.out.println("*********************************** fire employee *************************************************");
        company.printEmployee("print a list of employees.напечатать список сотрудников.");
    }

    @Test
    void findEmployee() {
        System.out.println("************** find an employee in the list of employeesнайти работника в списке сотрудников **************");
        System.out.println(company.findEmployee(104));
        System.out.println(company.findEmployee(107));
        System.out.println("=========================================================================================================================");
    }

    @Test
    void searchEmployee() {
        System.out.println("************** search an employee in the list of employees (найти работника в списке сотрудников) **************");
        System.out.println(firm[company.searchEmployee(firm, firm[0])]);
        System.out.println("=========================================================================================================================");
    }

    @Test
    void findByPredicateT() {
        System.out.println("================== Test find Employee by Predicate Objects with more than 5 years of experience ==================");
        company.printArray(company.findByPredicateT(firm, employee -> employee.getExperience() > 5));
        System.out.println("================== Test find Employee by Predicate Objects having a salary of less than 2000 euros ==================");
        company.printArray(company.findByPredicateT(firm, employee -> employee.getHours() * employee.getRate() < 2000));
        System.out.println("================== Test find Employee by Predicate Objects do not have higher education ==================");
        company.printArray(company.findByPredicateT(firm, employee -> employee.getEducation() != "1.higher educated"));

    }

    @Test
    void sortByComparator() {
        System.out.println("================== Test sort Employee by Comparator according to the age ==================");
        Comparator<Employee> firmComparator = Comparator.comparing(Employee::getYearOfBirth);
        company.bubbleSort(firm, firmComparator);
        company.printArray(firm);
        System.out.println("================== Test sort Employee by Comparator by length of service in the company ==================");
        Comparator<Employee> firmComparator1 = Comparator.comparing(Employee::getExperience);
        company.bubbleSort(firm, firmComparator1);
        company.printArray(firm);
        System.out.println("================== Test sort Employee by Comparator in terms of salary ==================");
        Comparator<Employee> firmComparator2 = Comparator.comparing(Employee::getSalary);
        company.bubbleSort(firm, firmComparator2);
        company.printArray(firm);
        System.out.println("================== Test sort Employee by Comparator by education (higher educated at the top of the list) ==================");
        Comparator<Employee> firmComparator3 = Comparator.comparing(Employee::getEducation);
        company.bubbleSort(firm, firmComparator3);
        company.printArray(firm);

    }
}