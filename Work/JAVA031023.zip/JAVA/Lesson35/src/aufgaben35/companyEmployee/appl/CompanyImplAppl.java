package aufgaben35.companyEmployee.appl;

import aufgaben35.companyEmployee.dao.Company;
import aufgaben35.companyEmployee.dao.CompanyImpl;
import aufgaben35.companyEmployee.model.Employee;
import aufgaben35.companyEmployee.model.Engineer;
import aufgaben35.companyEmployee.model.Worker;


public class CompanyImplAppl {
    public static void main(String[] args) {


        Company company; // создали объект класса Company
        company = new CompanyImpl();
        Employee[] firm = new Employee[7];
        //firm = new Employee[14];
        firm[0] = new Worker(100, "John", 1990, "kein", 5, 16, 176);
        firm[1] = new Engineer(101, "Bread", 1995, "UNI", 17, 25, 176);
        firm[2] = new Worker(102, "Julia", 1980, "kein", 11, 12, 176);
        firm[3] = new Engineer(103, "Robert", 1998, "UNI", 15, 24, 176);
        firm[4] = new Worker(104, "Peter", 2000, "Technikal", 20, 18, 176);
        firm[5] = new Engineer(105, "Make", 2004, "Student", 1, 12, 176);
        firm[6] = new Worker(106, "Denis", 2001, "Technikal", 12, 17, 176);
        System.out.println("****************************** hire an employee (принять на работу сотрудника) ******************************");
        for (int i = 0; i < firm.length; i++) {
            company.hireEmployee(firm[i]);
        }
        System.out.println("****************************** fire an employee уволить с работы сотрудника ******************************");
        System.out.println(company.fireEmployee(106));
        company.printEmployee("список сотрудников"); // print a list of employees.напечатать список сотрудников.

        System.out.println("************** find an employee in the list of employeesнайти работника в списке сотрудников **************");
        System.out.println(company.findEmployee(104));
        System.out.println("=========================================================================================================================");
        // determine the current number of employees;определить текущее количество сотрудников;

    }
}


