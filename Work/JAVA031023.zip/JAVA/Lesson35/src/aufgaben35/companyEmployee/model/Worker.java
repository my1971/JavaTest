package aufgaben35.companyEmployee.model;

public class Worker extends Employee {


    // конструктор


    public Worker(int id, String name, Integer yearOfBirth, String education, Integer experience, Integer rate, Integer hours) {
        super(id, name, yearOfBirth, education, experience, rate, hours);
    }

    public Worker(int id) {
        super(id);
    }

    public Worker(int id, Integer rate) {
        super(id);
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "Worker   : / ID = " + id +
                ", Name = '" + name + '\'' +
                ", Year of birth = " + yearOfBirth + ", Education = '" + education + '\'' +
                ", Experience = " + experience +
                ", Hours = " + hours + ", Rate = " + rate + ", Salary = " + Salary +
                '/';
    }
}