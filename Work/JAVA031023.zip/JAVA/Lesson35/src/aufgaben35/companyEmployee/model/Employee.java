package aufgaben35.companyEmployee.model;

import java.util.Objects;

public class Employee {
    /*Task 1    Create class Emplyee with fields:
                name, yearOfBirth, experience (work experience) with standard constructors,
                getters and setters override methods toString equals

    Задание 1   Создать класс Emplyee с полями:
                name, yearOfBirth, experience (стаж работы), образование со стандартными конструкторами,
                геттерами и сететрами переопределить методы toString equals*/
    protected final int id;
    protected String name, education; // имя,  оброзование
    protected Integer yearOfBirth, experience, rate, hours, Salary; //год рождения, стаж работы, отработанные часы, ставка, зарплата


    public Employee(int id, String name, Integer yearOfBirth, String education, Integer experience, Integer rate, Integer hours) {
        this.id = id;
        this.name = name;
        this.education = education;
        this.yearOfBirth = yearOfBirth;
        this.experience = experience;
        this.rate = rate;
        this.hours = hours;

    }

    public Employee(int id) {
        this.id = id;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(Integer yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public Integer getExperience() {
        return experience;
    }

    public void setExperience(Integer experience) {
        this.experience = experience;
    }

    public Integer getHours() {
        return hours;
    }

    public void setHours(Integer hours) {
        this.hours = hours;
    }

    public Integer getSalary() {
        return Salary;
    }

    public void setSalary(Integer salary) {
        Salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", education='" + education + '\'' +
                ", yearOfBirth=" + yearOfBirth +
                ", experience=" + experience +
                ", rate=" + rate +
                ", hours=" + hours +
                ", Salary = " + Salary +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id && Objects.equals(name, employee.name) && Objects.equals(yearOfBirth, employee.yearOfBirth) && Objects.equals(education, employee.education) && Objects.equals(experience, employee.experience) && Objects.equals(hours, employee.hours);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, yearOfBirth, education, experience, hours);
    }
}
