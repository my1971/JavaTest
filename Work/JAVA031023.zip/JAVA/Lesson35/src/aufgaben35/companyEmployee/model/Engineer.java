package aufgaben35.companyEmployee.model;

public class Engineer extends Employee {


    // конструктор


    public Engineer(int id, String name, Integer yearOfBirth, String education, Integer experience, Integer rate, Integer hours) {
        super(id, name, yearOfBirth, education, experience, rate, hours);
    }


    public Engineer(int id) {
        super(id);
    }

    public Engineer(int id, Integer rate) {
        super(id);
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "Engineer : / ID = " + id +
                ", Name = '" + name + '\'' +
                ", Year of birth=" + yearOfBirth + ", Education = '" + education + '\'' +
                ", Experience = " + experience +
                //   ", Hours = " + hours + ", Rate = " + rate + ", Salary = " + (rate * hours) +
                ", Hours = " + hours + ", Rate = " + rate + ", Salary = " + Salary +
                '/';
    }
}