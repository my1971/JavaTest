package aufgaben35.companyEmployee.dao;

import aufgaben35.companyEmployee.model.Employee;

import java.util.Comparator;
import java.util.function.Predicate;

public interface Company extends Comparable<Company> {
    /*    Task 2 Create interface Company, in which to set abstract methods:
            -   hire an employee
            -   fire an employee
            -   find an employee in the list of employees
            -   determine the current number of employees;
            -   print a list of employees.
    Задание 2 Создать интерфейс Company, в котором задать абстрактные методы:
            -   принять на работу сотрудника
            -   уволить с работы сотрудника
            -   найти работника в списке сотрудников
            -   определить текущее количество сотрудников;
            -   напечатать список сотрудников.*/
    boolean hireEmployee(Employee employee); // принять на работу сотрудника в компанию

    Employee fireEmployee(int id); //уволить с работы сотрудника из компании

    // найти сотрудника по его ID
    Employee findEmployee(int id); //найти работника в списке сотрудников компании

    //размер компании
    int size(); //определить текущее количество сотрудников;

    // печатаем список
    void printEmployee(String title); //напечатать список сотрудников

    // Tools
    int searchEmployee(Object[] arr, Object value); // поиск объекта в массиве Объектов

    void printArray(Object[] arr);

    <T> T[] findByPredicateT(T[] arr, Predicate<T> predicate); // поиск объекта по условию

    <T extends Comparable<T>> void bubbleSort(T[] arr); //bubbleSort

    <T> void bubbleSort(T[] arr, Comparator<T> comparator); //bubbleSorts by Comparator

}
