package aufgaben35.companyEmployee.dao;

import aufgaben35.companyEmployee.model.Employee;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;

public class CompanyImpl implements Company {
    private Employee[] employees;
    private int size = 0;

    // конструктор (CompanyImpl), т.к. совпадает с именем класса. получает capacity  и становится длиной массива
    public CompanyImpl() {
        employees = new Employee[0];
    }

    @Override
    public boolean hireEmployee(Employee employee) {
        if (employee == null || findEmployee(employee.getId()) != null) return false;
        Employee[] employeesCopy = Arrays.copyOf(employees, employees.length + 1);
        employeesCopy[size] = employee;
        Integer d = employeesCopy[size].getRate() * employeesCopy[size].getHours();
        employeesCopy[size++].setSalary(d);
        employees = employeesCopy;
        return true;
    }

    @Override
    public Employee fireEmployee(int id) {
        for (int i = 0; i < employees.length; i++) {
            if (employees[i].getId() == id) {
                Employee remove = employees[i];
                size--;
                employees[i] = employees[size];
                Employee[] employeesCopy = Arrays.copyOf(employees, employees.length - 1);
                employees = employeesCopy;
                return remove;
            }
        }
        return null;
    }

    @Override
    public Employee findEmployee(int id) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getId() == id) {
                return employees[i];
            }
        }
        return null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void printEmployee(String title) {
        System.out.println("========================= " + title + "=========================");
        for (int i = 0; i < employees.length; i++) {
            if (employees[i] != null) {
                System.out.println(employees[i]);
            }
        }
        System.out.println("=========================================================================================================================");
    }

    // поиск объекта в массиве Объектов
    public int searchEmployee(Object[] arr, Object value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(value)) {
                return i;
            }
        }
        return -1; // несуществующий индекс
    }

    public void printArray(Object[] arr) {
        for (Object o : arr) {
            System.out.println(o);
        }
        System.out.println("==============================================================================");
    }

    // поиск объекта по условию
    public <T> T[] findByPredicateT(T[] arr, Predicate<T> predicate) {
        //Метод возвращает тип Т[], из массива типа Т[], отбор по предикату
        int count = 0;// Счетчик найденных элементов'
        T[] existingT = Arrays.copyOf(arr, arr.length);// Создаем временный массив для хранения
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                existingT[count++] = arr[i]; // добавляем данные в массив
            }
        }
        return Arrays.copyOf(existingT, count);
    }

    //bubbleSort
    public <T extends Comparable<T>> void bubbleSort(T[] arr) {
        // этот метод применим к типам (классам), в которых есть Comparable<T>
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // перестановка массива местами
                    T t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
    }

    //bubbleSorts by Comparator
    public <T> void bubbleSort(T[] arr, Comparator<T> comparator) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (comparator.compare(arr[j], arr[j + 1]) > 0) {
                    T t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
    }

    @Override
    public int compareTo(Company o) {
        return 0;
    }
}
