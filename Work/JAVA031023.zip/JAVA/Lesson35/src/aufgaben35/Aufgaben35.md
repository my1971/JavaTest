Задание 1 Повторить операции (тесты) в нашем занятии с классом Cat (можно взять Car, или свой класс).
Комплексное задание (до пятницы)
Task 1 Create class Emplyee with fields:
name, yearOfBirth, experience (work experience) with standard constructors,
getters and setters override methods toString equals

Задание 1 Создать класс Emplyee с полями:
name, yearOfBirth, experience (стаж работы), образование со стандартными конструкторами,
геттерами и сететрами переопределить методы toString equals

Task 2 Create interface Company, in which to set abstract methods:
- hire an employee
- fire an employee
- find an employee in the list of employees
- determine the current number of employees;
- print a list of employees.
Задание 2 Создать интерфейс Company, в котором задать абстрактные методы:
- принять на работу сотрудника
- уволить с работы сотрудника
- найти работника в списке сотрудников
- определить текущее количество сотрудников;
- напечатать список сотрудников.

Task 3 Create child classes from Employee
- Engineer()
- worker() implement payroll methods in them (rate * hours).
Задание 3 Создать дочерние классы от Employee
- Engineer ()
- Worker () реализовать в них методы начисления зарплаты (ставка * часы).

Task 4 Create a CompanyImpl class that implements the Company interface and implement methods in it parent class.
Задание 4 Создать класс CompanyImpl, реализующий интерфейс Company, и имплементировать в нем методы родительского
класса.

Task 5 Implement methods for searching employees by criteria:
- with more than 5 years of experience
- having a salary of less than 2000 euros
- do not have higher education
Задание 5 CompanyImpl реализовать методы для поиска сотрудников по критериям:
- имеющих стаж более 5 лет
- имеющих зарплату менее 2000 евро
- не имеющих высшее образование

Task 6 Create comparators and get sorted employee lists:
- according to the age
- by length of service in the company
- in terms of salary
- by education (higher educated at the top of the list)
Задание 6 Создать компараторы и получить отсортированные списки сотрудников:
- по возрасту
- по стажу работы в компании
- по величине зарплаты
- по образованию (выше образованные в начале списка)

Последнее задание - реализовать в тестах.



