package practice31.company_employee28.appl;

import practice31.company_employee28.dao.Company;
import practice31.company_employee28.dao.CompanyImpl;
import practice31.company_employee28.model.Employee;
import practice31.company_employee28.model.Manager;
import practice31.company_employee28.model.SalesManager;
import practice31.company_employee28.model.WageEmployee;

public class CompanyImplAppl {
    public static void main(String[] args) {


        Company company; // создали объект класса Company
        company = new CompanyImpl(5);
        Employee[] firm = new Employee[5];
        //firm = new Employee[14];
        firm[0] = new Manager(100, "John", "Smith", 174, 5000, 5);
        firm[1] = new SalesManager(101, "Bread", "Pitt", 174, 300000, 0.1);
        firm[2] = new SalesManager(102, "Julia", "Roberts", 174, 300000, 0.1);
        firm[3] = new WageEmployee(103, "Robert", "Robert", 80, 20);
        firm[4] = new SalesManager(186, "Peter", "Petrov", 180, 40000, 0.1);
        company.addEmployee(firm[0]);
        company.addEmployee(firm[1]);
        company.addEmployee(firm[2]);
        company.addEmployee(firm[3]);
        company.addEmployee(firm[4]);
        company.addEmployee(firm[4]);
        company.printEmployee();

    }
}


