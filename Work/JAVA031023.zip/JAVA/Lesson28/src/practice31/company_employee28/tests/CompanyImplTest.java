package practice31.company_employee28.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice31.company_employee28.dao.Company;
import practice31.company_employee28.dao.CompanyImpl;
import practice31.company_employee28.model.Employee;
import practice31.company_employee28.model.Manager;
import practice31.company_employee28.model.SalesManager;
import practice31.company_employee28.model.WageEmployee;

import static org.junit.jupiter.api.Assertions.*;

public class CompanyImplTest {

    Company company = new CompanyImpl(5);
    // создали объект класса Company
    Employee[] firm = new Employee[5];

    @BeforeEach
    void setUp() {
        //company = new CompanyImpl(15);
        firm[0] = new Manager(100, "John", "Smith", 174, 5000, 5);
        firm[1] = new SalesManager(101, "Bread", "Pitt", 174, 300000, 0.1);
        firm[2] = new SalesManager(102, "Julia", "Roberts", 174, 300000, 0.1);
        firm[3] = new WageEmployee(103, "Robert", "Robert", 80, 20);
        firm[4] = new SalesManager(186, "Peter", "Petrov", 180, 40000, 0.1);
    }

    @Test
    void addEmployee() {
        assertFalse(company.addEmployee(null)); // нельзя добавить “пустого” сотрудника
        assertTrue(company.addEmployee(firm[0])); // можно добавить сотрудника
        assertTrue(company.addEmployee(firm[1])); // можно добавить сотрудника
        assertTrue(company.addEmployee(firm[2])); // можно добавить сотрудника
        assertTrue(company.addEmployee(firm[3])); // можно добавить сотрудника
        assertEquals(4, company.size());
        Employee employee = new SalesManager(186, "Peter", "Petrov", 180, 40000, 0.1);
        assertTrue(company.addEmployee(employee));
        assertEquals(5, company.size());
        assertFalse(company.addEmployee(firm[3]));// нельзя добавить уже имеющегося сотрудник
        employee = new SalesManager(186, "Peter", "Petrov", 180, 40000, 0.1);
        assertFalse(company.addEmployee(employee)); //нельзя выйти за размер компании
    }

    @Test
    void removeEmployee() {
    }

    @Test
    void findEmployee() {
    }

    @Test
    void size() {
    }

    @Test
    void printEmployees() {
    }
}