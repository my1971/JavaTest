# title 1

## title 2

Task 1. Make tests for Shape class methods.
Задча 1. Сделать тесты для методов класса Shape. (Lesson 26)

Task 2. Make tests for methods from the task of finding duplicates in an array. (Lesson 27)
Задача 2. Сделать тесты для методов из задачи о поиске дубликатов в массиве
.
Задача 3. Продолжить разработку тестов для CompanyImpl. (Lesson 28)


