public class Aufgaben12_1 {
    public static void main(String[] args) {
        /*  Задача 1 Собрать в массив данные о дневной температуре в вашем городе да прошедшую неделю.
            Выведите на печать температуру, которая была во вторник и затем в четверг. Найти среднюю
            температуру за прошлую неделю. */
        System.out.println("Temperature last week");
        int[] temperature = {20, 18, 15, 23, 25, 23, 26};
        System.out.println("1) Temperature on tuesday : " + temperature[1]);
        System.out.println("2) Temperature on thursday : " + temperature[3]);
        int average = 0;
        for (int i = 0; i < temperature.length; i++) {
            average = average + temperature[i];
        }
        System.out.println("3) Average temperature per week : " + (average / 7));
    }
}
