package aufgaben;

import java.util.Scanner;

public class Aufgabe22_2 {
    public static void main(String[] args) {
/*Task 2. (cycle) A unicellular amoeba divides into 2 similar amoeba every 3 hours. It is necessary to determine how many
        amoebas will be after n hours, if initially there were only one amoeba.
Задача 2. (цикл) Одноклеточная амёба каждые 3 часа делится на 2 такие же амёбы. Необходимо определить, сколько будет амёб
        через n часов, если первоначально была только одна амёба.*/

        Scanner scanner = new Scanner(System.in);
        System.out.print("Input quantity hours: ");
        long n = scanner.nextLong(), quan = 1, i = 1;;
        while ((n / 3) >= i){
            if ((quan * 2) > 0){
                quan = quan * 2;
                System.out.println(i + "----------" + quan);
                i++;
            }else {
                //9 223 372 036 854 775 807
                System.out.println("the summ is too big");
                break;
            }
        }
        System.out.println("In " + n + " hours a unicellular amoeba divides into " + quan + " similar");
    }
}
