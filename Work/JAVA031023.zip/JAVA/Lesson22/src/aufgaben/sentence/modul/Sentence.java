package aufgaben.sentence.modul;
public class Sentence {
    private String sentence;
    public Sentence(String sentence) {
        setWords(sentence);
        setLette(sentence);
    }
    public void setWords(String sentence) {
        String[] words = sentence.split(" ");
        int quantity = 0;
        for (int i = 0; i <words.length ; i++) {
            String word = "";
            for (int j = 0; j < words[i].length(); j++) {
                char c = words[i].charAt(j);
                if (((c >= 'А' && c <= 'Я') || (c >= 'а' && c <= 'я') || (c >= '0' && c <= '9'))){
//                    if (c > " "){
//
//                    }
                    word = word + c;
                }
            }
            if (!(word == null)){
                quantity++;
            }
            words[i] = word;
            System.out.println(words[i]);
        }
        System.out.println("Quantity of words = " + quantity);
    }
    public void setLette(String sentence) {
        int quantity = 0;
        for (int i = 0; i <sentence.length() ; i++) {
            char c = sentence.charAt(i);
            if (((c >= 'А' && c <= 'Я') || (c >= 'а' && c <= 'я') || (c >= '0' && c <= '9'))){
                quantity++;
            }
        }
        System.out.println("Quantity of letter = " + quantity);
    }
}


