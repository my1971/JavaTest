package aufgaben;

import java.util.Scanner;

public class Aufgabe22_3 {
    public static void main(String[] args) {
/*Task 3. (switch case, infinite loop, methods) Write a program to convert measures of length:
        -   fathoms to meters (1 fathom is equal to 2.1366 m)
        -   inches to centimeters (1 inch equals 2.5 cm)
        -   feet to meters (1 foot equals 0.3048 m)
        -   arshins to meters (1 arshin is equal to 0.7112 m)
        -   inches to millimeters (1 inch equals 25.3995 mm)
Задача 3. (switch case, бесконечный цикл, методы) Составьте программу для перевода мер длины:
        -   саженей в метры (1 сажень равна 2,1366 м)
        -   дюймов в сантиметры (1 дюйм равен 2,5 см)
        -   футов в метры (1 фут равен 0,3048 м)
        -   аршинов в метры (1 аршин равен 0,7112 м)
        -   дюймов в миллиметры (1 дюйм равен 25,3995 мм)*/
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("what do you want to calculate?");
            System.out.println("---------------------------------");
            System.out.println("1) саженей в метры (1 сажень равна 2,1366 м)");
            System.out.println("2) дюймов в сантиметры (1 дюйм равен 2,5 см)");
            System.out.println("3) футов в метры (1 фут равен 0,3048 м)");
            System.out.println("4) аршинов в метры (1 аршин равен 0,7112 м)");
            System.out.println("5) дюймов в миллиметры (1 дюйм равен 25,3995 мм)");
            System.out.print("Input number menu: ");
            int menu = scanner.nextInt();
            System.out.println("----------------------------------------------------");
            switch (menu) {
                case 1:
                    fathomsMeters();
                    break;
                case 2:
                    inchСentimeter();
                    break;
                case 3:
                    feetMeters();
                    break;
                case 4:
                    arshinsMeters();
                    break;
                case 5:
                    inchesMillimeters();
                    break;
                default:
                    break;
            }
            System.out.println("Continie? y/n");
            String choice = scanner.next();
            if (!choice.equals("y") & !choice.equals("Y")) {
                System.out.println("Thanks? bye!");
                break;
            }
        }
    }
    public static void fathomsMeters() {

        System.out.println("перевод саженей в метры (1 сажень равна 2,1366 м)");
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------------");
        System.out.print("Input value: ");
        double n = scanner.nextDouble();
        if (n >= 0) {
            System.out.println("Результат: " + n + " сажен. = " + (n * 2.1366) + " м.");
        } else {
            System.out.println(" Недопустимое значение");
        }
        System.out.println("----------------------------------------------------");
    }
    public static void inchСentimeter() {
        System.out.println("перевод дюймов в сантиметры (1 дюйм равен 2,5 см)");
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------------");
        System.out.print("Input value: ");
        double n = scanner.nextDouble();
        if (n >= 0) {
            System.out.println("Результат: " + n + " дюйм. = " + (n * 2.5) + " сантиметр.");
        } else {
            System.out.println(" Недопустимое значение");
        }
        System.out.println("----------------------------------------------------");
    }
    public static void feetMeters() {
        System.out.println("перевод футов в метры (1 фут равен 0,3048 м)");
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------------");
        System.out.print("Input value: ");
        double n = scanner.nextDouble();
        if (n >= 0) {
            System.out.println("Результат: " + n + " фут. = " + (n * 0.3048) + " м.");
        } else {
            System.out.println(" Недопустимое значение");
        }
        System.out.println("----------------------------------------------------");
    }
    public static void arshinsMeters() {
        System.out.println("перевод аршинов в метры (1 аршин равен 0,7112 м)");
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------------");
        System.out.print("Input value: ");
        double n = scanner.nextDouble();
        if (n >= 0) {
            System.out.println("Результат: " + n + " аршин. = " + (n * 0.7112) + " м.");
        } else {
            System.out.println(" Недопустимое значение");
        }
        System.out.println("----------------------------------------------------");
    }

    public static void inchesMillimeters() {
        System.out.println("перевод дюймов в миллиметры (1 дюйм равен 25,3995 мм)");
        Scanner scanner = new Scanner(System.in);
        System.out.println("----------------------------------------------------");
        System.out.print("Input value: ");
        double n = scanner.nextDouble();
        if (n >= 0) {
            System.out.println("Результат: " + n + " дюйм. = " + (n * 25.3995) + " мм.");
        } else {
            System.out.println(" Недопустимое значение");
        }
        System.out.println("----------------------------------------------------");
    }
}

