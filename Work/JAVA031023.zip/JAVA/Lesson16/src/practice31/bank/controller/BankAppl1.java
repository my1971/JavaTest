package practice31.bank.controller;

import practice31.bank.model.BankAccount1;


public class BankAppl1 {
    public static void main(String[] args) {
        BankAccount1 book1 = new BankAccount1("Название", "Автор книги", 2000, 1000000000);
        BankAccount1 book2 = new BankAccount1("Название2", "Автор книги2", 2000, 1000000002);
        BankAccount1 book3 = new BankAccount1("Название3", "Автор книги3", 2000, 1000000003);
        book1.display();
        book2.display();
        book3.display();
        BankAccount1 book4 = new  BankAccount1("Название4", "Автор книги3", 94, 1000000004);
        book4.display();
        book4.setYear(900);
        book4.display();
    }
}
