package aufgaben;

public class Aufgabe16_3 {
    public static void main(String[] args) {
/* Task 3. ()* Form an array that stores the names of the days of the week, provided that the first The working day
    of the week is Monday and the last day is Sunday. Redefine this array so that the first working day
    of the week is Sunday and the last one is Saturday.
---------------------------------------------------------------------------------------------------------------
Задача 3. ()* Сформируйте массив, который хранит названия дней недели при условии, что первый рабочий день
    недели - это Понедельник, а последний - Воскресенье. Переопределите этот массив так, чтобы первым
    рабочим днем недели стало Воскресенье, а последним - Суббота.
*/
        String[] arr =  {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        System.out.println("-----------------------------------------------------------------------");
        for (int i = 0; i < arr.length; i++) {System.out.print(arr[i] + " / ");}
        System.out.println(" ");
        String x = arr[arr.length - 1];
        for (int i = arr.length - 1; i > 0; i--) {arr[i] = arr[i-1];}
        arr[0] = x;
        for (int i = 0; i < arr.length; i++) {System.out.print(arr[i] + " / ");}
        System.out.println(" ");
        System.out.println("-----------------------------------------------------------------------");

   }
}
