package aufgaben.book.model;
public class Book {
/*    *Task 1. Create class Book in package xxx.book.model. Define the fields in this class: private long isbn;
    private String title; private String author; private int yearOfPublishing; Create constructors to
    initialize all fields, and a constructor to initialize fields when absence of the author. Other constructors
    are up to you. Create getters and setters, based on logic and necessity. Create a public void display()
    method to print information about the book to the console.
    Create class BookAppl in package xxx.book with main method. In the main method, create several instances
    of Book and print the result for each of them the operation of the display method.
   ---------------------------------------------------------------------------------------------------------------
    Задача 1. Создать класс Book в пакете xxx.book.model. В этом классе определить поля: private long isbn;
    private String title; private String author; private int yearOfPublishing; Создать конструкторы для
    иницализации всех полей, и конструктор для инициализации полей при отсутствии автора. Остальные конструкторы
    на Ваше усмотрение. Создать геттеры и сеттеры, исходя из логики и необходимости. Создать метод
    public void display() для печати в консоль информации о книге.
    Создать класс BookAppl в пакете xxx.book с методом main. В методе main создать несколько экземпляров
    Book и вывести для каждого из них результат работы метода display.*/

    private String title, author;//название - title и автор - author
    private int yearOfPublishing;
    private long isbn; //уникальный номер - ISBN

    //methods Class Book
    public void display(){
        if (title != null){System.out.print("Title - " + title + " /");}
        if (author != null){System.out.print("Account - " + author + " /");}
        if (yearOfPublishing >0){System.out.print("Year of publishing - " + yearOfPublishing+ " /");}
        if (isbn>0){System.out.print("ISBN - " + isbn+ " /");}
        System.out.println(" ");
    }
    // Generate / Constructor / Getters und Setters
    public Book(String title, String author, int yearOfPublishing, long isbn) {
        this.title = title;
        this.author = author;
        this.yearOfPublishing = yearOfPublishing;
        this.isbn = isbn;
    }
    public Book(String title, String author, long isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }
    public Book(String title, String author, int yearOfPublishing) {
        this.title = title;
        this.author = author;
        this.yearOfPublishing = yearOfPublishing;
    }

    public String getTitle() {return title;}
    public void setTitle(String title) {this.title = title;}
    public String getAuthor() {return author;}
    public void setAuthor(String author) {this.author = author;}
    public int getYearOfPublishing() {return yearOfPublishing;}
    public void setYearOfPublishing(int yearOfPublishing) {this.yearOfPublishing = yearOfPublishing;}
    public long getIsbn() {return isbn;}
    public void setIsbn(long isbn) {this.isbn = isbn;}
}
