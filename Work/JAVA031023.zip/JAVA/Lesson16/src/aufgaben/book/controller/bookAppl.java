package aufgaben.book.controller;
import aufgaben.book.model.Book;

public class bookAppl {
    public static void main(String[] args) {
        Book book1 = new Book("Название", "Автор книги", 2000, 1000000001L);
        Book book2 = new Book("Название2", "Автор книги2", 1000000001L);
        Book book3 = new Book("Название3", "Автор книги3", 2000);
        book1.display();
        book2.display();
        book3.display();
    }
}
