package aufgaben;

public class Aufgabe16_2 {
    public static void main(String[] args) {
/* Task 2. Given an array of integers {-5, 17, 23, -30, 22, 18, -3, 77, 19, -2}. Find the average value
    over all array elements with even indexes.
---------------------------------------------------------------------------------------------------------------
Задача 2. Задан массив целых чисел {-5, 17, 23, -30, 22, 18, -3, 77, 19, -2}. Найдите среднюю величину
    по всем элементам массива с четными индексами.*/
        int[] arr =  {-5, 17, 23, -30, 22, 18, -3, 77, 19, -2};
        int x = 0, a = 0;
        for (int i = 0; i < arr.length; i++) {
            if (i % 2 == 0){
                x += arr[i];
                a++;
            }
        }
        System.out.println("---------------------------------------------------------------------");
        System.out.println("The average value over all array elements with even indexes is - " + (double) x/a);
        System.out.println("---------------------------------------------------------------------");
   }
}
