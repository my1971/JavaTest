package aufgaben42.consultation;

import java.util.Arrays;

public class ArrayCopyTest {
    public static void main(String[] args) {
        int[] arrayInt = new int[10];
        for (int i = 0; i < arrayInt.length; i++) {
            arrayInt[i] = (i + 1) * 10;
        }
        int intAdd = 85;
        System.out.println(Arrays.toString(arrayInt));
        int index = Arrays.binarySearch(arrayInt, intAdd);
        System.out.println(index);
        index = index >= 0 ? index : -index - 1;
        System.out.println(index);
        /* System.arraycopy(исходныйМассив, начальныйИндексИсходного, целевойМассив,
        начальныйИндексЦелевого, количествоЭлементов);
        исходныйМассив: массив, из которого вы хотите скопировать данные.
        начальныйИндексИсходного: индекс начального элемента в исходном массиве, с которого начнется копирование.
        целевойМассив: массив, в который вы хотите скопировать данные.
        начальныйИндексЦелевого: индекс начального элемента в целевом массиве, куда начнется копирование.
        количествоЭлементов: количество элементов, которые вы хотите скопировать*/
        int[] arrayIntCopy = new int[arrayInt.length + 1];

        System.arraycopy(arrayInt, 0, arrayIntCopy, 0, arrayInt.length);
        System.out.println(Arrays.toString(arrayIntCopy));
        System.arraycopy(arrayInt, index, arrayIntCopy, index + 1, arrayIntCopy.length - index - 1);
        arrayIntCopy[index] = intAdd;
        System.out.println(Arrays.toString(arrayIntCopy));


//
//        int index = Arrays.binarySearch(photos, 0, size, photo, comparator); //нашли место куда надо вставть фото
//        index = index >= 0 ? index : -index - 1;
//        System.arraycopy(photos, index, photos, index + 1, size - index);
//        photos[index] = photo;
//        size++;
//
    }
}
