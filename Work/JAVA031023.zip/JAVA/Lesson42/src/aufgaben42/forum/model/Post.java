package aufgaben42.forum.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Post implements Comparable<Post> {
    private final int postID;
    private String title;
    private String author;
    private String content;
    private LocalDateTime date;
    private int likes;
    // constructor


    public Post(int postID, String title, String author, String content, LocalDateTime date, int likes) {
        this.postID = postID;
        this.title = title;
        this.author = author;
        this.content = content;
        this.date = date;
        this.likes = likes;
    }

    //Getter und Setter


    public int getPostID() {
        return postID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    @Override
    public String toString() {
        return "Post{" +
                "postID=" + postID +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", likes=" + likes +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Post photo = (Post) o;
        return postID == photo.postID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(postID);
    }

    @Override
    public int compareTo(Post o) {
        return Integer.compare(postID, o.postID);
    }

    //***************  End Class **********************************
}
