package aufgaben42.forum.appl;


import aufgaben42.forum.dao.ForumImpl;
import aufgaben42.forum.model.Post;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class ForumImplTest {

    ForumImpl postsT;
    LocalDateTime now = LocalDateTime.now();
    Post[] ps = new Post[9];

    @BeforeEach
    void setUp() {

        postsT = new ForumImpl(0);
        ps[0] = new Post(100, "title1", "Author1", "content1", postsT.inDateTime("1/10/23"), 10);
        ps[1] = new Post(101, "title2", "Author2", "content2", postsT.inDateTime("1/12/22"), 10);
        ps[2] = new Post(102, "title3", "Author3", "content3", postsT.inDateTime("1/3/21"), 10);
        ps[3] = new Post(103, "title4", "Author1", "content4", postsT.inDateTime("1/5/22"), 10);
        ps[4] = new Post(104, "title5", "Author1", "content5", postsT.inDateTime("1/6/21"), 10);
        ps[5] = new Post(105, "title6", "Author6", "content6", postsT.inDateTime("1/7/23"), 10);
        ps[6] = new Post(106, "title6", "Author6", "content6", postsT.inDateTime("1/7/23"), 10);
        ps[7] = new Post(107, "title6", "Author6", "content6", postsT.inDateTime("1/7/23"), 10);
        ps[8] = new Post(108, "title6", "Author6", "content6", postsT.inDateTime("1/7/23"), 10);

        for (int i = 0; i < ps.length; i++) {
            postsT.addPost(ps[i]);
        }

    }

    @Test
    void addPhotoTest() {
        assertFalse(postsT.addPost(null)); // добавление пустого фото
        assertFalse(postsT.addPost(ps[1])); // добавление имеющегося
        Post postost = new Post(109, "title7", "Author7", "content7", postsT.inDateTime("1/1/23"), 10);
        assertTrue(postsT.addPost(postost));
        assertEquals(10, postsT.size());
        System.out.println(postsT.size());
        postsT.display();
    }

    @Test
    void removePhoto() {
        assertFalse(postsT.removePost(8)); // не можем удалить несуществующее фото
        assertTrue(postsT.removePost(105));
        assertEquals(8, postsT.size());
        System.out.println(postsT.size());

    }

    @Test
    void updatePhoto() {
        assertTrue(postsT.updatePost(101, "NewContens"));
        assertEquals("NewContens", postsT.getPostById(101).getContent());
        System.out.println(postsT.getPostById(101));
    }

    @Test
    void getPostByAuthor() {
        Post[] expected = {ps[4], ps[3], ps[0]};
        Post[] actual = postsT.getPostByAuthor("Author1");
        for (int i = 0; i < actual.length; i++) {
            System.out.println(actual[i]);
        }
        assertArrayEquals(expected, actual);

    }

    @Test
    void getPostByAuthorDate() {
        Post[] actual = postsT.getPostByAuthor("Author1", postsT.inDate("1/05/21"), postsT.inDate("1/12/22"));
        Arrays.sort(actual);
        Post[] expected = {ps[3], ps[4]};
        assertArrayEquals(expected, actual);
        for (int i = 0; i < actual.length; i++) {
            System.out.println(actual[i]);
        }
    }

    @Test
    void size() {
        assertEquals(9, postsT.size());
    }
}