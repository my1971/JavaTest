package aufgaben42.forum.dao;

import aufgaben42.forum.model.Post;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;

public class ForumImpl implements Forum {
    Comparator<Post> comparator = (p1, p2) -> {
        int res = p1.getDate().compareTo(p2.getDate());
        return res != 0 ? res : Integer.compare(p1.getPostID(), p2.getPostID());
    };
    //поля
    private Post[] posts; // это массив объектов типа Post[]
    private int size;

    // конструктор
    public ForumImpl(int Capacity) {
        posts = new Post[Capacity];
    }

    @Override
    public boolean addPost(Post post) {
        if (post == null || getPostById(post.getPostID()) != null) return false;
        posts = Arrays.copyOf(posts, posts.length + 1);
        int index = Arrays.binarySearch(posts, 0, size, post, comparator); //нашли место куда надо вставть post
        index = index >= 0 ? index : -index - 1;
        System.arraycopy(posts, index, posts, index + 1, (size++) - index);
        posts[index] = post;
        return true;
    }

    @Override
    public boolean removePost(int postID) {
        for (int i = 0; i < size; i++) {
            if (posts[i].getPostID() == postID) {
                System.arraycopy(posts, i + 1, posts, i, --size - i);
                posts = Arrays.copyOf(posts, size);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean updatePost(int postID, String content) {
        Post photo = getPostById(postID);
        if (photo == null) return false;
        photo.setContent(content);
        return true;
    }

    @Override
    public Post getPostById(int postID) {
        Post pattern = new Post(postID, null, null, null, null, 0);
        for (int i = 0; i < size; i++) {
            if (pattern.equals(posts[i])) return posts[i];
        }
        return null;
    }

    @Override
    public Post[] getPostByAuthor(String author) {
        Post[] res = new Post[size];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (posts[i].getAuthor() == author) res[j++] = posts[i];
        }
        return Arrays.copyOf(res, j); // копируем только ту часть, где нет null
    }

    @Override
    public Post[] getPostByAuthor(String author, LocalDate dateFrom, LocalDate dateTo) {
        return findByPredicate(p -> p.getAuthor() == author && !p.getDate().toLocalDate().isBefore(dateFrom)
                && !p.getDate().toLocalDate().isAfter(dateTo));
    }

    private Post[] findByPredicate(Predicate<Post> predicate) {
        Post[] res = new Post[size];
        int j = 0;
        for (int i = 0; i < size; i++) {
            if (predicate.test(posts[i])) res[j++] = posts[i];
        }
        return Arrays.copyOf(res, j); // копируем только ту часть, где нет null
    }

    public LocalDateTime inDateTime(String date) {
        return (date == null || date.trim() == "") ? (LocalDateTime.now()) : (LocalDateTime.of(LocalDate.parse(date,
                DateTimeFormatter.ofPattern("[yyyy/M/d][yyyy.M.d][yyyy-M-d][yyyy:M:d][d-M-yy][d.M.yy][d/M/yy][d:M:yy]")), LocalTime.now()));
    }

    public LocalDate inDate(String date) {
        return (date == null || date.trim() == "") ? (LocalDate.now()) : (LocalDate.parse(date,
                DateTimeFormatter.ofPattern("[yyyy/M/d][yyyy.M.d][yyyy-M-d][yyyy:M:d][d-M-yy][d.M.yy][d/M/yy][d:M:yy]")));
    }

    @Override
    public int size() {
        return size;
    }

    public void display() {
        for (int i = 0; i < posts.length; i++) {
            System.out.println(posts[i]);
        }
    }
}
