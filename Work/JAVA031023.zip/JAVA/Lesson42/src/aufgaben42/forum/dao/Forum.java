package aufgaben42.forum.dao;

import aufgaben42.forum.model.Post;

import java.time.LocalDate;

public interface Forum {
    boolean addPost(Post Post);

    boolean removePost(int postID);

    boolean updatePost(int postID, String content);

    Post getPostById(int postID);

    Post[] getPostByAuthor(String author);

    Post[] getPostByAuthor(String autor, LocalDate dateFrom, LocalDate dateTo);

    int size();
}
