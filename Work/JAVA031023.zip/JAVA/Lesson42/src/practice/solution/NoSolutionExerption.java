package practice.solution;

public class NoSolutionExerption extends Exception {

}
