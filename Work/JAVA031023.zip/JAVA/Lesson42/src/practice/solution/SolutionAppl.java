package practice.solution;

public class SolutionAppl {
    public static void main(String[] args) {

        // a * x = b, x = b / a
        int a = 15;
        int b = 0;
        try {
            int x = solution(a, b);
            System.out.println("X = " + x);

        } catch (NoSolutionExerption e) {
            System.out.println(e.getMessage());
            System.out.println(" a can`t be equal 0.");
        } catch (AnyNumberSolution i) {
            System.out.println("AnyNumber is solution");

        } finally {
            System.out.println("Buy, buy!");
        }

    }

    public static int solution(int a, int b) throws NoSolutionExerption {
        int res;
        if (a == 0 && b != 0) {
            throw new NoSolutionExerption();
        }
        if (a == 0 && b == 0) {
            throw new AnyNumberSolution();
        }

        int x = b / a;
        return x;
    }
}
