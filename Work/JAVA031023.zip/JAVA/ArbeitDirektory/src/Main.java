import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        LaunchPage launchPage = new LaunchPage();
       //окно сообщений
        JOptionPane.showMessageDialog(null,
                "The number cannot be: [] is not correct",
                "Error",
                JOptionPane.ERROR_MESSAGE);

    }
}
/* здесь будут все рабочие моменты


 */