import javax.swing.*;
import java.awt.*;
import java.util.Scanner;


public class Aufgabe42 {
     public static void main(String[] args) throws Exception {
        JFrame frame = new JFrame();
        metodWindows("является ли год високосным",0, frame);
        metodWindows("Введите год : ",30, frame);

        JTextField perYearText = new JTextField(); //создаем обьект поле Ввода текста
        perYearText.setBounds(185,70,170,30);
        frame.add(perYearText); //добавляем поле Ввода в окно JFrame

         String pername = JOptionPane.showInputDialog("Ваше имя: ");
         JOptionPane.showMessageDialog(null, pername );
    //     int perYear = Integer.parseInt (perYearText);


//         if (perYear %100==0 && perYear %400 ==0 ){
//             System.out.println("количество дней в году: 366");
//         } else if (perYear % 4 == 0 && perYear % 100 > 0){
//             System.out.println("количество дней в году: 366");
//         } else if (perYear % 100 == 0){
//             System.out.println("количество дней в году: 365");
//         } else {
//             System.out.println("количество дней в году: 365");
//         };

//-------------------------------------------
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.setSize(1150,500);
         frame.setLayout(null);
         frame.setVisible(true);
//-------------------------------------------
// -----messege window-----------------------
        JOptionPane.showMessageDialog(null,
                "entered year: [" + pername + "]",
                "Message",
                JOptionPane.CANCEL_OPTION);
//-------------------------------------------
//Создаем поле Ввода текста
   }
    public static int metodWindows (String perLine, int perL, JFrame frame){
        JLabel label = new JLabel(perLine); // определяется строка для вывода на экран
        label.setBounds(20,perL,1400,100);
        label.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label);  // Вывод на экран
        return 0;
    }
}