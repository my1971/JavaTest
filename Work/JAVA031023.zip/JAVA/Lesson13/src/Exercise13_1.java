public class Exercise13_1 {
    public static void main(String[] args) {
        //Задача 1. Имеются оценки абитуриента из его аттестата, всего 12 оценок. Найдите средний балл абитуриента.
        System.out.println("Hello und welcome!");
        int[] array = {4,3,3,4,5,3,4,5,4,5,3,5};
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum = sum + array[i];
            System.out.println(i + " / " + sum);
        }
        double result = sum / (double)array.length;
        System.out.println("Средний бал абитурента: " + result );
        System.out.printf("Средний бал абитурента: %.2f ", result );
      //  System.out.println(array.length);


    }
}