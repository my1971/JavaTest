/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 **********************************************************************************************************************/

public class Aufgabe13_2 {
    public static void main(String[] args) {
/*   Задача 2. Написать метод, принимающий массив целых чисел, и возвращающий всех его элементов,
    с четными индексами. 0 - тоже четное число.*/
        int num[] = fillArray(10); // произведение
        System.out.println("Sum Array even index = " +  sumInArray(num));
   }
    public static int sumInArray (int[] num){
        int perSum = 0;
        for (int i = 0; i < num.length; i++) {
            if (i % 2 == 0){ // проверка индекса на четность
                perSum = perSum + num[i];
                System.out.println(i + ") " + num[i] );
            }
        }
        return perSum;
    }
    public static int[] fillArray(int x) {
        int[] arr = new int[x];
        int a = 1, b = 100;
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * (b - a + 1) + a);
        }
        return arr;
    }
}
