/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 **********************************************************************************************************************/

public class Aufgabe13_4 {
    public static void main(String[] args) {
/*Задача 4.()* Написать метод, принимающий массив целых чисел, и разворачивающий его. Последний элемент становится
 нулевым, предпоследний, первым, и т. д. Подсказка: этот метод должен изменить полученный массив.*/
        int num[] = fillArray(20);
        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        printArray(num);
        reverseArray(num);
        System.out.println(" ");
        System.out.println("*****************************************************************************************");
   }
    public static void reverseArray (int[] num){
        int l = num.length - 1;
        int numReverse[] = new int[num.length];
        for (int i = 0; i < num.length; i++) {
            numReverse[i] = num[l];
            l--;
        }
        System.out.println(" ");
        printArray(numReverse);
    }
    public static int[] fillArray(int x) {
        int[] arr = new int[x];
        for (int i=0;i<arr.length;++i) {
            arr[i]=i;
        }
        return arr;
    }
    public static void printArray(int[] arr){
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " | ");
        }
    }

}
