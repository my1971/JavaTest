package aufgaben33.soldier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

import static aufgaben33.soldier.ArrayTools.printArray;
import static aufgaben33.soldier.ArrayTools.searchObject;


class SoldierTest {
    /*   Task 2. Test methods:
               -   printing an array of objects
               -   finding an object in an array of objects
               -   finding an object in an array of objects by condition (findByPredicate) on three data
       types - numbers, strings and objects of the Soldier class (see task 1).
       Задание 2. Протестировать методы:
               -   печать массива объектов
               -   нахождение объекта в массиве объектов
               -   нахождение объекта в массиве объектов по условию (findByPredicate) на трех типах
       данных - числа, строки и объекты класса Soldier (см. задание 1).*/
    Soldier[] soldiers;

    // Soldier soldier;
    @BeforeEach
    void setUp() {
        soldiers = new Soldier[10];
        soldiers[0] = new Soldier("Vasya", 175.0, 75.0, 60);
        soldiers[1] = new Soldier("Oleg", 180.0, 79.0, 20);
        soldiers[2] = new Soldier("John", 169.0, 73.0, 40);
        soldiers[3] = new Soldier("Marik", 181.0, 90.0, 80);
        soldiers[4] = new Soldier("Duma", 169.0, 77.0, 33);
        soldiers[5] = new Soldier("Mad", 173.0, 67.0, 78);
        soldiers[6] = new Soldier("Nirev", 179.0, 80.0, 23);
        soldiers[7] = new Soldier("Byd", 175.0, 75.0, 67);
        soldiers[8] = new Soldier("Badil", 177.0, 77.0, 60);
        soldiers[9] = new Soldier("Nas", 190.0, 100.0, 96);
    }

    @Test
    void machDisplay() {
        printArray(soldiers);
    }

    @Test
        //Сортировка по имени
    void testSortByName() {
        System.out.println("--------Array as is----------");
        printArray(soldiers);
        Arrays.sort(soldiers, Comparator.comparing(Soldier::getName));
        //Arrays.sort(soldiers, (o1, o2) -> o1.getName().compareTo(o2.getName()));
        //Arrays.sort(soldiers, (o1, o2) -> o1.getName().compareTo(o2.getName()));
        //Arrays.sort(soldiers, ((o1, o2) -> o1.getName() - o2.getName()));
        System.out.println("--------Array sort by name----------");
        printArray(soldiers);
    }

    // поиск объекта в массиве Объектов
    @Test
    void search() {
        System.out.println(soldiers[searchObject(soldiers, soldiers[5])]);
    }

    @Test
    void searchByPredicate() {
        ArrayTools.printArray(soldiers);
        Soldier soldier = ArrayTools.findByPredicate(soldiers, soldier1 -> Objects.equals(soldier1.getName(), "Marik"));
        System.out.println(soldier);
//
    }

}