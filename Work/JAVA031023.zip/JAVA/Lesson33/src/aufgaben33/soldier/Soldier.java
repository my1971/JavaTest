package aufgaben33.soldier;

import java.util.Objects;
//import java.util.function.Predicate;

public class Soldier {
    /*  Task 1. Create class Soldier (name, height, weight, profile). Profile = 1 to 99.
      Задание 1. Создать класса Soldier (name, height, weight, profile). Profile = 1 до 99.*/
    public String name; // имя
    public double height; // рост
    public double weight; // вес
    public int profile; //профиль или професиональные данные от 1 до 99

    public Soldier(String name, double height, double weight, int profile) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.profile = profile;
    }
//Metods

    public String getName() {
        return name;
    }


    @Override
    public String toString() {
        return "Soldier{" +
                "name='" + name + '\'' +
                ", height=" + height +
                ", weight=" + weight +
                ", profile=" + profile +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Soldier soldier = (Soldier) o;
        return Objects.equals(name, soldier.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, height, weight, profile);
    }
}
