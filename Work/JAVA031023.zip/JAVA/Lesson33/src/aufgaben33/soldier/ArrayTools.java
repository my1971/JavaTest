package aufgaben33.soldier;

import java.util.function.Predicate;

public class ArrayTools {
    public static void printArray(Object[] arr) {
        for (Object o : arr) {
            System.out.println(o);
        }
        System.out.println("===================================");
    }

    // поиск объекта в массиве Объектов
    public static int searchObject(Object[] arr, Object value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(value)) return i;
        }
        return -1; // несуществующий индекс
    }


    // поиск объекта по условию
    public static <T> T findByPredicate(T[] arr, Predicate<T> predicate) {
        //Метод возвращает тип Т, из массива типа Т[], отбор по предикату
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                return arr[i];
            }
        }
        return null;
    }
}
