package practice.city;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;

class CityTest {
    City[] cities;

    static void printArray(Object[] arr) {
        for (Object name : arr) {
            System.out.println(name);
        }
    }

    @BeforeEach
    void setUp() {
        cities = new City[10];
        cities[0] = new City("Berlin", 3645000, 68, "13555");
        cities[8] = new City("Berlin", 36000, 50, "10095");
        cities[1] = new City("München", 1545000, 45, "85555");
        cities[2] = new City("Banberg", 400000, 35, "96138");
        cities[3] = new City("Augsburg", 360000, 65, "86356");
        cities[4] = new City("Hennef", 46114, 30, "53773");
        cities[5] = new City("New York", 8800000, 80, "10001");
        cities[6] = new City("Moskow", 15000000, 78, "141000");
        cities[9] = new City("Moskow", 15000000, 30, "141000");
        cities[7] = new City("Moskow", 150000, 60, "100005");
    }

    @Test
    void testSort() {
        System.out.println("--------- UnSort ----------");
        printArray(cities);
        Arrays.sort(cities);
        System.out.println("--------- Sort by Array----------");
        printArray(cities);
    }

    @Test
    void testSortComparator() {
        System.out.println("===============Array as is =================");
        printArray(cities);

        Comparator<City> cityComparator = new Comparator<City>() { // компаратор определяет способ сортировки
            @Override
            public int compare(City o1, City o2) {
                int compareName = o1.getName().compareTo(o2.getName()); // сортировка по алфавиту
                int comparePopulation = -(o1.getPopulation() - o2.getPopulation());
                if (compareName != 0) {
                    return compareName;
                } else if (comparePopulation != 0) {
                    return comparePopulation; // по размеру популяции
                } else {
                    return o1.getPollution() - o2.getPollution(); // по загрязнению, меньшие значения - выше
                }
            }
        };

        Arrays.sort(cities, cityComparator); // выбираем другой метод класса Arrays
        System.out.println("===============Array sorted =================");
        printArray(cities);
    }


}