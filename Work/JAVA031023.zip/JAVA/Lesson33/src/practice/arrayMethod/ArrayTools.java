package practice.arrayMethod;

import java.util.function.Predicate;

public class ArrayTools {
    public static void printArray(Object[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
        System.out.println("===================================");
    }

    // поиск объекта в массиве Объектов
    public static int search(Object[] arr, Object value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(value)) {
                return i;
            }
        }
        return -1; // несуществующий индекс
    }

    public static boolean searchBoolean(Object[] arr, Object value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(value)) {
                return true;
            }
        }
        return false; // несуществующий индекс
    }

    // поиск объекта по условию
    public static <T> T findByPredicate(T[] arr, Predicate<T> predicate) {
        //Метод возвращает тип Т, из массива типа Т[], отбор по предикату
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                return arr[i];
            }
        }
        return null;
    }
}
