package practice31;

import java.util.Objects;

public abstract class Employee {
    protected final int id;
    protected String firstName;
    protected String lastName;
    protected double haurs;

    @Override
    public String toString() {
        //воспользуемся новым классом StringBuilder - это "Класс объвертка" для класса String
        String sb = "Employee" + "id = " + id +
                ", FirstName = " + firstName + '\'' +
                ", LastName = " + lastName + '\'' +
                ", Haurs = " + haurs +
                ", Salary = " + calcSalary();
        return sb;
    }
    public abstract double calcSalary();

    public Employee(int id, String firstNAme, String lastName, double haurs) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.haurs = haurs;
    }

    public int getId() {
        return id;
    }

    public String getfirstName() {
        return firstName;
    }

    public void setFirstNAme(String firstNAme) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getHaurs() {
        return haurs;
    }

    public void setHaurs(double haurs) {
        this.haurs = haurs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
