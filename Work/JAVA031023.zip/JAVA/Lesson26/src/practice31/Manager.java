package practice31;
// MAnager: base + grade * haurs
public class Manager extends Employee{
    private double baseSalaly;
    private double grade;

    public Manager(int id, String firstNAme, String lastName, double haurs, double baseSAlaly, double grade) {
        super(id, firstNAme, lastName, haurs);
        this.baseSalaly = baseSAlaly;
        this.grade = grade;
    }
    @Override
    public double calcSalary() {
        double salary = baseSalaly + grade * haurs;
        return salary;
    }
    public double getBaseSAlaly() {
        return baseSalaly;
    }

    public void setBaseSAlaly(double baseSAlaly) {
        this.baseSalaly = baseSAlaly;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }


}
