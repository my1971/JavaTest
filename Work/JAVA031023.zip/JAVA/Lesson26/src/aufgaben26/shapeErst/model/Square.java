package aufgaben26.shapeErst.model;

public class Square extends Shape {
    Integer a; // Сторона квадрата (S = a*a; P = 4a.)
    @Override
    public double calcArea() {
        System.out.println("Площадь  квадрата = " + (4*a));
        return (Math.pow(a,2));
    }

    @Override
    public double calcPerimeter() {
        System.out.println("Периметр квадрата = " + (4*a));
        return 4*a;
    }

    public Square(int id, String shapeName, Integer a) {
        super(id, shapeName);
        this.a = a;
    }
}
