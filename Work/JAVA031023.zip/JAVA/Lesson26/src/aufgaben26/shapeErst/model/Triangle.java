package aufgaben26.shapeErst.model;

public class Triangle extends Shape {
    Integer a, b, c; //Стороны треугольника ((P = (a+b+c)/2; S = Math.sqrt(p*(p-a)*(p-b)*p-c))
    @Override
    public double calcArea() {
        double p = (a+b+c)/2;
        double s = (Math.sqrt(p*(p-a)*(p-b)*p-c));
        System.out.println("Площадь  треугольника = " + s);
        return s;
    }

    @Override
    public double calcPerimeter() {
        double p = (a+b+c)/2;
        System.out.println("Периметр треугольника = " + p);
        return p;
    }

    public Triangle(int id, String shapeName, Integer a, Integer b, Integer c) {
        super(id, shapeName);
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
