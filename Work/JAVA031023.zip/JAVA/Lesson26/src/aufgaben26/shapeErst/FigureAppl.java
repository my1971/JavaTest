package aufgaben26.shapeErst;

import aufgaben26.shapeErst.model.Circle;
import aufgaben26.shapeErst.model.Shape;
import aufgaben26.shapeErst.model.Square;
import aufgaben26.shapeErst.model.Triangle;

public class FigureAppl {
    public static void main(String[] args) {

        Shape[] arrShape = new Shape[4]; //Массив состоящий из объектов, каждый обект - это фигура
        arrShape[0] = new Circle(1,"Shape",2);
        arrShape[1] = new Circle(2,"Shape",3);
        arrShape[2] = new Triangle(3, "Triangle",3,4, 5);
        arrShape[3] = new Square(4,"Square",4);


        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь = " + totelArea(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общий периметр = " + totelPerimetery(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь круга = " + totelCircle(arrShape));
        System.out.println("------------------------------------------------------");
    }

    public static double totelArea(Shape[] arrShape) {
        double sum = 0;
        for (int i = 0; i < arrShape.length; i++) {
            if (arrShape[i] != null) {
                sum += arrShape[i].calcArea();
            }
        }
        return sum;
    }

    public static double totelPerimetery(Shape[] arrShape) {
        double sum = 0;
        for (int i = 0; i < arrShape.length; i++) {
            if (arrShape[i] != null) {
                sum += arrShape[i].calcPerimeter();
            }
        }
        return sum;
    }
    public static double totelCircle(Shape[] arrShape) {
        double sum = 0;
        for (int i = 0; i <  arrShape.length; i++) {
            if (arrShape[i] != null && (arrShape[i] instanceof Circle)) {
                sum += arrShape[i].calcArea();
            }
        }
        return sum;
    }
}

//        Add two circles круг  (S = π × r2 , P = d*π = 2*r*π.)
//        one triangle треугольник (P = (a+b+c)/2; S = Math.sqrt(p*(p-a)*(p-b)*p-c))
//        one square. квадрат S = a*a; P = 4a.
