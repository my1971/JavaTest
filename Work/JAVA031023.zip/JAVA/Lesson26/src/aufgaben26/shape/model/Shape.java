package aufgaben26.shape.model;

public abstract class  Shape {
 /*   Task 2.
    Create an abstract class Shape with field type double and abstract methods calcArea and calcPerimeter.
    Create classes Circle, Triangle, Square that extend the Shape class and implement abstract methods.
    Write a FigureAppl class with a main method.
    In the method, create an array of shapes.
    Add two circles to the array, one triangle and one square.
    Calculate the total area and total perimeter
    of all shapes from an array of shapes.
    Задача 2.
    Создайте абстрактный класс Shape с типом поля double и абстрактными методами calcArea и calcPerimeter.
    Создать классы Circle, Triangle, Square, расширяющие класс Shape и реализующие абстрактные методы.
    Напишите класс FigureAppl с методом main. В методе создайте массив фигур.
    Добавьте в массив два круга, один треугольник и один квадрат.
    Рассчитайте общую площадь и общий периметр всех фигур из массива фигур.*/
 protected final int id;
    protected String shapeName;
    protected Double length;
    public Shape[] arrShape;
    //Medods

    public static Double totelArea(Shape[] arrShape) {
        Double sum = 0.0;
        for (int i = 0; i < arrShape.length; i++) {
            if (arrShape[i] != null) {
                sum += arrShape[i].calcArea();
            }
        }
        return sum;
    }

    public static Double totelPerimetery(Shape[] arrShape) {
        Double sum = 0.0;
        for (int i = 0; i < arrShape.length; i++) {
            if (arrShape[i] != null) {
                sum += arrShape[i].calcPerimeter();
            }
        }
        return sum;
    }

    public static Double totelCircle(Shape[] arrShape) {
        double sum = 0;
        for (int i = 0; i < arrShape.length; i++) {
            if (arrShape[i] != null && (arrShape[i] instanceof Circle)) {
                sum += arrShape[i].calcArea();
            }
        }
        return sum;
    }

    public Shape(int id, String shapeName, Double length) {
        this.id = id;
        this.shapeName = shapeName;
        this.length = length;
    }

    public abstract Double calcArea();

    public abstract Double calcPerimeter();

    public Double getLength() {
        return length;
    }
    public void setLength(Double length) {
        this.length = length;
    }
    public int getId() {
        return id;
    }

    public String getShapeName() {
        return shapeName;
    }

    public void setShapeName(String shapeName) {
        this.shapeName = shapeName;
    }
}
