package practice31.company_employee29.dao;

import practice31.company_employee29.model.Employee;

public interface Company {
    //перечень действий метода

    //берем на работу
    boolean addEmployee(Employee employee); // добавить сотрудника в компанию

    Employee removeEmployee(int id); //удоляет сотрудника из компании

    // найти сотрудника по его ID
    Employee findEmployee(int id); //ищем  сотрудника в компании

    //размер компании
    int size();

    // печатаем список
    void printEmployee();

}
