package aufgaben29.shape;

import aufgaben29.shape.model.*;

public class FigureAppl {
    public static void main(String[] args) {
        Shape[] arrShape = new Shape[6]; //Массив состоящий из объектов, каждый обект - это фигура
        arrShape[0] = new Circle(1, "Shape", 2.0);
        arrShape[1] = new Circle(2, "Shape", 3.0);
        arrShape[2] = new Triangle(3, "Triangle", 3.0);
        arrShape[3] = new Square(4, "Square", 4.0);
        arrShape[4] = new Trapezoid(4, "Square", 4.0, 5.0, 3.0, 7.0, 9.0);
        arrShape[5] = new Rectangle(4, "Square", 4.0, 7.0);


        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь = " + Shape.totelArea(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общий периметр = " + Shape.totelPerimetery(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь круга = " + Shape.totelCircle(arrShape));
        System.out.println("------------------------------------------------------");
    }
}
