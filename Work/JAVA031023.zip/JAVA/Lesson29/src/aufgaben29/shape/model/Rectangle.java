package aufgaben29.shape.model;

public class Rectangle extends Shape {
    // Сторона прямоугольника (S = a * b; P = (a + b) * 2.)
    protected Double lengthB;

    public Rectangle(int id, String shapeName, Double length, Double lengthB) {
        super(id, shapeName, length);
        this.lengthB = lengthB;
    }

    @Override
    public Double calcArea() {
        Double s = length * lengthB;
        System.out.println("Площадь  прямоугольника = " + s);
        return s;
    }

    @Override
    public Double calcPerimeter() {
        Double p = (length + lengthB) * 2;
        System.out.println("Периметр прямоугольника = " + p);
        return p;
    }
}
