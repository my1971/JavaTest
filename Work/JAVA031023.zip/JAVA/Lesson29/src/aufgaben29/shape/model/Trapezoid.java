package aufgaben29.shape.model;

public class Trapezoid extends Shape {
    // Сторона Трапеции (S = (a + b)/ 2 * h; P = a + b + c + d.)
    protected Double lengthA;
    protected Double lengthB;
    protected Double lengthC;
    protected Double lengthD;

    public Trapezoid(int id, String shapeName, Double length, Double lengthA, Double lengthB, Double lengthC, Double lengthD) {
        super(id, shapeName, length);
        this.lengthA = lengthA;
        this.lengthB = lengthB;
        this.lengthC = lengthC;
        this.lengthD = lengthD;
    }

    @Override
    public Double calcArea() {
        Double s = (lengthA + lengthB) / 2 * length;
        System.out.println("Площадь  трапеции = " + s);
        return s;
    }

    @Override
    public Double calcPerimeter() {
        Double p = lengthA + lengthB + lengthC + lengthD;
        System.out.println("Периметр трапеции = " + p);
        return p;
    }
}
