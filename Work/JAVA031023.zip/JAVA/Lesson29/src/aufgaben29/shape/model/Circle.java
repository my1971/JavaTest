package aufgaben29.shape.model;

public class Circle extends Shape {
    public Circle(int id, String shapeName, Double length) {
        super(id, shapeName, length);
    }

    // радиус круга (S = π × r2 , P = d*π = 2*r*π.)
    @Override
    public Double calcArea() {
        double s = (Math.pow(length, 2) * 3.14);
        System.out.println("Площадь  круга = " + s);
        return s;
    }

    @Override
    public Double calcPerimeter() {
        double p = (2 * length * 3.14);
        System.out.println("Периметр круга = " + p);
        return p;
    }
}
