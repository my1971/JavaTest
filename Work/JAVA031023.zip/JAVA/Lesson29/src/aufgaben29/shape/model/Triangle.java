package aufgaben29.shape.model;

public class Triangle extends Shape {
    public Triangle(int id, String shapeName, Double length) {
        super(id, shapeName, length);
    }

    //Стороны треугольника ((P = (a+b+c)/2; S = Math.sqrt(p*(p-a)*(p-b)*p-c))
    //  ((Math.pow(length) * Math.sqrt(3))/4)
    @Override
    public Double calcArea() {
        Double s = (((length * length) * Math.sqrt(3)) / 4);
        System.out.println("Площадь  треугольника = " + s);
        return s;
    }

    @Override
    public Double calcPerimeter() {
        Double p = (length) / 2;
        System.out.println("Периметр треугольника = " + p);
        return p;
    }

}
