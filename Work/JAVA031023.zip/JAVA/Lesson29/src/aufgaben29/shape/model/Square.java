package aufgaben29.shape.model;

public class Square extends Shape {
    public Square(int id, String shapeName, Double length) {
        super(id, shapeName, length);
    }

    // Сторона квадрата (S = a*a; P = 4a.)
    @Override
    public Double calcArea() {
        Double s = (Math.pow(length, 2));
        System.out.println("Площадь  квадрата = " + s);
        return s;
    }

    @Override
    public Double calcPerimeter() {
        Double p = (4 * length);
        System.out.println("Периметр квадрата = " + p);
        return p;
    }
}
