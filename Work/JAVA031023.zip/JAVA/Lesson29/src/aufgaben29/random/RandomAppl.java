package aufgaben29.random;

import aufgaben29.random.model.Random;

public class RandomAppl {
    public static void main(String[] args) {
        Random random = new Random();
        int[] array = random.fillArray(1, 10, 100);
        System.out.println("**************** First Version ****************************");
        int[] array1 = random.findInArray1(array);
        random.display(array1);
        System.out.println("*******************  Test Switch ****************************");
        int[] array1_1 = random.findInArray3(array);
        random.display(array1_1);
        System.out.println("**************** Second Version ****************************");
        int[][] array2 = random.findInArray2(array);
        random.display(array2);
        System.out.println("*******************  Test Version ****************************");
        int[] array3 = random.fillArray();
        int[][] array4 = random.findInArray2(array3);
        random.display(array4);
        System.out.println("**********************  End ********************************");

    }

}
