/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 //arr[i] = (int)(Math.random() * (b - a + 1) + a);
 **********************************************************************************************************************/

package aufgaben29.random.model;

public class Random {
    public Random() {
    }

    /* Task 2. Finding duplicates in an array. Think of an array of 100 elements and fill
            it with random values between 1 and 10. Count how many and which elements
            occurred more than once in this array.
    Задача 2. Поиск дубликатов в массиве. Задумайте массив из 100 элементов и заполните
            его случайными значениями целых чисел в интервале от 1 до 10. Подсчитайте сколько
            и каких элементов встретилось более одного раза в этом массиве. */
    // Erst version
    public int[] findInArray1(int[] arr) { // нахождение похожих чисел в массиве
        int[] arr2 = new int[10];
        int in = 0;
        for (int i = 1; i <= 10; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (arr[j] == i) {
                    in++;
                }
            }
            if (in > 0) {
                arr2[i - 1] = in;
                in = 0;
            }
        }
        return arr2;
    }

    // Second version
    public void display(int[] arr2) {
        for (int i = 0; i < arr2.length; i++) {
            System.out.println("Number - " + (i + 1) + " repits - " + arr2[i] + " time!");
        }
    }

    // Second version
    public int[][] findInArray2(int[] arr) { // нахождение похожих чисел в массиве
        int[][] arr2 = new int[10][2];
        int q = 0, quan = 1;
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] == arr[j]) & (arr[i] >= 0)) {
                    quan++;
                    arr[j] = -1;
                }
            }
            if (quan > 1) {
                arr2[q][0] = arr[i];
                arr2[q][1] = quan;
                q++;
                quan = 1;
            }
        }
        return arr2;
    }

    public int[] findInArray3(int[] arr) { // нахождение похожих чисел в массиве Вариант 3
        int[] arr2 = new int[10];
        for (int i = 0; i < arr.length; i++) {
            switch (arr[i]) {
                case 1:
                    arr2[0]++;
                    break;
                case 2:
                    arr2[1]++;
                    break;
                case 3:
                    arr2[2]++;
                    break;
                case 4:
                    arr2[3]++;
                    break;
                case 5:
                    arr2[4]++;
                    break;
                case 6:
                    arr2[5]++;
                    break;
                case 7:
                    arr2[6]++;
                    break;
                case 8:
                    arr2[7]++;
                    break;
                case 9:
                    arr2[8]++;
                    break;
                case 10:
                    arr2[9]++;
                    break;
                default:
                    break;
            }
        }
        return arr2;
    }

    public void display(int[][] arr2) {
        for (int i = 0; i < arr2.length; i++) {
            if (!(arr2[i][0] == 0)) {
                System.out.println("Number - " + arr2[i][0] + " repits - " + arr2[i][1] + " time!");
            }
        }
    }

    //**********************
    public int[] fillArray(int a, int b, int x) { // заполнение массива (генерирует случайное число)
        int[] arr = new int[x];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * (b - a + 1) + a);
        }
        return arr;
    }

    public int[] fillArray() { // заполнение массива (генерирует случайное число)
        int[] arr = {10, 10, 5, 1, 7, 1, 10, 3, 3, 2, 10, 1};
        return arr;
    }
}



