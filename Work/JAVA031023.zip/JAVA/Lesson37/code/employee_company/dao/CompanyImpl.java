package employee_company.dao;

import employee_company.model.Employee;

import java.util.Arrays;
import java.util.Comparator;

//**Задание 5.**
//        CompanyImpl реализовать методы для поиска сотрудников по критериям:
//        - имеющих стаж более 5 лет
//        - имеющих зарплату менее 2000 евро
//        - не имеющих высшее образование
//

public class CompanyImpl implements Company {
    // заводим массив под сотрудников
    private final Employee[] employees;

    // кол-во сотрудников
    private int size;

    // конструктор, который получив на вход capacity определяет размер массива employees
    public CompanyImpl(int capacity) {
        employees = new Employee[capacity];
    }

    // метод, который добавляет нового сотрудника в массив
    @Override
    public boolean addEmployee(Employee arraty) {
        // если сотрудник не null ИЛИ size еще не равен длине массива ИЛИ такой сотрудник уже есть, ТО
        if (arraty == null || size == employees.length || findEmployee((int) arraty.getId()) != null) {
            return false; // возвращаем false, т.к. его нельзя добавить!
        }
        employees[size++] = arraty; // добавляем сотрудника в массив
        return true; // возвращаем true
    }

    // метод, который удаляет сотрудника из массива по его id
    @Override
    public Employee removeEmployee(int id) { // получили на вход id
        for (int i = 0; i < size; i++) { // перебираем весь массив
            if (employees[i].getId() == id) { // находим жертву по его id
                Employee victim = employees[i]; // в объект victim кладем найденного
                employees[i] = employees[--size]; // берем последнего в списке и ставим его на место найденного
                employees[size] = null; // последнего в списке делаем null
                return victim; // возвращаем найденный объект
            }
        }
        return null;
    }

    // метод для поиска сотрудника по его id
    @Override
    public Employee findEmployee(int id) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getId() == id) {
                return employees[i];
            }
        }
        return null;
    }


    // метод выясняет кол-во сотрудников
    @Override
    public int size() {
        return size;
    }

    public Employee[] employeesArray() { //возвращаем employees Array
        return employees;
    }

    // метод для печати
    @Override
    public void printEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
        System.out.println("==================================================================");
    }

    public void sortEmployee(int field) { //метод сортировки сотрудников
        Comparator<Employee> employeeComparator = new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                // сравнение по полю experience, которое имеет тип int, если в поле null, то возвращает 0.
                switch (field) {
                    case 1:
                        return (o1 == null || o2 == null) ? (0) : (o1.getName().compareTo(o2.getName())); //name
                    case 2:
                        return (o1 == null || o2 == null) ? (0) : (Integer.compare(o1.getAge(), o2.getAge())); //age
                    case 3:
                        return (o1 == null || o2 == null) ? (0) : (Integer.compare(o1.getExperience(), o2.getExperience())); // experience
                    case 4:
                        return (o1 == null || o2 == null) ? (0) : (o1.getEducation().compareTo(o2.getEducation())); // education
                }
                return 0;
            }
        };
        Arrays.sort(employees, employeeComparator);
    }

}