package employee_company.dao;

import employee_company.model.Employee;
import employee_company.model.Engineer;
import employee_company.model.Worker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

//**Задание 5.**
//        CompanyImpl реализовать методы для поиска сотрудников по критериям:
//        - имеющих стаж более 5 лет
//        - имеющих зарплату менее 2000 евро
//        - не имеющих высшее образование
//
//        **Задание 6.**
//        Создать компараторы и получить отсортированные списки сотрудников:
//        - по возрасту
//        - по стажу работы в компании
//        - по величине зарплаты
//        - по образованию (выше образованные в начале списка)


class CompanyImplTestAjt {

    CompanyImpl company; // что это?
    Employee[] employeesTest; // что это? Для чего?

    @BeforeEach
    void setUp() {
        company = new CompanyImpl(10);
        employeesTest = new Employee[5];
        employeesTest[0] = new Engineer(100L, "John", 35, 7, "1 - phd", 1000.0, 5, 160);
        employeesTest[1] = new Engineer(101L, "Ann", 30, 5, "2 - university", 900.0, 4, 160);
        employeesTest[2] = new Worker(103L, "Peter", 45, 5, "3 - hight school", 850, 160);
        employeesTest[3] = new Worker(104L, "Robin", 28, 10, "4 - real school", 750, 160);
        employeesTest[4] = new Worker(105L, "Mike", 20, 2, "4 - real school", 600, 160);
        for (int i = 0; i < employeesTest.length; i++) {
            company.addEmployee(employeesTest[i]);
        }

    }

    @Test
    void addEmployee() {
        System.out.println(company.size());
        Engineer engineer = new Engineer(106L, "Stefan", 40, 0, "3 - hight school", 900, 4, 160);
        assertTrue(company.addEmployee(engineer));
        System.out.println(company.size());
        assertEquals(5, company.size());
        assertFalse(company.addEmployee(null));
        assertFalse(company.addEmployee(engineer));
    }

    @Test
    void removeEmployee() {
        System.out.println(company.size() + "//////////");
        company.printEmployees();
        assertEquals(employeesTest[4], company.removeEmployee(105));
        System.out.println(company.size());
        assertEquals(4, company.size());
        company.printEmployees();
    }

    @Test
    void findEmployee() {


    }

    @Test
    void size() {


    }

    @Test
    void printEmployees() {


    }
//    @Test
//    void testSortByExpirience() {
//
//        company.printEmployees();
//        Comparator<Employee> employeeComparator = new Comparator<Employee>() {
//            @Override
//            public int compare(Employee o1, Employee o2) {
//                return Integer.compare(o1.getExperience(), o2.getExperience()); // сравнение по полю experience, которое имеет тип int
//            }
//        };
//
//        Employee[] sortedArray = Arrays.copyOf(employees, company.size());
//        Arrays.sort(sortedArray, employeeComparator);
//        Arrays.sort(employees, employeeComparator);
//        company.printEmployees();
//
//    }
//
//    @Test
//    void testSortByExpirience() {
//        System.out.println("===============Array as is =================");
//        company.printEmployees();
//        Comparator<Employee> employeeComparator = new Comparator<Employee>() {
//
//            @Override
//            public int compare(Employee o1, Employee o2) {
//                System.out.println(new StringBuilder().append(o1).append(" **********").append(o2).toString());
//                return o1.getExperience() - o2.getExperience(); // по полю Expirience
//               // return o1.getName().compareTo(o2.getName());
//                //compareName = o1.getName().compareTo(o2.getName());
//              //  return o1.getExperience() - o2.getExperience(); // по полю Expirience
//            } // компаратор определяет способ сортировки
//        };
//
//      //  Arrays.sort(company.ArrayMetod(), employeeComparator); // выбираем другой метод класса Arrays
//        System.out.println("===============Array sorted =================");
//        company.printEmployees();
//
////    Comparator<Employee> employeeComparator = Comparator.comparing(Employee::getExperience);
////    Arrays.sort(employees, employeeComparator);
//        // company.printEmployees();
//
////    Comparator<Employee> employeeComparator  = new Comparator<Employee>() {
////        @Override
////        public int compare(Employee o1, Employee o2) {
////            return o1.getExperience() - o2.getExperience(); // по полю Expirience
////        }
////    };
////    company.printEmployees();
////    Arrays.sort(employees);
////    company.printEmployees();
//    }

}

//        **Задание 6.**
//        Создать компараторы и получить отсортированные списки сотрудников:
//        - по возрасту
//        - по стажу работы в компании
//        - по величине зарплаты
//        - по образованию (выше образованные в начале списка)