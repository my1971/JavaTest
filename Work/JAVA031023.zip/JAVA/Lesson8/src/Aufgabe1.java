import java.util.Scanner;

public class Aufgabe1 {
    public static void main(String[] args) {
//Пользователь вводит с клавитуры число. Вывести абсолютное значение (модуль) числа, используя тернарный оператор.
        Scanner sc = new Scanner(System.in);
        System.out.println("Output the absolute value (modulus) of a number");
        System.out.print("Input Number: ");
        int perNumber = sc.nextInt();
        System.out.println("------------------------------------------");
//        int perNumberOutput = (perNumber >0) ? perNumber : - perNumber;
//        System.out.println(perNumberOutput);
        System.out.println((perNumber >0) ? perNumber : - perNumber);
        System.out.println("===========================================");

    }
}