import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {

        System.out.println("Parsing IP-address");
/*Задача 3. Программа получает на вход IP-адрес в одну строку: например, 192.168.23.1 (четыре числа, разделённые точками).
Каждое число должно быть в диапазоне от 0 до 255. Программа должна вывести эти четыре числа по отдельности, каждое в новой
строке, например: 192 168 23 1*/

        Scanner sc = new Scanner(System.in);
        System.out.println("Imput IP-address");
        String perIpAddress = sc.nextLine();
        perIpAddress = perIpAddress.trim(); // убираем пробелы
        int perFirstDotIndex = perIpAddress.indexOf('.'); // нашли точку позиции 1-й точки
        //System.out.println(perFirstDotIndex);
        int perL = perIpAddress.length();
        int perSecondDotIndex = perIpAddress.indexOf('.',perFirstDotIndex + 1);
        int perThirdDotIndex = perIpAddress.indexOf('.',perSecondDotIndex + 1);
        int perExtraDotIndex = perIpAddress.indexOf('.',perThirdDotIndex + 1);
        // если точки нет, то perExtraDotIndex = -1
        if (perExtraDotIndex != -1){
            System.out.println("Wrong input, a lot of dots.");
        }
        if (perExtraDotIndex == -1){
            String perByte1 = perIpAddress.substring(0,perFirstDotIndex);
            int perNum1 = Integer.parseInt(perByte1); // преобразование строки в число
            String perByte2 = perIpAddress.substring(perFirstDotIndex + 1,perSecondDotIndex);
            int perNum2 = Integer.parseInt(perByte2); // преобразование строки в число
            String perByte3 = perIpAddress.substring(perSecondDotIndex + 1,perThirdDotIndex);
            int perNum3 = Integer.parseInt(perByte3); // преобразование строки в число
            String perByte4 = perIpAddress.substring(perThirdDotIndex + 1,perL );
            int perNum4 = Integer.parseInt(perByte4); // преобразование строки в число
            System.out.println(perNum1 + " - " + perNum2 + " - " + perNum3 + " - " + perNum4);
        }

    }
}