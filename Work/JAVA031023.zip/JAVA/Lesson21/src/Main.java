public class Main {
    public static void main(String[] args) {

        String str = "Ich liebe Java sehr stark!";
        String[] words = str.split(" ");
        for (String word : words) {
            System.out.println(word);
        }
        String[] Symbols = str.split("");
        System.out.println(Symbols.length);
        for (String word1 : Symbols) {
            System.out.print(word1 + "|");
        }

    }
}