package practice31;
import java.util.Scanner;

public class IsPrime {
    //отсутствуют поля, описывают объекты
    // В нем есть только методы
    // есть метод main, который исполняется
    public static void main(String[] args) {
/*  Написать метод, определяющий, является ли число простым (primary). Проcтое число - это число,
    которое делится только на себя и 1. Примеры: 2, 7, 11, 19, 47. */
        // Что на входе     - целое положительное число
        // Что на выходе    - boolean, ответ на п оставленный вопрос
        // ключевой алгоритм -
        //Scanner scanner = new Scanner(System.in);
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("Input integer positive number: ");
            int n = scanner.nextInt();
            boolean isPrime = true;
            System.out.println("n = " + n);
            for (int i = 2; i < n - 1; i++) {
                if (n % i == 0){
                    isPrime = false;
                    System.out.println(i);
                }
            }
            if (isPrime){
                System.out.println("Number " + n + " is prime");
            }else{
                System.out.println("Number " + n + " is not prime");
            }
            System.out.println("Continie? y/n");
            String choice = scanner.next();
            if (!choice.equals("y") & !choice.equals("Y")){
                System.out.println("Thanks? bye!");
                break;
            }
        }


    }

}
