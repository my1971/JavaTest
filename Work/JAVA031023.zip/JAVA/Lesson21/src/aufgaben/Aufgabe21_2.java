package aufgaben;

public class Aufgabe21_2 {
    public static void main(String[] args) {
/*Task 2. A sentence was given: "You can't be pardoned."
    -   Swap the first and last word in it;
    -   add a comma to it at the right place and print it.
Задача 2. Дано предложение: "Казнить нельзя помиловать".
    -   Поменяйте первое и последнее слово в нем местами;
    -   добавьте в него запятую на нужном месте и выведите на печать.*/

        String str = "казнить нельзя помиловать";
        String[] words = str.split(" ");
        for (String word : words) {System.out.print(word + " |");}
        System.out.println(" ");
        String per = words[0];
        words[0] = words[words.length-1] + ",";
        words[words.length-1] = per;
        System.out.println(String.join(" ",words ));
//        String res = String.join(" ",words );
//        System.out.println(res);
//        for (int i = 0; i < words.length; i++) {
//            System.out.print(words[i]);
//            if (i == 0) {System.out.print(", ");} else {System.out.print(" ");}
//        }
    }
}