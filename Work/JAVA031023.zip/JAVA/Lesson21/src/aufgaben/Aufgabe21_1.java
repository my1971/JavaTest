package aufgaben;

public class Aufgabe21_1 {
    public static void main(String[] args) {
/*Task 1. Complete all the exercises that we did in the lesson with the string. As an example of a line, take your own word or
 a short sentence, for example, "My name is First Name and Last Name."
 Задча 1. Выполнить все упражнения, которые мы делали на занятии со строкой. В качестве примера строки взять свое слово или
 короткое предложение, например, "Меня зовут Имя и Фамилия".*/

        String str = "Ich heiße Vyacheslav Manschulow";
        String[] words = str.split(" ");
        for (String word : words) {
            System.out.println(word);
        }
        String[] Symbols = str.split("");

        for (String word1 : Symbols) {
            System.out.print(word1 + "|");
        }
        System.out.println("Total characters - " + Symbols.length);
        //Присвоение и вычисления
        int n = 20;
        Integer z = 10;
        System.out.println(n);
        System.out.println(z);
        z = z+ 100;
        System.out.println(z);
        Double pi = 3.14;
        double circleLength = 2 * pi * 10;
        System.out.println(circleLength);
        // методы  с константами классов
        System.out.println("================ Constants of");
        System.out.println("Integer und MAX - " + Integer.MAX_VALUE);
        System.out.println("Integer und MIN - " + Integer.MIN_VALUE);
        System.out.println("Long MIX" + Long.MAX_VALUE);
        System.out.println("Double MAX " + Double.MAX_VALUE);


    }
}