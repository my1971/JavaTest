import java.util.Scanner;

public class SumN {
    public static void main(String[] args) {
        // Задача 1. Составьте программу, которая вычисляет сумму чисел от 1 до N.
        // Значение N вводится с клавиатуры.
        System.out.println("Sum of number less then N");
        //что на входе - число N = 9 int n
        //что на выходе - 1 + 2 + 3 + ... + 8 + 9
        // ключевой алгоритм - запустить цыкл while
        // количество повторов number-1

        System.out.print("Input ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), sum = 1, i = 1;
        while (i<=n){
            sum = sum +i+1;
            System.out.println(sum);
            i++;
            System.out.println(i);
        }
        System.out.println("Sum = " + sum);
    }
}