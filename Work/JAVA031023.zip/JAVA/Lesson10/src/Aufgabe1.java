import java.util.Scanner;

public class Aufgabe1 {
    public static void main(String[] args) {
        /*С клавиатуры вводятся N чисел. Составьте программу, которая определяет кол-во отрицательных,
         кол-во положительных и кол-во нулей среди введеных чисел. Значение N вводится с клавиатуры.*/

        System.out.println("working with numbers");
        System.out.print("Input quantity number: ");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), i = 1, nPositive = 0, nNegative = 0, nNull = 0, n1 = 0;
        while (i<=n){
            System.out.print("Input number " + i + ": ");
            n1 = sc.nextInt();
            if ( n1 == 0){ nNull++; } else if (n1>0) { nPositive++; }
            else { nNegative++;}
            i++;
        }
        System.out.println("====================================");
        System.out.println("Sum positive = " + nPositive);
        System.out.println("Sum negative = " + nNegative);
        System.out.println("Sum Null = " + nNull);
        System.out.println("====================================");
    }
}