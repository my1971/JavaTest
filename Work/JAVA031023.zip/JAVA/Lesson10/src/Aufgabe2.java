import java.util.Scanner;

public class Aufgabe2 {
    public static void main(String[] args) {
// Задача 2. В сберкассу на трёхпроцентный вклад положили S рублей. Какой станет сумма вклада через N лет?

        System.out.println("working with Bank");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input Sum: ");
        int deposit = sc.nextInt();
        System.out.print("Input quantity year: ");
        int year = sc.nextInt(), i = 1;
        Double sum = 0.00;
        while (i<=year){
            sum = (i == 1) ? (deposit + (deposit * 0.03)) : (sum + (sum * 0.03));
            System.out.println("deposit " + i  + " year = " + sum + " ruble");
            i++;
        }
        System.out.println("====================================");
        System.out.printf("Sum deposit for %d year = %.2f ruble" ,year, sum);
        System.out.println(" ");
        System.out.println("====================================");
    }
}