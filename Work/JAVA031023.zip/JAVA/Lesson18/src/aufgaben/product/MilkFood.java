package aufgaben.product;

public class MilkFood extends Food{
    private String milkType; //которые хранят тип молока и жирность продукта соответственно.
    private double fat; //жирность продукта соответственно.

    public MilkFood(double price, String name, long barCode, boolean isOutOfDate, String milkType, double fat) {
        super(price, name, barCode, isOutOfDate);
        this.milkType = milkType;
        this.fat = fat;
    }

    @Override
    public String toString() {
        return "MilkFood: / "  +"NAME - '" + super.getName() + "' PRICE - " +
                super.getPrice() + ", BAR CODE - " + super.getBarCode() +
                ", MILK TYPE - '" + milkType + "', " + " FAT - '" + fat +"' /";
    }

    public String getMilkType() {
        return milkType;
    }

    public void setMilkType(String milkType) {
        this.milkType = milkType;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }
}
