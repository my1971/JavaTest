package aufgaben.product;

public class MeatFood extends Food{
    private String meatType; //которое хранит тип мяса, из которого изготовлен продукт.

    public MeatFood(double price, String name, long barCode, boolean isOutOfDate, String meatType) {
        super(price, name, barCode, isOutOfDate);
        this.meatType = meatType;
    }

    @Override
    public String toString() {
        return "Meat food: / " + "NAME - '" + super.getName() + "' PRICE - " +
                super.getPrice() + ", BAR CODE - " + super.getBarCode() +
                ", MEAT TYPE - '" + meatType + "' /";
    }

    public String getMeatType() {
        return meatType;
    }

    public void setMeatType(String meatType) {
        this.meatType = meatType;
    }
}
