package aufgaben.product;

public class ProductsAppl {
    public static void main(String[] args) {
/* Task 2.  Override the equals method to compare objects of the Product class. In the ProductsAppl class, create a
            method that prints all unsuitable products to the console. In the main method, call new methods.
            Print the result of their work to the console.
Задача 2.   Переопределить метод equals для сравнения объектов класса Product. В классе ProductsAppl создать метод
            печатающий в консоль все негодные в пищу продукты. В методе main вызвать новые методы.
            Результат их работы напечатать в консоль.*/

        Product Prod1 = new Product(2.25, "Brot", 100000000001L);
        Product Prod2 = new Product(3.50, "Tomatte", 100000000001L);
        Food Prod3 = new Food(5.30, "Käse", 100000000003L, true);
        Food Prod4 = new Food(2.75, "Johgurt", 100000000004L, false);
        MeatFood Prod5 = new MeatFood(3.15, "Wurst", 100000000005L, true, "Pferdefleisch");
        MeatFood Prod6 = new MeatFood(3.75, "Wurst", 100000000006L, false, "Hammelfleisch");
        MilkFood Prod7 = new MilkFood(3.75, "Hüttenkäse", 100000000006L, true, "Kuh",20);
        MilkFood Prod8 = new MilkFood(3.75, "Hüttenkäse", 100000000006L, false, "Ziege", 25);
        Product[] arrProd = new Product[9];
        arrProd[0] = Prod1;
        arrProd[1] = Prod2;
        arrProd[2] = Prod3;
        arrProd[3] = Prod4;
        arrProd[4] = Prod5;
        arrProd[5] = Prod6;
        arrProd[6] = Prod7;
        arrProd[7] = Prod8;

        System.out.println("=========================================================================================================");
        printArray(arrProd); // распечатываем массив
        System.out.println("=========================================================================================================");
        System.out.println("Total cost per product - / " + printSum(arrProd) + " /"); //распечатывам сумму продуктов
        System.out.println("=========================================================================================================");
        System.out.println("Checking products for bar codes '" + Prod1.getName() + "' und '" +Prod2.getName() + "' bar code - " +
                ((Prod1.equals(Prod2)) ? (" matches! (true)") : ("does not match! (false)")));
        System.out.println("Checking products for bar codes '" + Prod1.getName() + "' und '" +Prod3.getName() + "' bar code - " +
                ((Prod1.equals(Prod3)) ? (" matches! (true)") : ("does not match! (false)")));
    }

    public static void printArray(Object[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            //System.out.println(arr[i].toString());
            System.out.println(arr[i]);
        }
    }
    public static Double printSum(Product[] arr) {
        Double sum = 0.00;
        for (int i = 0; i < arr.length - 1; i++) {
            sum += arr[i].getPrice();
        }
        return sum;
    }
}
