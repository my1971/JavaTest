package aufgaben.product;

public class Food extends Product{
    private boolean isOutOfDate; //которое отвечает за годность продукта.

    public Food(double price, String name, long barCode, boolean isOutOfDate) {
        super(price, name, barCode);
        this.isOutOfDate = isOutOfDate;
    }

    @Override
    public String toString() {
        return "Food: / "  +"NAME - '" + super.getName() + "' PRICE - " +
                super.getPrice() + ", BAR CODE - " + super.getBarCode() +
                ", is out of date - " + ((isOutOfDate== true) ? ("'fit' / ") :("'overdue' /"));
    }

    public boolean isOutOfDate() {
        return isOutOfDate;
    }

    public void setOutOfDate(boolean outOfDate) {
        isOutOfDate = outOfDate;
    }
}
