package practice31;

import practice31.model.Computer;

public class ComputerComputerAppl {
    public static void main(String[] args) {
        Computer comp1 = new Computer("i5", 8, 256, "Lenovo");
        Computer comp2 = new Computer("i5", 8, 256, "Lenovo");
        Computer comp3 = new Computer("i5", 8, 256, "asus");
        Computer comp4 = new Computer("i5", 8, 256, "Asus");
        Computer comp5 = new Computer("i5", 8, 512, "Lenovo");
//        System.out.println(comp1 == comp2);
//        System.out.println(comp1.equals(comp2));
//        System.out.println(comp1.equals(comp3));
        Computer[]arrComp = new Computer[5];
        arrComp[0] = comp1;
        arrComp[1] = comp2;
        arrComp[2] = comp3;
        arrComp[3] = comp4;
        arrComp[4] = comp5;
        printArray(arrComp);

        int sum = 0;
        for (int i = 0; i < arrComp.length; i++) {
            sum = sum + arrComp[i].getSsd();
        }
        System.out.println("Totel SSD Memory = " + sum);
    }

    public static void printArray(Object[] arr){
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i].toString());
        }
    }
}
