package practice36.city;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;

class CityTest {
    // вызвать тестируемый класс
    City[] cities;

    @BeforeEach
    void setUp() {
        // создать тестовый набор данных

        cities = new City[6]; // создаем массив

        cities[0] = new City("Denver", 600_000);
        cities[1] = new City("Boston", 670_000);
        cities[2] = new City("Chicago", 2_700_000);
        cities[3] = new City("Atlanta", 470_000);
        cities[4] = new City("New York", 8_500_000);
        cities[5] = new City("Dallas", 1_300_000);
    }

    // метод для печати массива + строка-анонс списка
    public void printArray(Object[] arr, String title) {
        System.out.println("===== " + title + " =====");
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    // будем искать город в массиве BinarySearch, что он нам вернет
    // BinarySearch можно применять только к отсортированному массиву
    @Test
    void testBinarySearch() {
        printArray(cities, " Original array ");
        Arrays.sort(cities); // сортировка естественный порядке
        printArray(cities, " Natural order (population) ");
        // теперь можем примменять BinarySearch
        City patttern = new City(null, 5);
        int index = Arrays.binarySearch(cities, patttern);
        System.out.println("Index = " + index);
    }

    // сортировку по имени используем Comporator
    @Test
    void testBinarySearchName() {
        printArray(cities, " Original array ");
        //(версия 1) Comparator <City> cityComparator = (c1, c2) -> c1.getName().compareTo(c2.getName());
        /*(версия 2)Comparator <City> cityComparator = new Comparator<City>() {
            @Override
            public int compare(City o1, City o2) {
                return o1.getName().compareTo(o2.getName());
            }
        };*/
        Comparator<City> cityComparator = Comparator.comparing(City::getName); // определение 1 шаг
        //  Arrays.sort(cities, cityComparator); // сортировка 2 шаг
        printArray(cities, "Sort by Name");
        City pattern = new City("Chicago", 2_700_011);
        int index = Arrays.binarySearch(cities, pattern, cityComparator);
        System.out.println("Index = " + index);
    }

    // Увеличиваем массив в 2 раза
    @Test
    void testArrayCopy() {
        City[] cityesCopy = Arrays.copyOf(cities, cities.length * 2);
        // printArray(cityesCopy, "cityesCopy before sorting");
        // попытаемся провести сортировку
        Comparator<City> cityComparator = Comparator.comparing(City::getName); // определение 1 шаг
        Arrays.sort(cityesCopy, 0, cities.length, cityComparator);
        // сортитовать можно только часть массива без null
        printArray(cityesCopy, "After Copy");
    }

    @Test
    void testCopyOfRange() {
        printArray(cities, "Original Array");
        City[] cityCopyRange = Arrays.copyOfRange(cities, 1, cities.length - 1);
        printArray(cityCopyRange, "cityCopyRange Array");
    }

    @Test
    void testSystemyArrayCopy() {
        printArray(cities, "Original Array");
        City[] citiesCopy = new City[cities.length * 2];
        System.arraycopy(cities, 1, citiesCopy, 5, 8);
        printArray(citiesCopy, "System.arraycopy citiesCopy Array");

    }

    @Test
    void testInsertAndKeepSorted() {
        printArray(cities, " Original array ");
        Arrays.sort(cities); // сортировка естественный порядке
        printArray(cities, " Natural order (population) ");
        City city = new City("SanFrancisco", 670_000);
        // Скопировать массив в новый массив с длинной +1
        City[] citiesCopy = Arrays.copyOf(cities, cities.length + 1);
        // Найти индекс для вставляемого города с помощью Bi
        int index = Arrays.binarySearch(citiesCopy, 0, citiesCopy.length - 1, city);
        // определить реальный индекс
        index = index >= 0 ? index : -index - 1; //позиция куда вставлять см. теорию прошлого урока
        //сдвинуть весь массив на 1 позицию (Освободить место для нового города)
        System.arraycopy(citiesCopy, index, citiesCopy, index + 1, citiesCopy.length - index - 1);
        citiesCopy[index] = city;
        cities = citiesCopy;
        printArray(cities, " Natural order (population) + 1");
    }
}