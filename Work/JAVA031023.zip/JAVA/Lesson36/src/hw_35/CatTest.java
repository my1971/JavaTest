package hw_35;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;

class CatTest {

    Cat[] cats; // массив из объектов типа Cat

    @BeforeEach
    void setUp() {
        cats = new Cat[]{
                new Cat("Murzik", 5, "black", 4.8),
                new Cat("Garfild", 12, "gray", 9.0),
                new Cat("Lusy", 3, "white", 4.5),
                new Cat("Ponchik", 6, "red", 6.5)
        };
        // или так
        // cats[0] = new Cat("Vaska", 7, "yellow", 6.0);
        // ...
    }

    @Test
    void testSort() {
        printArray(cats, "Original array");
        Arrays.sort(cats);
        printArray(cats, "Sorting by age");
    }

    public void printArray(Object[] arr, String string) {
        System.out.println("=========" + string + "=============");
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
        System.out.println("====================================");
    }

    @Test
    void testBinarySearch() {
        // печать массива как есть
        printArray(cats, "Original Array");
        // сортировка компаратором по весу
        Comparator<Cat> catSComparator = Comparator.comparing(Cat::getWeight);
        Arrays.sort(cats, catSComparator);
        printArray(cats, "Sorting by weight");
        // поиск BinarySearch НЕсуществующего элемента
        // Cat pattern = new Cat("", 0, "", 9.0);
        //  int index = Arrays.binarySearch(cats,new Cat("", 0, "", 9.0), catSComparator);
        System.out.println("Index = " + Arrays.binarySearch(cats, new Cat("", 0, "", 9.0), catSComparator));
        // Cat pattern1 = new Cat("", 0, "", 8.0);
        System.out.println("Index = " + Arrays.binarySearch(cats, new Cat("", 0, "", 8.0), catSComparator));
        System.out.println("Index = " + Arrays.binarySearch(cats, new Cat("", 0, "", 5.0), catSComparator));

    }
}