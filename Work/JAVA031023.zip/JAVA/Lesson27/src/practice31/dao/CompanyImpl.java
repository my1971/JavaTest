package practice31.dao;

import practice31.model.Employee;

public class CompanyImpl  implements Company{
    @Override
    public boolean addEmployee(Employee employee) {
        return false;
    }

    @Override
    public Employee removeEmployee(int id) {
        return null;
    }

    @Override
    public Employee findEmployee(int id) {
        return null;
    }

    @Override
    public int siz() {
        return 0;
    }

    @Override
    public void printEmployee() {

    }
}
