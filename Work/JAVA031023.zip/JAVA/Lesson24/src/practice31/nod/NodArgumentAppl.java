package practice31.nod;

public class NodArgumentAppl {
    public static void main(String[] args) { // в качестве аргумента передаем строки из масива который называется argsarg
        int n = args.length; //Сколько параметров передали в коммандной строке
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        Nod nod;
        nod = new Nod();
        System.out.println(nod.nod(a,b));


    }
}
