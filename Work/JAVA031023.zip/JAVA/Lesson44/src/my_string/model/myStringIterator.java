package my_string.model;

import java.util.Iterator;

public class myStringIterator implements Iterator<Character> {
    private final StringBuilder str;
    private int size;
    private int currPosition;

    public myStringIterator(StringBuilder str) {
        this.str = str;
        size = str.length();
        //currPosition = 0;
    }

    @Override
    public boolean hasNext() {
        return currPosition < size;
    }

    @Override
    public Character next() {
        Character currCharacter = str.charAt(currPosition);
        currPosition++;
        return currCharacter;

    }

    public void remove() {
        str.deleteCharAt(--currPosition);
        size--;
    }
}
