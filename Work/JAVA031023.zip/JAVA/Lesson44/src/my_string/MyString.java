package my_string;

import my_string.model.myStringIterator;

import java.util.Iterator;

public class MyString {
    private StringBuilder str; // StringBuilder это встроенный в JAVA класс

    //иконструктор
    public MyString(String str) {
        this.str = new StringBuilder(str);
    }

    //метод возвращает iterator
    public Iterator<Character> iterator() {
        return new myStringIterator(str);
    }

//    public StringBuilder getStr() {
//        return str;
//    }

    public void setStr(StringBuilder str) {
        this.str = str;
    }

    public void addChar(char c) {
        str.append(c);
    }

    public void remuveChar(char c) {
        int index = str.indexOf(Character.toString(c)); // нашли индекс на котором стоит с
        str.deleteCharAt(index);
    }

    public String toString() {
        return str.toString();
    }
}
