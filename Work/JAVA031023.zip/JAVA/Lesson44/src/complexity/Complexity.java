package complexity;

public class Complexity {
    public static void main(String[] args) {
        int[] arr = new int[]{2, 3, 500, 7, 11, 13, 17, 19, 3, 500, 70, 11, 13, 170, 19, 3, 500, 7, 11, 13, 17, 19, 3, 500, 70, 11, 13, 170,};
        double mid = (arr[0] + arr[arr.length - 1]) / 2;
        System.out.println(mid);
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }

        System.out.println(sum);
        System.out.println(sum / arr.length);
//сортировка
        boolean sorted = false;
        int temp;
        int per = 0;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < arr.length - 1; i++) {
                if (arr[i] > arr[i + 1]) {
                    temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                    sorted = false;
                }
            }
            per++;
        }
        System.out.println("////////////version 1/////////////////");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " | ");
        }
        System.out.println();
        System.out.println(per);
        per = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i; j < arr.length - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
            per++;
        }
        System.out.println("////////////version 2/////////////////");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " | ");
        }
        System.out.println();
        System.out.println(per);

    }


}

