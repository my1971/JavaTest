package practice.forumKlass.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice.forumKlass.model.Post;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class ForumImplTest {
    Forum forum;
    Post[] posts = new Post[10];

    @BeforeEach
    void setUp() {
        forum = new ForumImpl();
        posts[0] = new Post(1, "title1", "author1", "content");
        posts[1] = new Post(2, "title2", "author2", "content");
        posts[2] = new Post(3, "title3", "author2", "content");
        posts[3] = new Post(4, "title4", "author1", "content");
        posts[4] = new Post(5, "title4", "author3", "content");
        posts[5] = new Post(6, "title4", "author4", "content");
        posts[6] = new Post(7, "title4", "author7", "content");
        posts[7] = new Post(8, "title4", "author1", "content");
        posts[8] = new Post(9, "title4", "author9", "content");
        posts[9] = new Post(10, "title4", "author10", "content");

        for (int i = 0; i < posts.length - 1; i++) {
            forum.addPost(posts[i]);
        }
    }

    @Test
    void addPost() {
        //TODO assert throw if forum.addPost(null)
        boolean flag;
        try {
            forum.addPost(null);
            flag = true;
        } catch (RuntimeException e) {
            flag = false;
        }
        assertFalse(flag);
        // assertTrue(forum.addPost(posts[5]));
        assertEquals(9, forum.size());
        assertFalse(forum.addPost(posts[5]));
        assertEquals(9, forum.size());
    }

    @Test
    void removePost() {
        assertTrue(forum.removePost(2));
        assertEquals(8, forum.size());
        assertFalse(forum.removePost(2));
        assertEquals(8, forum.size());
    }

    @Test
    void updatePost() {
        System.out.println(posts[0]);
        assertTrue(forum.updatePost(1, "NEW CONTENT"));
        assertEquals("NEW CONTENT", forum.getPostById(1).getContent());
        System.out.println(posts[0]);
    }

    @Test
    void getPostById() {
        assertEquals(posts[3], forum.getPostById(4));
        assertNull(forum.getPostById(14));
    }

    @Test
    void getPostsByAuthor() {
        Post[] actual = forum.getPostsByAuthor("author1");
        Arrays.sort(actual);
        for (int i = 0; i < actual.length; i++) {
            System.out.println(actual[i]);
        }
        System.out.println("--------------------");
        Post[] expected = {posts[0], posts[3], posts[7]};
        for (int i = 0; i < expected.length; i++) {
            System.out.println(expected[i]);
        }
        assertArrayEquals(expected, actual);
    }

    @Test
    void testGetPostsByAuthor() {
        posts[0].setDate(LocalDateTime.now().minusDays(6));
        posts[1].setDate(LocalDateTime.now().minusDays(9));
        posts[2].setDate(LocalDateTime.now().minusDays(5));
        posts[3].setDate(LocalDateTime.now().minusDays(7));
        posts[4].setDate(LocalDateTime.now().minusDays(10));
        posts[5].setDate(LocalDateTime.now().minusDays(8));
        posts[6].setDate(LocalDateTime.now().minusDays(18));
        posts[7].setDate(LocalDateTime.now().minusDays(12));
        posts[8].setDate(LocalDateTime.now().minusDays(13));
        posts[9].setDate(LocalDateTime.now().minusDays(11));
        forum = new ForumImpl();
        for (int i = 0; i < posts.length; i++) {
            forum.addPost(posts[i]);
        }
        Post[] actual = forum.getPostsByAuthor("author1", LocalDate.now().minusDays(8), LocalDate.now().minusDays(5));
        Arrays.sort(actual);
        System.out.println("--------------Array actual----------");
        for (int i = 0; i < actual.length; i++) {
            System.out.println(actual[i]);
        }
        System.out.println("--------------Array expected----------");
        Post[] expected = {posts[0], posts[2], posts[3], posts[5]};
        for (int i = 0; i < expected.length; i++) {
            System.out.println(expected[i]);
        }
        assertArrayEquals(expected, actual);
    }

    @Test
    void size() {
        assertEquals(9, forum.size());
    }
}