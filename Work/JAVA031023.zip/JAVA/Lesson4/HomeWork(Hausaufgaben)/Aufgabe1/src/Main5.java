import java.util.Scanner;

public class Main5 {
    public static void main(String[] args) {
        /*
        Сделайте расчет покупки товаров со скидками. Стоимость, количество товаров и скидку на них вводит
        пользователь. Товар А стоит X руб и на него скидка D%, а товар B стоит Y руб и на него скидка С%.
         Клиент взял N товаров A и M товаров B. Выведите итоговую стоимость покупки.
         */
        System.out.println(" --- *** Магазин *** ---");
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите стоимость первого товара - ");
        double PerProdukt1 = sc.nextDouble(); // стоимость товара 1
        System.out.print("Введите стоимость второго товара - ");
        double PerProdukt2 = sc.nextDouble(); // стоимость товара 2
        System.out.print("Введите процент скидки - ");
        double PerAngebot = sc.nextDouble(); // Процент скидки

        System.out.println("Цена 1 товара - " + PerProdukt1);
        System.out.println("Цена 2 товара - " + PerProdukt2);
        System.out.println("-------------------------------------------");
        System.out.println("Стоимость товара = " + (PerProdukt1 + PerProdukt2));
        System.out.println("Скидка = " + ((PerProdukt2) * PerAngebot/100));
        System.out.println("Стоимость товара со скидкой = " + ( PerProdukt1 + (PerProdukt2-
                                                    (PerProdukt2 * PerAngebot/100))));
    }
}
