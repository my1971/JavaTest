public class Main4 {
    public static void main(String[] args) {
        /*Пусть цена товара A обычно составляет 1000 евро, и товара B составляет 500 евро.
        Если клиент покупает товары вместе, то на них действует скидка 10% на всю покупку.
         Выведите на экран стоимость суммы A + B со скидкой. Отдельно выведите на экран
         абсолютную величину скидки для этой покупки.
         */
        System.out.println(" --- *** Магазин *** ---");
        int PerProdukt1 = 1000, PerProdukt2 = 500;

        System.out.println("Цена 1 товара - " + PerProdukt1);
        System.out.println("Цена 2 товара - " + PerProdukt2);
        System.out.println("-------------------------------------------");
        System.out.println("Стоимость товара = " + (PerProdukt1 + PerProdukt2));
        System.out.println("Скидка = " + ((PerProdukt1 + PerProdukt2) * 0.1));
        System.out.println("Стоимость товара со скидкой = " + ( PerProdukt1 + PerProdukt2-
                                                    ((PerProdukt1 + PerProdukt2) * 0.1)));
    }
}
