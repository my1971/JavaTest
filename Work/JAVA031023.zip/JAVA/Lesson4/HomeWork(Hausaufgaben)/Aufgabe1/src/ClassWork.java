import java.util.Scanner;
import java.io.*;

public class ClassWork {
    public static void main(String[] args) throws IOException {
        String Per1 = "15";
        int n1 = Integer.parseInt(Per1);
        System.out.println(n1);
    }
}
