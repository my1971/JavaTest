package practice31;

import practice31.model.Computer;

public class ComputerComputerAppl {
    public static void main(String[] args) {
        Computer comp1 = new Computer();
        comp1.setRam(-32);
        comp1.setCpu("CatsDogs");
        comp1.setSsd(-512);
        comp1.computerTutOn();

        System.out.println(comp1);
        Computer comp2 = new Computer( "17", 16,512,"On", "Br");
        System.out.println(comp2);
    }
}
