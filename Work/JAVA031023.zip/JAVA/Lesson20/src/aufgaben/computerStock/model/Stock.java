package aufgaben.computerStock.model;

public class Stock {
/*    Task 3. Implement a computer warehouse by analogy with a book and a library (a task for the whole week).
    Задача3. Реализовать компьютерный склад по аналогии с книгой и библиотекой (задание на всю неделю).*/

    private Computer[] computers; // массив типа Computer, куда попадут все Computers
    private int size = 0; // количество Computers в Stock

    // Метод класса, который задает количество компьютеров, т.е. длину массива Computer
    public Stock(int capacity) {
        computers = new Computer[capacity];
    }

    // метод добавление книги
    public boolean addComputer(Computer computer) {
        if ((size == computers.length) || findComputer(computer.getIsbn()) != null) {
            return false; // не можем добавить Computer, так как нем места или такой компьютер уже есть
        }
        computers[size] = computer; // помещаем Computer в массив
        size++;
        return true;
    }

    public void display() { // Метод вывода на кран массива
        for (int i = 0; i < size; i++) {
            System.out.println(computers[i]);
        }
    }

    // метод поиска книги по ISBN
    public Computer findComputer(long isbn) {
        for (int i = 0; i < size; i++) { // пробегаем по массиву
            if (computers[i].getIsbn() == isbn) { // проверяем совпадение ISBN
                return computers[i]; // возвращаем элемент массива типа Computers
            }
        }
        return null;
    }

    public int getSize() {
        return size;
    } // метод возвращает размер

    public Computer removeComputer(long isbn) {
        Computer victim = null;
        for (int i = 0; i < size; i++) { // пробегаем по массиву
            if (computers[i].getIsbn() == isbn) { // проверяем совпадение ISBN
                victim = computers[i];
                computers[i] = computers[size - 1]; // на место удаляемого ставим последний Computer
                computers[size - 1] = null; // последний Computer стираем, тк она теперь стоит на месте удаленной
                size--;
                break;
            }
        }
        System.out.println("Computer # " + ((victim == null) ? (isbn + " not found") : (victim + " is  deleted")));
        return victim;
    }
}
//    public Computer removeComputer(long isbn, Computer[] computers ){
//        Computer victim = null;
//        for (int i = 0; i < size; i++) {
//            if(computers[i].getIsbn() == isbn){
//                victim = computers[i];
//                computers[i] = computers[size - 1]; // на место удаляемого ставим последний Computer
//                computers[size - 1] = null; // последний Computer стираем, тк она теперь стоит на месте удаленной
//                size--;
//                break;
//            }
//        }
//        return victim;
//    }

