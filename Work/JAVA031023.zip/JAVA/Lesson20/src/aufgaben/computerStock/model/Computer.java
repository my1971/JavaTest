package aufgaben.computerStock.model;

import java.util.Objects;

public class Computer {
    public static final int ISBN_LENGTH = 13;
    private final long isbn;
    public String brand;
    public double price;
    public int yearOfReceipt;
    public String cpu;
    public int ram;
    public int ssd;
    // Constructor und Special method (конструктор специальный метод)
    private long checkIsbn(long isbn) {
        if (countDigits(isbn) == ISBN_LENGTH) {
            return isbn;
        }
        return -1;
    }
    private int countDigits(long isbn) {
        int count = 0;
        do {
            count++;
            isbn /= 10; // isbn = isbn / 10;
        } while (isbn != 0);
        return count;
    }
// Конструктор создает конкретный объект данного класса

    public Computer(long isbn, String brand, double price, int yearOfReceipt, String cpu, int ram, int ssd) {
        this.isbn = isbn;
        this.brand = brand;
        this.price = price;
        this.yearOfReceipt = yearOfReceipt;
        this.cpu = cpu;
        this.ram = ram;
        this.ssd = ssd;
    }

    public long getIsbn() {return isbn;}
    public double getPrice() {return price;}
    public void setPrice() {setPrice(0.00);}
    public void setPrice(double price) {this.price = price;}
    public int getYearOfReceipt() {return yearOfReceipt;}
    public void setYearOfReceipt(int yearOfReceipt) {this.yearOfReceipt = yearOfReceipt;}
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getCpu() {return cpu;}
    public void setCpu(String cpu) {this.cpu = cpu;}
    public int getRam() {return ram;}
    public void setRam(int ram) {this.ram = ram;}
    public int getSsd() {return ssd;}
    public void setSsd(int ssd) {this.ssd = ssd;}


    public String toString() {
        return "Computer{" +
                "ISBN = " + isbn +
                ", Brand = '" + brand + '\'' +
                ", Price = '" + price + '\'' +
                ", Year Of Receipt = " + yearOfReceipt +
                ", CPU = '" + cpu + '\'' +
                ", Ram = " + ram +
                ", SSD = " + ssd + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Computer computer = (Computer) o;
        return isbn == computer.isbn && Double.compare(computer.price, price) == 0 && yearOfReceipt == computer.yearOfReceipt
                && ram == computer.ram && ssd == computer.ssd && Objects.equals(brand, computer.brand) && Objects.equals(cpu, computer.cpu);
    }
    @Override
    public int hashCode() {
        return Objects.hash(isbn, brand, price, yearOfReceipt, cpu, ram, ssd);
    }

}
