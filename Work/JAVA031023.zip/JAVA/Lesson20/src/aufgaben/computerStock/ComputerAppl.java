package aufgaben.computerStock;

import aufgaben.computerStock.model.Computer;
import aufgaben.computerStock.model.Stock;

public class ComputerAppl {
    public static void main(String[] args) {
        // create Library
        Stock stock = new Stock(10);
        // add Computer
        stock.addComputer(new Computer(2000000000000l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000001l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000002l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000003l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000004l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000005l, "Intel 8",2000.00, 1988,"i8", 8,512));
        stock.addComputer(new Computer(2000000000006l, "Intel 8",2000.00, 1988,"i8", 8,512));
        System.out.println("*****************************  metod display *************************************************************");
        stock.display();

        System.out.println("*****************************  metod find ***************************************************************");
        // Поиск компьютера по ISBN
        System.out.println("Computer № " + 2000000000002l  + " - " +  stock.findComputer(2000000000002l));
        System.out.println("Computer № " + 3000000000002l  + " - " +  stock.findComputer(3000000000002l));
        System.out.println("*****************************  metod delete *************************************************************");
        // удаление компьютера
        stock.removeComputer( 5000000000002l);
        stock.removeComputer( 2000000000002l);

        System.out.println("*****************************  metod display *************************************************************");
        stock.display();
        System.out.println("**********************************************************************************************************");
    }
}