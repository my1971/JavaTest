public class Rocket {
    public static void main(String[] args) {
    /*    Задача 2. Запустить обратный отсчет старта ракеты от 10 до 0. Последнее сообщение: "Поехали!..."..*/
        int perCountDown = 10;
        while (perCountDown >= 0){
            System.out.println("to Start left: " + perCountDown);
            perCountDown--;
        } //end of while
        System.out.println("\"Поехали!...\"..");
    }
}