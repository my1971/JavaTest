import java.util.Scanner;

public class Nummer {
    public static void main(String[] args) {
    //   Задача 4. Пользователь вводит натуральное число (целое, положительное). Выясните, сколько цифр в числе.
        Scanner sc = new Scanner(System.in);
        System.out.println("Input integer and positive number - ");
        int  i = 0;
        int perN = sc.nextInt();
        while (perN > 0){
            perN = perN / 10;
            i++;
        } //end of while
        System.out.println("In diese number = " + i + " Symbol.");
    }
}