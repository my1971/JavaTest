import java.util.Scanner;

public class Aufgabe3 {
    public static void main(String[] args) {
/*  Задача 3. В первый день спортсмен пробежал s километров, а затем он каждый день увеличивал пробег на 10 %
    от предыдущего значения. Определите номер дня, на который пробег спортсмена составит не менее target километров.
    Программа получает на вход действительные числа s и target и должна вывести одно натуральное число.*/

        System.out.println("Exercise №3");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input how many kilometers did the athlete run the first day: ");
        double perS = sc.nextInt();
        System.out.print("Input how many kilometers the athlete had to run: ");
        int perTarget = sc.nextInt();
        int perDay =1;
        double perTemp = 0;
        System.out.println("On the " + perDay + "-th day did the athlete run " + perS);
        while (perS < perTarget){
//            perTemp = (Math.round(perS * 1000))/1000;
//            System.out.println("---------" + Math.round(perS * 10) +"----" + perTemp);
            perS= perS + (perS * 0.1);
            perDay++;
            System.out.println("On the " + perDay + "-th day did the athlete run " + perS);
        } //end of while
        System.out.println("--------------------------------------------------------");
        System.out.println(perDay + " days needed before " + perTarget + " km.");
    }
}
