# Lesson plan No. 53 dated 09/20/2023:

1. Map data structure in Java

2. HashMap "under hood"

3. analysis of the Map application using the example of the FibonacciExample, MockService, LanguageCard classes

_________________________________________________

# План урока № 53 от 20.09.2023:

1. Структура данных Map в Java

2. HashMap, что "под каопотом"

3. разбор применения Map на примере классов FibonacciExample, MockService, LanguageCard

