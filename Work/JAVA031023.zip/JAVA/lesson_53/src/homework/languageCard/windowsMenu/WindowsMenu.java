package homeworkMy.languageCard.windowsMenu;

import javax.swing.*;

public class WindowsMenu {
    public static void main(String[] args) {

        while (true) {
            String st = JOptionPane.showInputDialog("Input integer positive number:: ");
            if (st == null) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
           // isPrime.checkPrime((Integer.parseInt(st)));
           // int n = Integer.parseInt(st);

            int reply = JOptionPane.showConfirmDialog(null, "Continie?", "Question?", JOptionPane.YES_NO_OPTION);
            if (!(reply == JOptionPane.YES_OPTION)) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
        }
    }
}
