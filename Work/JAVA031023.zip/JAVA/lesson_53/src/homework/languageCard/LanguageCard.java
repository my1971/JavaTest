package homeworkMy.languageCard;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


public class LanguageCard {
    // Хранилище для слов и их переводов
    private HashMap<String, String> wordMap = new HashMap<>();

    // Метод для добавления нового слова и его перевода
    public void addWord(String foreignWord, String nativeWord) {
        wordMap.put(foreignWord, nativeWord);
    }

    // Метод для практики слов
    public void practice() {
        if (wordMap.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Словарь пуст. Пожалуйста, добавьте слова для практики.");
            return;
        }
        HashMap<String, Integer> mapErrors = new HashMap<>();
        Random random = new Random();
        String randomKey;
        String correctAnswer;
        String userAnswer;
        while (true) {
            // Преобразование ключей мапы в список для удобного доступа
            ArrayList<String> keys = new ArrayList<>(wordMap.keySet());
            // Случайный выбор слова для проверки
            randomKey = keys.get(random.nextInt(keys.size()));
            correctAnswer = wordMap.get(randomKey);
            // Задаем вопрос
            userAnswer = JOptionPane.showInputDialog("Каков перевод слова " + randomKey + "?");
            if (userAnswer == null) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
            // Проверка ответа
            if (correctAnswer.equalsIgnoreCase(userAnswer)) {
                JOptionPane.showMessageDialog(null, "Верно!");
            } else {
                Integer count = 1;
                while (true){
                    if (!mapErrors.isEmpty() && mapErrors.containsKey(randomKey)){
                        count = mapErrors.get(randomKey) + 1;
                    }
                    mapErrors.put(randomKey, count);
                    JOptionPane.showMessageDialog(null, count + " Неверных ответов! Правильный ответ: " + correctAnswer);
                    userAnswer = JOptionPane.showInputDialog("Каков перевод слова " + randomKey + "?");
                    if (userAnswer == null) {
                        JOptionPane.showMessageDialog(null, "Thanks?");
                        break;
                    }
                    // Проверка ответа
                    if (correctAnswer.equalsIgnoreCase(userAnswer)) {
                        JOptionPane.showMessageDialog(null, "Верно!");
                        break;
                    }


                }

            }
            //продолжение
            int reply = JOptionPane.showConfirmDialog(null, "Continie?", "Question?", JOptionPane.YES_NO_OPTION);
            if (!(reply == JOptionPane.YES_OPTION)) {
                JOptionPane.showMessageDialog(null, "Thanks? bye!");
                break;
            }
        }
    }
    public static void main(String[] args) {
        // Пример использования класса LanguageCard
        LanguageCard myCard = new LanguageCard();

         //Добавление слов
        myCard.addWord("apple", "яблоко");
        myCard.addWord("dog", "собака");
        myCard.addWord("hello", "привет");
        myCard.addWord("cat", "кошка");
        myCard.addWord("printer", "принтер");

        // Запуск практики
        myCard.practice();
    }
}

