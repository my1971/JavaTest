# Lesson plan No. 50 dated 09/13/2023:

1. Practice Working with Set

2. Theory of HashCode and equals

3. Practice HashCode and equals contract

_________________________________________________

# План урока № 50 от 13.09.2023:

1. Практика работы с Set

2. Теория HashCode и equals

3. Приактика контракта HashCode и equals




















