package practice41.album.dao;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice41.album.model.Photo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class AlbumImplTestAlt {

    AlbumImpl albums;
    LocalDateTime now = LocalDateTime.now();
    Photo[] ph = new Photo[6];

    @BeforeEach
    void setUp() {
        albums = new AlbumImpl(7);
        ph[0] = new Photo(1, 1, "Title1", "url1", now.minusDays(10));
        ph[1] = new Photo(1, 2, "Title2", "url1", now.minusDays(11));
        ph[2] = new Photo(1, 3, "Title3", "url1", now.minusDays(12));
        ph[3] = new Photo(2, 1, "Title4", "url1", now.minusDays(7));
        ph[4] = new Photo(2, 4, "Title5", "url1", now.minusDays(5));
        ph[5] = new Photo(3, 1, "Title6", "url1", now.minusDays(16));
        //  ph[6] = new Photo(3,2,"Title7", "url1", now.minusDays(12));
        for (int i = 0; i < ph.length; i++) {
            albums.addPhoto(ph[i]);
        }
    }

    @Test
    void addPhoto() {
        assertFalse(albums.addPhoto(null));
        assertFalse(albums.addPhoto(ph[1]));
        Photo photo = new Photo(3, 2, "Title7", "url1", now.minusDays(12));
        assertTrue(albums.addPhoto(photo));
        assertFalse(albums.addPhoto(photo));
    }

    @Test
    void removePhoto() {
        assertFalse(albums.removePhoto(5, 1));
        assertTrue(albums.removePhoto(1, 1));
        assertEquals(5, albums.size());
        assertNull(albums.getPhotoFromAlbum(1, 1));
    }

    @Test
    void updatePhoto() {
        assertTrue(albums.updatePhoto(1, 1, "Newurl"));
        assertEquals("Newurl", albums.getPhotoFromAlbum(1, 1).getUrl());
    }

    @org.junit.jupiter.api.Test
    void getPhotoFromAlbum() {
        assertEquals(ph[0], albums.getPhotoFromAlbum(1, 1));

    }

    @Test
    void getAllPhotoFromAlbum() {
        Photo[] actual = albums.getAllPhotoFromAlbum(1);
        Arrays.sort(actual);
        Photo[] expected = {ph[0], ph[1], ph[2]};
        // assertArrayEquals(expected, actual);


    }

    @Test
    void getPhotoBetweenDate() {
        LocalDate ld = now.toLocalDate();
        System.out.println(ld);
        Photo[] actual = albums.getPhotoBetweenDate(ld.minusDays(5), ld.minusDays(2));
        Arrays.sort(actual);

    }

    @Test
    void size() {
    }
}