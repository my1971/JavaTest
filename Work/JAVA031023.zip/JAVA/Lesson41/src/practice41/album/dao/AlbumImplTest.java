package practice41.album.dao;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice41.album.model.Photo;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class AlbumImplTest {

    AlbumImpl albums;
    LocalDateTime now = LocalDateTime.now();
    Photo[] ph = new Photo[6];

    @BeforeEach
    void setUp() {

        albums = new AlbumImpl(7);
        ph[0] = new Photo(1, 1, "title1", "url1", now.minusDays(7));
        ph[1] = new Photo(1, 2, "title2", "url2", now.minusDays(7));
        ph[2] = new Photo(1, 3, "title3", "url3", now.minusDays(5));
        ph[3] = new Photo(2, 1, "title4", "url1", now.minusDays(7));
        ph[4] = new Photo(2, 4, "title5", "url4", LocalDateTime.of(now.minusDays(2).toLocalDate(), LocalTime.MAX));
        ph[5] = new Photo(1, 4, "title6", "url1", LocalDateTime.of(now.minusDays(2).toLocalDate(), LocalTime.MAX));

        for (int i = 0; i < ph.length; i++) {
            albums.addPhoto(ph[i]);
        }

    }

    @Test
    void addPhotoTest() {
        assertFalse(albums.addPhoto(null)); // добавление пустого фото
        assertFalse(albums.addPhoto(ph[1])); // добавление имеющегося
        Photo photo = new Photo(1, 5, "title5", "url5", now.minusDays(3));
        assertTrue(albums.addPhoto(photo));
        assertEquals(7, albums.size());
        photo = new Photo(1, 6, "title6", "url6", now.minusDays(3));
        assertFalse(albums.addPhoto(photo)); // добавление сверх capacity

    }

    @Test
    void removePhoto() {
        assertFalse(albums.removePhoto(5, 1)); // не можем удалить несуществующее фото
        assertTrue(albums.removePhoto(1, 1));
        assertEquals(5, albums.size());
        assertNull(albums.getPhotoFromAlbum(1, 1));
    }

    @Test
    void updatePhoto() {
        assertTrue(albums.updatePhoto(1, 1, "newUrl"));
        assertEquals("newUrl", albums.getPhotoFromAlbum(1, 1).getUrl());
    }

    @Test
    void getPhotoFromAlbum() {
        assertEquals(ph[0], albums.getPhotoFromAlbum(1, 1));
        assertNull(albums.getPhotoFromAlbum(3, 3));
    }

    @Test
    void getAllPhotoFromAlbum() {
        Photo[] actual = albums.getAllPhotoFromAlbum(2);
        Arrays.sort(actual);
        Photo[] expected = {ph[3], ph[4]};
        assertArrayEquals(expected, actual);
    }

    @Test
    void getPhotoBetweenDate() {
//        LocalDate ld = now.toLocalDate(); //
//        System.out.println(ld);
//        LocalDate ld1;
//        ld1 = albums.inDate("2023-01-01");
//        System.out.println(ld1);
        //Photo[] actual = albums.getPhotoBetweenDate(ld.minusDays(5), ld.minusDays(2));
        Photo[] actual = albums.getPhotoBetweenDate(albums.inDate("12:8:23"), albums.inDate("2023-8-15"));
        for (int i = 0; i < actual.length; i++) {
            System.out.println(actual[i]);
        }
        Arrays.sort(actual);
        Photo[] expected = {ph[3], ph[0], ph[1]};
        //  assertArrayEquals(expected, actual);
    }

    @Test
    void size() {
        assertEquals(6, albums.size());
    }
}