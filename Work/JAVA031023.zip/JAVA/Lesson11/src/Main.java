import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        int a = 1, i = 0;
        boolean log = true;
        while (i < 10){
            a = a * 10;
            i++;
            System.out.println(a + "---" + i);
            JOptionPane.showMessageDialog(null, a + "---" + i );
        }

    }
}
