import javax.swing.*;

public class Aufgabe11_2 {
    public static void main(String[] args) {
 /* Задача 2. Вводится n - натуральное число. Напишите метод, который получает на вход n и вычисляет
  n! = 1 * 2 * 3 *... * n (n факториал) 10! = 1 * 2 * 3 * ... * 10 Вызовите полученный метод.
  При каком значении n происходит переполнение памяти, выделяемой для n типа int? */

        long a = 20000000, i =10;
        boolean log = true;
        while (i < 22){
            a = a * 10;
            i++;
            System.out.println(a + "---" + i);
            JOptionPane.showMessageDialog(null, a + "---" + i );
        }

    }
}
