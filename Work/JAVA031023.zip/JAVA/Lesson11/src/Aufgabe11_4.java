
public class Aufgabe11_4 {
    public static void main(String[] args) {
//Задача 4 (*) Найти произведение двузначных нечетных чисел кратных 13.

        System.out.println("Number work");
        long a = 13, b = 0;
        boolean log = true;
        while (log){
            a = a +13;
            if (a % 2 >0){
                System.out.println("First number= " + a);
                break;}
        }
        b = a;
        while (log){
            b = b +13;
            if (b % 2 >0){
                System.out.println("Second number = " + b);
                break;}
        }
        System.out.printf("Multiplication of numbers %d * %d = %d", a, b, (a*b));
    }
}
