package aufgaben34.test;

import aufgaben34.arrayMethod.ArrayTools;
import aufgaben34.model.Soldier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Comparator;

class ArrayToolsHomeworkTest {
    Integer[] arrNum;
    String[] arrStr;
    Soldier[] soldiers;


    @Test
   /*Task 1. Make tests for the bubbleSort(T[] arr, Comparator comparator) method
        -   for integers
        -   for strings
    Задание 1. Сделать тесты для метода bubbleSort(T[] arr, Comparator comparator)
        -   для целых чисел
        -   для строк*/
    void testBubbleSortCoparatorInt() {
        System.out.println("================== Sort Array Num ==================");
        ArrayTools.printArray(arrNum);
        Comparator<Integer> comparator = (o1, o2) -> o1.compareTo(o2);
        ArrayTools.bubbleSort(arrNum, comparator);
        ArrayTools.printArray(arrNum);
    }

    @Test
    void testBubbleSortCoparatorString() {
        System.out.println("================== Sort Array String ==================");
        ArrayTools.printArray(arrStr);
        Comparator<String> comparator = (o1, o2) -> o1.compareTo(o2);
        ArrayTools.bubbleSort(arrStr, comparator);
        ArrayTools.printArray(arrStr);
    }

    @Test
    void testBubbleSortCoparator() {
        System.out.println("=========== Test by Name ===========");
        ArrayTools.printArray(soldiers);
        //  Arrays.sort(soldiers,(s1, s2) -> s1.getName().compareTo(s2.getName()));
        Comparator<Soldier> comparator = new Comparator<Soldier>() {
            @Override
            public int compare(Soldier o1, Soldier o2) {
                return o1.getName().compareTo(o2.getName());
            }
        };
        ArrayTools.bubbleSort(soldiers, comparator);
        ArrayTools.printArray(soldiers);
    }

    @Test
   /* Task 2. compare Soldiers by weight by height and then by weight
    Задание 2. сравнить Soldiers по весу, по росту и затем по весу*/
    void findByPredicateHome() {// Лямда выражение (->)

        ArrayTools.printArray(soldiers);
        System.out.println("================ compare Soldiers by weight < 76 ================");
        ArrayTools.printArray(ArrayTools.findByPredicateObjects(soldiers, soldier1 -> soldier1.getWeight() < 76));
        System.out.println("====== compare Soldiers by height > 174 and then by weight > 76 ======");
        ArrayTools.printArray(ArrayTools.findByPredicateObjects(soldiers, soldier1 -> soldier1.getWeight() > 76 && soldier1.getHeight() > 174));
    }

    @BeforeEach
    void setUp() {
        arrNum = new Integer[]{9, 7, 4, 7, 2, 5, 9, 1, 0};
        arrStr = new String[]{"one", "two", "three", "four", "five"};
        soldiers = new Soldier[]{
                new Soldier("John", 182, 82.3, 81),
                new Soldier("Peter", 175, 77.1, 75),
                new Soldier("Robin", 182, 69.3, 92),
                new Soldier("Mary", 159, 55.1, 91),
                new Soldier("Anna", 162, 50.0, 88)
        };
    }

    @Test
    void printArray() {
        System.out.println("================== Print Array ==================");
        ArrayTools.printArray(arrNum);
        ArrayTools.printArray(arrStr);
        ArrayTools.printArray(soldiers);
    }

}