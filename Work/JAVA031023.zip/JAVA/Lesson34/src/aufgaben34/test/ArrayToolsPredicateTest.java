package aufgaben34.test;

import aufgaben34.arrayMethod.ArrayTools;
import aufgaben34.model.Soldier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Objects;

class ArrayToolsPredicateTest {
    Integer[] arrNum;
    String[] arrStr;
    Soldier[] soldiers;


    @Test
    void findByPredicate() {// Лямда выражение (->)
        System.out.println("================== Test findByPredicate ==================");
        // для целых чисел
        ArrayTools.printArray(arrNum);
        ArrayTools.printArray(ArrayTools.findByPredicateT(arrNum, n -> n > 5 && n < 10));
        ArrayTools.printArray(ArrayTools.findByPredicateT(arrNum, n -> n < 7));


        System.out.println("================== Test findByPredicate  String ==================");
        ArrayTools.printArray(arrStr);
        ArrayTools.printArray(ArrayTools.findByPredicateT(arrStr, s -> Objects.equals(s, "four")));
        ArrayTools.printArray(ArrayTools.findByPredicateT(arrStr, s -> s.length() > 3));

        System.out.println("================== Test findByPredicate Soldiers==================");
        ArrayTools.printArray(soldiers);
        ArrayTools.printArray(ArrayTools.findByPredicateT(soldiers, soldier1 -> soldier1.getHeight() < 176));
        ArrayTools.printArray(ArrayTools.findByPredicateT(soldiers, soldier1 -> soldier1.getProfile() < 85));
    }

    @BeforeEach
    void setUp() {
        arrNum = new Integer[]{9, 7, 4, 7, 2, 5, 9, 1, 0};
        arrStr = new String[]{"one", "two", "three", "four", "five"};
        soldiers = new Soldier[]{
                new Soldier("John", 182, 82.3, 81),
                new Soldier("Peter", 175, 77.1, 75),
                new Soldier("Robin", 182, 69.3, 92),
                new Soldier("Mary", 159, 55.1, 91),
                new Soldier("Anna", 162, 50.0, 88)
        };
    }

    @Test
    void printArray() {
        System.out.println("================== Print Array ==================");
        ArrayTools.printArray(arrNum);
        ArrayTools.printArray(arrStr);
        ArrayTools.printArray(soldiers);
    }

}