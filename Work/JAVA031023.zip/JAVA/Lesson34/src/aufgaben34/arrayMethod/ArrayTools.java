package aufgaben34.arrayMethod;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.stream.IntStream;

public class ArrayTools {
    public static void printArray(Object[] arr) {
        for (Object o : arr) {
            System.out.println(o);
        }
        System.out.println("==============================================================================");

    }

    // поиск объекта в массиве Объектов
    public static int search(Object[] arr, Object value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(value)) {
                return i;
            }
        }
        return -1; // несуществующий индекс
    }

    public static boolean searchBoolean(Object[] arr, Object value) {
        return IntStream.range(0, arr.length).anyMatch(i -> arr[i].equals(value)); //РАБОТАЕТ ЗАМЕСТО ЭТОГО
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i].equals(value)) {
//                return true;
//            }
//        }

//        return false; // несуществующий индекс
    }

    // поиск объекта по условию

    public static <T> T[] findByPredicateT(T[] arr, Predicate<T> predicate) {

        //Метод возвращает тип Т[], из массива типа Т[], отбор по предикату
        int count = 0;// Счетчик найденных элементов'
        T[] existingT = Arrays.copyOf(arr, arr.length);// Создаем временный массив для хранения
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                existingT[count++] = arr[i]; // добавляем данные в массив
            }
        }
        return Arrays.copyOf(existingT, count);
    }

    public static <T> Object[] findByPredicateObjects(T[] arr, Predicate<T> predicate) {

        //Метод возвращает тип Т, из массива типа Т[], отбор по предикату
        int count = 0;// Счетчик найденных элементов'
        Object[] existingObject = new Object[arr.length];// Создаем временный массив для хранения
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                existingObject[count++] = arr[i]; // добавляем данные в массив
            }
        }
        return Arrays.copyOf(existingObject, count);
    }

    public static <T> int[] findByPredicate(T[] arr, Predicate<T> predicate) {
        //Метод возвращает тип Т, из массива типа Т[], отбор по предикату
        int count = 0;// Счетчик найденных элементов'
        int[] existingArray = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            if (predicate.test(arr[i])) {
                existingArray[count++] = i;
            }
        }
        int[] result = new int[count];
        System.arraycopy(existingArray, 0, result, 0, count);
        return result;
    }

    public static void unpackPrintArray(Object[] arr, int[] arrPrint) {
        for (int i = 0; i < arrPrint.length; i++) {
            System.out.println(arr[arrPrint[i]]);
        }
        System.out.println("==============================================================================");
    }

    //bubbleSort
    public static <T extends Comparable<T>> void bubbleSort(T[] arr) {
        // этот метод применим к типам (классам), в которых есть Comparable<T>
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // перестановка массива местами
                    T t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
    }

    //bubbleSorts by Comparator
    public static <T> void bubbleSort(T[] arr, Comparator<T> comparator) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (comparator.compare(arr[j], arr[j + 1]) > 0) {
                    T t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
            }
        }
    }
}
