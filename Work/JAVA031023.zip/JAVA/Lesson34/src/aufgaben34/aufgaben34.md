Task 1. Make tests for the bubbleSort(T[] arr, Comparator comparator) method
- for integers
- for strings
Задание 1. Сделать тесты для метода bubbleSort(T[] arr, Comparator comparator)
- для целых чисел
- для строк
Task 2. compare Soldiers by weight by height and then by weight
Задание 2. сравнить Soldiers по весу, по росту и затем по весу

Task 3. Read article https://javarush.com/groups/posts/modifier-static-java
Задание 3. Прочитать статью https://javarush.com/groups/posts/modifikator-static-java