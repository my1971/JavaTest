package practice.arrayMethod;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import practice.model.Soldier;

import java.util.Comparator;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ArrayToolsTest {
    Integer[] arrNum;
    String[] arrStr;
    Soldier[] soldiers;

    @BeforeEach
    void setUp() {
        arrNum = new Integer[]{9, 7, 4, 7, 2, 5, 9, 1, 0};
        arrStr = new String[]{"one", "two", "three", "four", "five"};
        soldiers = new Soldier[]{
                new Soldier("John", 182, 82.3, 81),
                new Soldier("Peter", 175, 77.1, 75),
                new Soldier("Robin", 182, 69.3, 92),
                new Soldier("Mary", 159, 55.1, 91),
                new Soldier("Anna", 162, 50.0, 88)
        };

    }

    @Test
    void printArray() {
        System.out.println("================== Print Array ==================");
        ArrayTools.printArray(arrNum);
        ArrayTools.printArray(arrStr);
        ArrayTools.printArray(soldiers);

    }

    @Test
    void search() {
        System.out.println("================== search  Num ==================");
        ArrayTools.printArray(arrNum);
        Integer res = ArrayTools.search(arrNum, 7);
        System.out.println(res);
        System.out.println(arrNum[res]);
        assertEquals(1, res);
        assertEquals(-1, ArrayTools.search(arrNum, 100));
        System.out.println("================== search STRING ==================");
        ArrayTools.printArray(arrStr);
        Integer index = ArrayTools.search(arrStr, "three");
        System.out.println(index);
        assertEquals(2, index);
        assertEquals(-1, ArrayTools.search(arrStr, "ghb"));
        System.out.println("================== search soldiers ==================");
        ArrayTools.printArray(soldiers);
        Integer resSoldiers = ArrayTools.search(soldiers, new Soldier("Robin", 162, 69.3, 82));
        System.out.println(resSoldiers);
        System.out.println(soldiers[resSoldiers]);
        assertEquals(2, resSoldiers);
        assertEquals(-1, ArrayTools.search(soldiers, "ghb"));
        System.out.println("-*-*-*-*-*-*-*-*");
        Integer resSoldiers1 = ArrayTools.search(soldiers, soldiers[20]);
        System.out.println(resSoldiers1);

    }

    @Test
    void searchBoolean() {
    }

    @Test
    void findByPredicate() {
        System.out.println("================== Test findByPredicate ==================");
        // для целых чисел
        // ArrayTools.printArray(arrNum);
//        Integer res = ArrayTools.findByPredicate(arrNum, n -> n > 5 && n < 10); // Лямда выражение (->)
//        System.out.println(res);
//        Integer res1 = ArrayTools.findByPredicate(arrNum, n -> n% 3 == 0 ); // Лямда выражение (->)
//        System.out.println(res1);
//        System.out.println("================== Test findByPredicate  String ==================");
//        String str = ArrayTools.findByPredicate(arrStr, s -> s == "four");
//        System.out.println(str);
//        assertEquals("four", str );
//        String str1 = ArrayTools.findByPredicate(arrStr, s -> s.length() == 5);
//        System.out.println(str1);
        System.out.println("================== Test findByPredicate Soldiers==================");
        ArrayTools.printArray(soldiers);
        Soldier soldier = ArrayTools.findByPredicate(soldiers, soldier1 -> soldier1.getHeight() < 160);
        System.out.println(soldier);
        assertEquals(soldiers[3], soldier);
    }

    @Test
    void testBubbleSort() {
//        System.out.println("================== Test findByPredicate Soldiers==================");
//        ArrayTools.printArray(arrNum);
//        ArrayTools.bubbleSort(arrNum);
//        ArrayTools.printArray(arrNum);
//        Integer[] expected = new Integer[] {0, 1, 2, 4, 5, 7, 7, 9, 9};
//        assertArrayEquals(expected,arrNum);
//        ArrayTools.printArray(arrStr);
//        ArrayTools.bubbleSort(arrStr);
//        ArrayTools.printArray(arrStr);

        ArrayTools.printArray(soldiers);
        ArrayTools.bubbleSort(soldiers);
        ArrayTools.printArray(soldiers);
    }

    @Test
    void testBubbleSortCoparator() {
        System.out.println("=========== Test by Name ===========");
        ArrayTools.printArray(soldiers);
        //  Arrays.sort(soldiers,(s1, s2) -> s1.getName().compareTo(s2.getName()));
        Comparator<Soldier> comparator = new Comparator<Soldier>() {
            @Override
            public int compare(Soldier o1, Soldier o2) {
                return o1.getName().compareTo(o2.getName());
            }
        };
        ArrayTools.bubbleSort(soldiers, comparator);
        ArrayTools.printArray(soldiers);
    }

    @Test
    void testSearchBoolean() {
        ArrayTools.searchBoolean(soldiers, "Vasy");
    }

}