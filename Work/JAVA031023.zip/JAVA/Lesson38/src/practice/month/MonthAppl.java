package practice.month;

import java.io.IOException;

public class MonthAppl {
    public static void main(String[] args) throws IOException {
        Month monrh = Month.DEC;
        System.out.println(monrh);
        System.out.println(monrh.plusMpnth(3)); //ожидаем март
        System.out.println(monrh.plusMpnth(12) + " Декабрь"); //ожидаем декабрь
        System.out.println(monrh.plusMpnth(13) + " Январь"); //ожидаем декабрь
        System.out.println("---------------------------");
        System.out.println(Month.getName(1));
        System.out.println(Month.getName(12));
        System.out.println(Month.getName(360));
        System.out.println("|количество дней по имени месяца");
        Month month1 = Month.AUG;
        // способ 1
        System.out.println(month1.getDays());
        // способ 2
        System.out.println(Month.AUG.getDays());
        System.out.println("====================================");
        for (int i = 1; i < 13; i++) {
            System.out.println(i % 12);
        }
    }

}
