package practice.month;

public enum Month {
    //Константы в JAVA (их имена) всегда создаются заглавными буквами
    JAN(31), FEB(28), MAR(31), APR(30), MAY(31), JUN(30), //Константы
    JUL(31), AUG(31), SEP(30), OCT(31), NOV(30), DEC(31);

    //поле класса
    private int days;
    //констроктоп

    Month(int days) { // вернет количество дней по имени месяца
        this.days = days;
    }

    // метод возвращает имя месяца по его номеру
    public static String getName(int num) { // static metod можно вызывать по имени класса
        Month[] values = values();
        return values[(num - 1) % values.length].name(); // возвращаем имя правильного месяца
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    //метод увеличивает количество месяцев
    public Month plusMpnth(int quantity) {
        int index = ordinal(); // взяли текущий номер месяца
        index = index + quantity; // увнличили
        Month[] values = values(); //определили массив values
        return values[index % values().length]; //разделили с остатком на 12
    }
}
