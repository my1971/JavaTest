package practice.seasons;

public enum Season {
    //Константы в JAVA (их имена) всегда создаются заглавными буквами
    WINTER, SPRING, SUMMER, AUTUMN

}
