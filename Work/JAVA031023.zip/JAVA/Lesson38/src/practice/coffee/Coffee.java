package practice.coffee;

public enum Coffee {
    ESPRESSO_SMALL(3.5, 50), ESPRESSO_GRAND(4.0, 150), AMERICANO(2.5, 200), CAPUCCINO(4.5, 300), LATTE(4.5, 350);
    private double prise;
    private int volume;

    Coffee(double prise, int volume) {
        this.prise = prise;
        this.volume = volume;
    }

    public double getPrise() {
        return prise;
    }

    public void setPrise(double prise) {
        this.prise = prise;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }
}
