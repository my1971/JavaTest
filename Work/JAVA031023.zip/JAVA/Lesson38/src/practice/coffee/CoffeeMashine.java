package practice.coffee;

import java.util.Scanner;

public class CoffeeMashine {
    public static void main(String[] args) {
        System.out.println("Wellcome to our Coffee Shop!");
        // предложить меню
        Coffee[] menu = Coffee.values();
        // понять выбор пользователя
        Scanner scanner = new Scanner(System.in);
        while (true) {
            for (int i = 0; i < menu.length; i++) {
                System.out.println((i + 1) + " - " + menu[i] + " = " + menu[i].getPrise());
            }
            System.out.println("0 -  EXIT MENU");
            System.out.println("================================================================");
            System.out.print("Input number of your choice : ");
            int choice = scanner.nextInt();
            if (choice == 0) {
                System.out.println("Good bay!!!");
                break;
            }
            if (choice > 0 && choice < 6) {
                System.out.println("Your choice is: " + menu[choice - 1].name());
                System.out.println("The volume is: " + menu[choice - 1].getVolume() + " ml");
                System.out.println("The price is: " + menu[choice - 1].getPrise() + " euro");
                break;
            } else {
                System.out.println("Wrong choice.");
                System.out.println(" ");
            }
        }
    }
}
