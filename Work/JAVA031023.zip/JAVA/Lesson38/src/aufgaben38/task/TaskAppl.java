package aufgaben38.task;

import java.util.Scanner;

public class TaskAppl {
    public static void main(String[] args) {
        System.out.println("--------------- Wellcome to our Company! ---------------");
        Task[] menu = Task.values();
        // понять выбор пользователя
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < menu.length; i++) {
            System.out.println(menu[i].getId() + " - " + menu[i]);
        }
        while (true) {
            System.out.println("================================================================");
            System.out.println("1 -  Add a record"); //добавить запись
            System.out.println("2 -  View all recordes"); // посмотреть все записи
            System.out.println("3 -  Delete record (by number)"); //удалить запись (по номеру)
            System.out.println("0 -  Exit MENU"); //выйти
            System.out.println("================================================================");
            System.out.print("Input number of your choice : ");
            int choice = scanner.nextInt();
            System.out.println("================================================================");
            if (choice == 0) {
                System.out.println("Good bay!!!");
                break;
            } else if (choice == 1) {
                System.out.println("----------------------  1 -  Add a record selected  ------------------------- ");
            } else if (choice == 2) {
                System.out.println("----------------------  2 -  View all recordes  ------------------------- ");
                for (int i = 0; i < menu.length; i++) {
                    System.out.println(menu[i].getId() + " - " + menu[i]);
                }
            } else if (choice == 3) {
                System.out.println("----------------------  3 -  Delete record (by number)  ------------------------- ");
            } else {
                System.out.println("Wrong choice.");
                System.out.println(" ");
            }

        }
    }
}

