package aufgaben38.task;

public enum Task {
    МИТИНГ(1), ЗАКУП(2), ОТКРЫТЬ_НАРЯД(3), ОПРЕДЕЛЕНИЕ_МЕР_БЕЗОПАСНОСТИ(4), ПРИСТУПИТЬ_К_РАБОТЕ(5),
    ОБЕД(6), ПРОДОЛЖИТЬ_РАБОТУ(7), ТЕСТИРОВАНИЕ(8), УБРАТЬСЯ(9), ЗАКРЫТЬ_НАРЯД(10);
    public int id;


    Task(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
