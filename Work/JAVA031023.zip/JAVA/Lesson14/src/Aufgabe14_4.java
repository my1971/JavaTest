
public class Aufgabe14_4 {
    public static void main(String[] args) {
//Задача 4.(*) (циклы и печать) Распечатать в консоли таблицу умножения.

        System.out.println("Таблица умножения");
        System.out.println("=================");
        int a = 2, b = 2;
        while (b < 10){
            System.out.println(a + " * " + b + " = " + a * b);
            a ++;
            if (a > 9){
                System.out.println("=================");
                a = 2;
                b++;
            }
        }
    }
}
