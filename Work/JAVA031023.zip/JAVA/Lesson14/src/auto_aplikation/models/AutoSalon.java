package auto_aplikation.models;

public class AutoSalon {
}
