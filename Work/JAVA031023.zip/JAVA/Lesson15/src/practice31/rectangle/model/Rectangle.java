package practice31.rectangle.model;

// этот файл - это и есть капсула для
// Название класса с большой буквы
public class Rectangle {
    // длина
    public double a;

    // ширина
    public double b;

    //Конструктор класса Rectangle


    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }
// SET для установки значений полей
    public void setA(double a) {
        this.a = a;
    }

    public void setB(double b) {
        this.b = b;
    }

    public Rectangle() {
    }

    // метод для вычисления периметра
    public double perimeter (double a, double b){
        return 2*a + 2*b;
    }
    public double perimeter2 (){
        return 2*a + 2*b;
    }
    // метод для вычисления площади
    public double square (double a, double b){
        return a*b;
    }

}
