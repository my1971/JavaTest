package aufgaben.cube.model;

/* Задача 1. Создать класс Cube, описывающий куб cо стороной a. Реализовать в нем методы определения
 периметра p, площади s и объема v. Создать приложение CubeAppl, в котором создать несколько экземпляров
 класса Cube. Для каждого экземпляра вызвать методы класса Cube и рассчитать p, s и v. */
public class Cube {
    public int a; // поле класса

    public int perimeter (){ // определение периметра
        return a * 12;
    }
    public  int square(){ // определение площади
        return 6 * a * a;
    }
    public int volume(){ // определение объема
        return a * a * a;
    }

// Constructor
    public Cube(int a) {
        this.a = a;
    }
//Get - or
    public int getA() {
        return a;
    }
// Set - or
    public void setA(int a) {
        this.a = a;
    }


}
