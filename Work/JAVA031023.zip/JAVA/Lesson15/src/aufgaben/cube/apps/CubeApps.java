package aufgaben.cube.apps;
import aufgaben.cube.model.Cube;

public class CubeApps {

    public static void main(String[]args){
        Cube kub1 = new Cube(10); // создал первый Куб
        Cube kub2 = new Cube(20); // создал второй Куб
        Cube kub3 = new Cube(30); // создал третий Куб


        System.out.println("Периметер = " + kub1.perimeter());
        System.out.println("Площадь = " + kub1.square());
        System.out.println("Объем = " + kub1.volume());
        System.out.println("-------------------------------");

        //----------------------------
        System.out.println("Периметер = " + kub2.perimeter());
        System.out.println("Площадь = " + kub2.square());
        System.out.println("Объем = " + kub2.volume());
        System.out.println("-------------------------------");

        //-----------------------------
        System.out.println("Периметер = " + kub3.perimeter());
        System.out.println("Площадь = " + kub3.square());
        System.out.println("Объем = " + kub3.volume());
    }

}
