package aufgaben.quadraticEquation.model;
public class QuadraticEquation {
 /*   Задача 3. ()* Создать класс, описывающий квадратные уравнения с коэффициетами a, b и c.
    Реализовать в нем методы: вычисления дискриминанта b*b - 4 * a *c определения количества корней в
    зависимости от значения дискриминанта (d>0 - два корня, d=0 - один корень, d<0 - корней нет)
    Вызвать методы из приложения QuadraticEquationAppl*/

    public int a, b, c;
    public void display(){
        double perD = 0;
        perD = Math.pow(b,2) -  (4*a* c);
        System.out.println("Discriminant = " + perD);
        if (perD < 0) {
            System.out.println("no solutions - [ D < 0 ]");
        } else if (perD == 0) {
            double perX = (-b / (2 * a));
            System.out.println("Value [ x ] = " + perX);
            int perSol = (int) ((a * Math.pow(perX,2)) + (b * perX) + c);
            System.out.println("solution verification " + perSol);
        } else {
            double perX1 = (-b + Math.sqrt(perD)) / (2 * a);
            double perX2 = (-b - Math.sqrt(perD)) / (2 * a);
            System.out.println("Value [ x1 ] =" + perX1);
            System.out.println("Value [ x2 ] =" + perX2);
        }
        System.out.println("====================================");
    }

    // Generate
    public int getA() {return a;}
    public void setA(int a) {this.a = a;}
    public int getB() {return b;}
    public void setB(int b) {this.b = b;}
    public int getC() {return c;}
    public void setC(int c) {this.c = c;}
    public QuadraticEquation(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
