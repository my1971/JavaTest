package aufgaben.employee.model;
public class Employee {
 /*   Задача 2. Создать класс Работник (Employee) c полями:
    - уникальный номер
    - имя
    - фамилия
    - пол
    - зарплата
    - уровень налогообложения
 Создать приложение FirmaAppl в котором принять на работу несколько сотрудников.*/

    public int isbn; // - уникальный номер - ISBN
    public String name; // - имя
    public String surname ; // - фамилия
    public  String gender; // - пол
    public  double salary; // - зарплата
    public  int nalog; // - уровень налогообложения
    //methods Class Employee
    public void display(){
        System.out.print(" ISBN - " + isbn + " /");
        System.out.print(" Name - " + name+ " /");
        System.out.print(" Surname - " + surname+ " /");
        System.out.print(" Gender - " + gender+ " /");
        System.out.print(" Salary - " + salary+ " /");
        System.out.print(" Level of taxation - " + nalog+ " /");
        System.out.println(" ");
    }
    public static int[] uniqueNumber(int x) { // Уникальный номер(генерирует случайное число, и заполняет массив)
        int[] arr = new int[x];
        int a = 10000, b = 20000, c = 0;
        for (int i = 0; i < arr.length; i++) {
            if (i==0){c = (int)(Math.random() * (b - a + 1) + a);
            }else{c = c + 1;}
            arr[i] = c;
        }
        return arr;
    }
    // Generate

    public int getIsbn() {return isbn;}
    public void setIsbn(int isbn) {this.isbn = isbn;}
    public String getName() {return name;}
    public void setName(String name) {this.name = name;}
    public String getSurname() {return surname;}
    public void setSurname(String surname) {this.surname = surname;}
    public String getGender() {return gender;}
    public void setGender(String gender) {this.gender = gender;}
    public double getSalary() {return salary;}
    public void setSalary(double salary) {this.salary = salary; }
    public int getNalog() {return nalog;}
    public void setNalog(int nalog) {this.nalog = nalog;}
    public Employee(int isbn, String name, String surname, String gender, double salary, int nalog) {
        this.isbn = isbn;
        this.name = name;
        this.surname = surname;
        this.gender = gender;
        this.salary = salary;
        this.nalog = nalog;
    }
}
