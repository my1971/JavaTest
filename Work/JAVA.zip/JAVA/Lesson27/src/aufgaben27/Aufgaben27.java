/*Task 1. Read the article, repeat the examples from it:
            https://www.geeksforgeeks.org/interfaces-in-java/
Задча 1. Прочитать статью, повторить примеры из нее:
            https://www.geeksforgeeks.org/interfaces-in-java/


Task 2. Finding duplicates in an array. Think of an array of 100 elements and fill
        it with random values between 1 and 10. Count how many and which elements
        occurred more than once in this array.
Задача 2. Поиск дубликатов в массиве. Задумайте массив из 100 элементов и заполните
        его случайными значениями целых чисел в интервале от 1 до 10. Подсчитайте сколько
        и каких элементов встретилось более одного раза в этом массиве.

*/