package aufgaben27.random;

import aufgaben27.random.model.Random;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

// Использование двумерного массива.
class RandomTest {
    Random random;

    @BeforeEach
    void setUp() {
        random = new Random();
    }

    @Test
    void fillArray() {
        int[] arr = {10, 10, 5, 1, 7, 1, 10, 3, 3, 2, 10, 1};
        assertArrayEquals(arr, random.fillArray());
    }

    @Test
    void findInArray2() {
        int[][] arr2 = new int[10][2];
        arr2[0][0] = 10;
        arr2[0][1] = 4;
        arr2[1][0] = 1;
        arr2[1][1] = 3;
        arr2[2][0] = 3;
        arr2[2][1] = 2;
        assertArrayEquals(arr2, random.findInArray2(random.fillArray()));
    }
}
