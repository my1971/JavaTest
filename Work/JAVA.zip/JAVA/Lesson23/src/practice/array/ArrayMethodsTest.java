package practice.array;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ArrayMethodsTest {
    ArrayMethods arrayMethods;

    @BeforeEach
    void setUp() {
        arrayMethods = new ArrayMethods();

    }

    @Test
    void sumElOfArray() {
        int[] num = {10, 20, 30, 40, 50};
        assertEquals(150, arrayMethods.sumElOfArray(num));

    }

    @Test
    void sumElOfOddIndex() {
    }
}