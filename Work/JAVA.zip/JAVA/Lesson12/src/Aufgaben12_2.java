public class Aufgaben12_2 {
    public static void main(String[] args) {

        /*  Задача 2 Задан массив целых чисел: 56, 73, 15, -10, 37, -14, 25, 65, 33, 38.
            Найдите максимальный элемент массива и его индекс. */

        int[] numbers = {56, 73, 15, -10, 37, -14, 25, 65, 33, 38};
        int  max = numbers[0];
        int pointer = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] > max){
                max = numbers[i];
                pointer = i;
            }
        }
        System.out.println("Max = " + max+ "  Index  " + pointer);
    }
}
