public class Main2 {
    public static void main(String[] args) {

        /* Задача 2. Задан массив целых чисел: 75, 34, -15, -123, 57, -145, 86, 77, 48, -59.
        Найдите минимальный элемент массива и его индекс. */

        int[] numbers = {-1575, 34, -15, -123, 57, -145, 86, 77, 48, -59};
        int  min = numbers[0];
        int pointer = -1;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] < min){
                min = numbers[i];
                pointer = i;
            }
        }
        System.out.println("Min = " + min+ "  Index  " + pointer);

//        System.out.println(" ");
//        System.out.println("======================");
//        System.out.println(marks[marks.length - 1]);
      //  System.out.println(marks + "//////" + a);
    }
}