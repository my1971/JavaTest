public class Aufgaben12_4 {
    public static void main(String[] args) {

        /* Задача 4 (*) Заполнить двухмерный массив 8 х 8 элементами 0 и 1, как на шахматной достке.
         1 - черное поле, 0 - белое поле Вывести массив на печать. */
        int[][] array = new int[8][8];
        System.out.println("****************************");
        for (int i = 0; i < 8; i++) {
            System.out.print("*  ");
            for (int i1 = 0; i1 < 8; i1++) {
                if (i != 0 & i%2 > 0){
                    array[i][i1] = (i1 != 0 & i1%2 > 0) ? 1 : 0;
                }else {
                    array[i][i1] = (i1 != 0 & i1%2 > 0) ? 0 : 1;
                }
                System.out.print(array[i][i1] + "  ");
                array[0][i] = (i != 0 & i%2 > 0) ? 1 : 0;
            }
            System.out.print("*");
            System.out.println(" ");
        }
        System.out.println("****************************");
    }
}
