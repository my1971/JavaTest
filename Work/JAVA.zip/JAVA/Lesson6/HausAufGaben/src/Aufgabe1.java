import javax.swing.*;
import java.awt.*;

public class Aufgabe1 {
  // Дана строка "I'm proud to learn Java! Java is the most famous programming language!!!"
  // Повторить практикум с этой строкой.
    public static void main(String[] args) {
        String perSt = "I'm proud to learn Java! Java is the most famous programming language!!!";
        JFrame frame = new JFrame();
        JLabel label = new JLabel("Work line: [ " + perSt + " ]"); // определяется строка для вывода на экран
        label.setBounds(20,0,1400,100);
        label.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label);  // Вывод на экран
        //------ первое задание - Распечатать последний символ строки.-------------
        char perlastSymbol = perSt.charAt(perSt.length()-1);
        JLabel label1 = new JLabel("1) Last Symbol ist - ' " + perlastSymbol + " '");
        label1.setBounds(20,30,1400,100);
        label1.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label1);  // Вывод на экран
        //------ второе задание - Найти позицию подстроки “Java” в строке.------------
        int perIndex = perSt.indexOf("Java"); //  выдает номер расположения слова (index)
        JLabel label2 = new JLabel("2) 'Java' start from index = ' " + perIndex + " '");
        label2.setBounds(20,60,1400,100);
        label2.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label2);  // Вывод на экран
        //------ третье  задание - Проверить, содержит ли заданная строка подстроку “Java”.------------
        boolean perBool = perSt.contains("Java"); // находит в предложении слово (True или False)
        JLabel label3;
        if (perBool){label3 = new JLabel("3) 'Java' have in the line! (" + perBool + ")");}
        else {label3 = new JLabel("3) 'Java' have no in the line!(" + perBool + ")");}
        label3.setBounds(20,90,1400,100);
        label3.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label3);  // Вывод на экран
        //------ четвертое задание - Заменить все символы “o” на “a”.------------
        JLabel label4 = new JLabel("4) " + perSt.replace("a", "o"));
        label4.setBounds(20,120,1400,100);
        label4.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label4);  // Вывод на экран
        //------ пятое задание - Преобразуйте строку к верхнему регистру.------------
        JLabel label5 = new JLabel("5) " + perSt.toUpperCase());
        label5.setBounds(20,150,1400,100);
        label5.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label5);  // Вывод на экран
        //------ шестое задание - Преобразуйте строку к нижнему регистру.------------
        JLabel label6 = new JLabel("6) " + perSt.toLowerCase());
        label6.setBounds(20,180,1400,100);
        label6.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label6);  // Вывод на экран
        //------ седьмое  задание - Вырезать строку Java c помощью метода substring().------------
        JLabel label7 = new JLabel("7) " + perSt.substring(19, 23));
        label7.setBounds(20,210,1400,100);
        label7.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label7);  // Вывод на экран
        //------ восьмое задание - Проверить, заканчивается ли ваша строка подстрокой “!!!”.------------
        boolean perBool1 = perSt.endsWith("!!!"); // заканчивается предложение на “!!!” (True или False)
        JLabel label8;
        if (perBool1){label8 = new JLabel("8) '!!!' have in the end line! (" + perBool1 + ")");}
        else {label8 = new JLabel("8) '!!!' have no in the end line! (" + perBool1 + ")");}
        label8.setBounds(20,240,1400,100);
        label8.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label8);  // Вывод на экран
        //------ девятое задание - Проверить, начинается ли ваша строка подстрокой “I'm proud”.------------
        boolean perBool2 = perSt.startsWith("I'm proud"); // начинается  предложение на “I'm proud” (True или False)
        JLabel label9;
        if (perBool2){label9 = new JLabel("9) 'I'm proud' have in the Start line! (" + perBool2 + ")");}
        else {label9 = new JLabel("9) 'I'm proud' have no in the Start line! (" + perBool2 + ")");}
        label9.setBounds(20,270,1400,100);
        label9.setFont(new Font(null,Font.PLAIN,25));
        frame.add(label9);  // Вывод на экран

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1150,500);
        frame.setLayout(null);
        frame.setVisible(true);
    }
}

/*
       Object St;
        System.out.println("String pratice");
        String st = ("I like Java! Java is the best way to earn good salary in IT.");
        // 1
        System.out.println(st);
        int l = st.length();
        System.out.println("Lengt of string is: " + l);
        // 1
        char lastSymbol = st.charAt(st.length()-1);
        System.out.println("Last symbol is : " + lastSymbol);
        /2
        String st1 = "I like Java!";
        int index = st1.indexOf("Java"); //  выдает номер расположения слова (index)
        System.out.println("Java start from index = " + index);
        int index2 = st1.indexOf("like");
        System.out.println("Like start from index = "+ index2);
        /3
        boolean yesOrNo = st.contains("Java!!!"); // находит в предложении слово (True или False)
        System.out.println(yesOrNo);
        // 4  Меняем "A" на "O"
        System.out.println(st.replace("a", "o"));
        //5
        String stNew1 = st.toLowerCase();
        System.out.println(stNew1);
        //6
        String stNew2 = st.toUpperCase();
        System.out.println(stNew2);
        String stNew3 = st.substring(7,11);
        System.out.println(stNew3);
//---------------------
        String stNew4 = "I like Java!!!";
        yesOrNo = stNew4.endsWith("!!!!");
        System.out.println(yesOrNo);
 */