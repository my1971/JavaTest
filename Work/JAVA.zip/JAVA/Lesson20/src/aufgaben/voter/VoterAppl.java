package aufgaben.voter;

import aufgaben.voter.model.Voter;

public class VoterAppl {
    public static void main(String[] args) {
/* Task 2.  Implement the Voter class. Ensure the impossibility of registering as a voter person who is under 18 years of age.
 Задача 2.  Реализовать класс Избиратель (модель). Обеспечить невозможность регистрации в качестве избирателя лица, которому
            еще не исполнилось 18 лет в классе-апликации.*/
        Voter[] arrVoter = new Voter[10];
        arrVoter[0] = new Voter ("Gans", "Tuher","15.02.2010","Munchen", "Deutschland");
        arrVoter[1] = new Voter ("Micha", "Bar","15.07.2008","Hamm", "Deutschland");
        arrVoter[2] = new Voter ("Elena", "Lee","15.01.1980","Man", "Kareya");
        arrVoter[3] = new Voter ("Anna", "Maier","15.12.1990","Keel", "Deutschland");
        arrVoter[4] = new Voter ("Mathius", "Maier","15.11.1988","California", "USA");
        arrVoter[5] = new Voter ("Mark", "Hallem","15.08.1980","California", "USA");
        arrVoter[6] = new Voter ("Irma", "Kluger","15.03.1985","Eule", "Deutschland");
        arrVoter[7] = new Voter ("Frans", "Kluger","15.01.2005","California", "Deutschland");
        Voter.display(arrVoter);
        Voter.checkAge(arrVoter);

    }
}
