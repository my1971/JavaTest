package aufgaben.voter.model;

import java.util.Objects;
import java.time.LocalDate;

public class Voter {
    /*Task 2.     Implement the Voter class. Ensure the impossibility of registering as a voter person who is under 18 years of age.
Задача 2.   Реализовать класс Избиратель (модель). Обеспечить невозможность регистрации в качестве избирателя лица, которому
            еще не исполнилось 18 лет в классе-апликации.*/
    public String firstName;
    public String surName;
    public String dateOfBirth; // дата рождения
    public String placeOfBirth; // место рождения
    protected String citizenship; // Гражданство

    // Constructor und Special method (конструктор специальный метод)
    public  static void display(Voter[] voters){// Метод вывода на кран массива
        for (int i = 0; i < voters.length-1; i++) {
            if (!(voters[i] == null)) {System.out.println(voters[i]);}
        }
    }
    public  static void checkAge(Voter[] voters){// Метод проверки избирателей и вывода на экран
        System.out.println("List of the voter persons: ");
        for (int i = 0; i < voters.length-1; i++) {
            if (!(voters[i] == null) && checkDate(voters[i].getDateOfBirth())) {System.out.println(voters[i]);}
        }
    }
    public static boolean checkDate(String data){
        LocalDate current_date = LocalDate.now(); // import java.time.LocalDate;
        int current_Year = current_date.getYear();
        int year = Integer.parseInt(data.substring(data.length()-4));
        return ((current_Year - 18)>=year) ? (true) : (false);
    }

    public Voter(String firstName, String surName, String dateOfBirth, String placeOfBirth, String citizenship) {
        this.firstName = firstName;
        this.surName = surName;
        this.dateOfBirth = dateOfBirth;
        this.placeOfBirth = placeOfBirth;
        this.citizenship = citizenship;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(String placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    @Override
    public String toString() {
        return "Voter / " +
                "Firstname='" + firstName + '\'' +
                ", Surname='" + surName + '\'' +
                ", Date of birth='" + dateOfBirth + '\'' +
                ", Place of birth='" + placeOfBirth + '\'' +
                ", Citizenship='" + citizenship + '\'' +
                '/';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Voter voter = (Voter) o;
        return Objects.equals(firstName, voter.firstName) && Objects.equals(surName, voter.surName) && Objects.equals(dateOfBirth, voter.dateOfBirth) && Objects.equals(placeOfBirth, voter.placeOfBirth) && Objects.equals(citizenship, voter.citizenship);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, surName, dateOfBirth, placeOfBirth, citizenship);
    }
}
