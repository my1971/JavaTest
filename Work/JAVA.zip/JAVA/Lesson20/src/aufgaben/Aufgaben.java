package aufgaben;

public class Aufgaben {

}
/*Task 1. implement book search methods in the library
        -   by author
        -   book title
Задча 1. реализовать методы поиска книг в библиотеке
        -   по автору
        -   по названию книги

Task 2.     Implement the Voter class. Ensure the impossibility of registering as a voter person who is under 18 years of age.
Задача 2.   Реализовать класс Избиратель (модель). Обеспечить невозможность регистрации в качестве избирателя лица, которому
            еще не исполнилось 18 лет в классе-апликации.
Task 3. Create an array of 100 random integers between -10 and 10. Calculate how many are in this array:
        -   positive numbers;
        -   negative numbers;
        -   even numbers;
        -   zero.
Задача 3(*). Создайте массив из 100 случайных целых чисел в интервале от -10 до 10. Подсчитайте, сколько в этом массиве оказалось:
        -   положительных чисел;
        -   отрицательных чисел;
        -   четных чисел;
        -   нулей.

Task 4. Implement a computer warehouse by analogy with a book and a library (a task for the whole week).
Задача4. Реализовать компьютерный склад по аналогии с книгой и библиотекой (задание на всю неделю).
*/