package aufgaben25.bus.metod;

public class Bus {
    /*Task 2.   Create class Bus (bus) - with fields number of the route, capacity, speed on the route, length of the route.
                Implement go, stop, speedUp, speedDown methods
    Задача 2.   Создать класс Bus (автобус) - с полями номер маршрута, вместимость, скорость на маршруте, длина маршрута.
                Реализовать методы go, stop, speedUp, speedDown*/
    Integer numOfRoute; //номер маршрута
    Integer capacity; //вместимость
    Integer speedOnRoute; //скорость на маршруте
    Integer lenghtOfRoute; //длина маршрута

    public Integer go(Integer speed) {
        speedOnRoute = speed;
        return speedOnRoute;
    }
    public Integer stop() {
        speedOnRoute = 0;
        return speedOnRoute;
    }
    public Integer speedUp(Integer speed) {
        speedOnRoute = speed;
        return speedOnRoute;
    }
    public Integer speedDown(Integer speed) {
        speedOnRoute = speed;
        return speedOnRoute;
    }
    public Bus(Integer numOfRoute, Integer capacity, Integer speedOnRoute, Integer lenghtOfRoute) {
        this.numOfRoute = numOfRoute;
        this.capacity = capacity;
        this.speedOnRoute = speedOnRoute;
        this.lenghtOfRoute = lenghtOfRoute;
    }

    public Bus() {  }
    @Override
    public String toString() {
        return "Bus  [Number of route = " + numOfRoute +
                ", with capacity = " + capacity +
                ", Speed on route = " + speedOnRoute +
                ", Lenght of route = " + lenghtOfRoute + ']';
    }

    public Integer getNumOfRoute() {
        return numOfRoute;
    }

    public void setNumOfRoute(Integer numOfRoute) {
        this.numOfRoute = numOfRoute;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getSpeedOnRoute() {
        return speedOnRoute;
    }

    public void setSpeedOnRoute(Integer speedOnRoute) {
        this.speedOnRoute = speedOnRoute;
    }

    public Integer getLenghtOfRoute() {
        return lenghtOfRoute;
    }

    public void setLenghtOfRoute(Integer lenghtOfRoute) {
        this.lenghtOfRoute = lenghtOfRoute;
    }
}
