package aufgaben25.students.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StudendtsTest {
    public Studendts stud;

    @BeforeEach
    void setUp() {
        stud = new Studendts(11);
    }

    @Test
    void groups() {
        //assertEquals(("Quantity students in Group 1 = " + 6 + " | Quantity students in Group 2 = " + 5), stud.groups());
        assertEquals("Quantity students in Group 1 = " + 5 + " | Quantity students in Group 2 = " + 6, stud.groups());
    }
}