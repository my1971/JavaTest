package aufgaben25;

public class Aufgaben25 {
}
/*
Task 1. Move all your projects to a folder that is tracked by Git
Задча 1. Перенести все свои проекты в папку, которая отслеживается Git

Task 2. Create class Bus (bus) - with fields number of the route, capacity, speed on the route, length of the route.
        Implement go, stop, speedUp, speedDown methods
Задача 2. Создать класс Bus (автобус) - с полями номер маршрута, вместимость, скорость на маршруте, длина маршрута.
        Реализовать методы go, stop, speedUp, speedDown

Task 3.     There is a list of students with their last names (set inside the program).
            Distribute students into 2 approximately equal groups (+/- 1 person) randomly.
            -   first write in words an algorithm of how this will be done;
            -   implement the algorithm in code;
            -   when implementing, use the method(s);
            -   create tests.


Задача 3.   Имеется список студентов с их фамилиями (задать внутри программы).
            Распределить студентов на 2 примерно равных группы (+/- 1 человек) случайным образом.
            -   сначала написать словами алгоритм того, как это будет делаться;
            -   реализовать алгоритм в коде;
            -   при реализации использовать метод(ы);
            -   создать тесты.
 */
