import java.util.Scanner;

public class Aufgabe11_3 {
    public static void main(String[] args) {
/* Задача 3 Бизнесмен взял ссуду m тысяч рублей в банке под 10% годовых.
 Через сколько лет его долг превысит s тысяч рублей, если за это время он не будет отдавать долг. */

        System.out.println("working with Bank");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input sum: ");
        double sumM = sc.nextInt();
        System.out.print("Input maximal sum: ");
        int sumS = sc.nextInt(), year = 0;
        while (sumM <= sumS){
            sumM = sumM * 1.1;
            System.out.println("deposit " + year  + " year = " + sumM + " ruble");
            year++;
        }
        System.out.println("====================================");
        System.out.printf("The amount owed will exceed for %d year = %.2f ruble" ,year, sumM);
        System.out.println(" ");
        System.out.println("====================================");
    }
}
