import java.util.Scanner;

public class Digits {
    public static void main(String[] args) {
        System.out.println("Methods Practice");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input numer: ");
        int num = scanner.nextInt();
        int digits =  numberDFDigits(num);
        System.out.println("Number of digits is ; " + digits);
        int suьDigits = sumDfDigits( num);
        System.out.println("Sum of digits: " + suьDigits);
    }
    //-----------Methods
    public static int numberDFDigits(int n) {
        int count = 1; //инициировал счетчик
        while (n/10>0){
            n = n / 10;
            count++;
        }
        return count;
    }
    public static int sumDfDigits(int n){
        int sum = 0;
        while(n *10 / 10 > 0){
           sum = sum + n % 10;
           n = n / 10;
        }
        return sum;
    }
    //-----------End of Methods
}