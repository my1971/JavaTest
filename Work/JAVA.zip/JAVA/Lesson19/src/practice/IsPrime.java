package practice;

import java.util.Scanner;

public class IsPrime {
    public static void main(String[] args) {
/*  Написать метод, определяющий, является ли число простым (primary). Проcтое число - это число,
    которое делится только на себя и 1. Примеры: 2, 7, 11, 19, 47. */
        // Что на входе     - целое положительное число
        // Что на выходе    - boolean, ответ на п оставленный вопрос
        // ключевой алгоритм -
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.println("Input integer positive number");
            int n = scanner.nextInt();
            boolean isPrime = true;
            System.out.println("n = " + n);
            for (int i = 2; i < n - 1; i++) {
                if (n % i == 0){
                    isPrime = false;
                    System.out.println(i);
                }
            }
            if (isPrime){
                System.out.println("Number " + n + " is prime");
            }else{
                System.out.println("Number " + n + " is not prime");
            }
        }

    }
}
