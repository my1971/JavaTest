/*  - encapsulation (инкапсуляция)
    - polymorphism (полиморфизм)
    - inheritance (наследование)*/
package aufgaben;
import java.util.Scanner;

public class Aufgaben19_3 {
    public static void main(String[] args) {
/* Задча 3. Создайте собственный класс и его методы из классной групповой работы.
            Создайте несколько экземпляров объектов созданного класса. Выполните действия с помощью методов класса.*/
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("Input integer positive number: ");
            int n = scanner.nextInt();
            if (n > 0){display(CheckNumber(n));} else {break;} // выбор числа меньше или равно 0 дает выход из цикла
        }
    }
    public static int[] CheckNumber(int n){
        System.out.println(" ");
        System.out.println("Number = " + n);
        int l = 0, i1 = 0;
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0){l++;}
        }
        int[] arr = new int[l];
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0){
                arr[i1] = n / i;
                i1++;
            }
        }
        return arr;
    }
    public static void display(int[] arr){
        for (int i = 0; i < arr.length ; i++) {
            System.out.println("Number " + arr[i]);
        }
    }
}
