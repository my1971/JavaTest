package aufgaben.printer;

public class PrinterRepair extends Printer {
    public int addParer;
    public String repair;
    // Constructor und Special method (конструктор специальный метод)

//    public PrinterRepair(int addParer, String repair) {
//        this.addParer = addParer;
//        this.repair = repair;
//    }

    public PrinterRepair(String file, String modelPrinter, Boolean color, int quantity, int addParer, String repair) {
        super(file, modelPrinter, color, quantity);
        this.addParer = addParer;
        this.repair = repair;
    }

    public int getAddParer() {
        return addParer;
    }

    public void setAddParer(int addParer) {
        this.addParer = addParer;
    }

    public String getRepair() {
        return repair;
    }

    public void setRepair(String repair) {
        this.repair = repair;
    }
}
