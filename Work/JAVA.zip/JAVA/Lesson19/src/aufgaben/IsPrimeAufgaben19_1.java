/*  - encapsulation (инкапсуляция)
    - polymorphism (полиморфизм)
    - inheritance (наследование)*/
package aufgaben;
import java.util.Scanner;

public class IsPrimeAufgaben19_1 {
    public static void main(String[] args) {
// Задча 1. Доделать дадачу про проверку простого числа или нет - сделать метод.
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.print("Input integer positive number: ");
            int n = scanner.nextInt();
            if (n > 0){display(CheckNumber(n),n);} else {break;} // выбор числ 0 дает выход из цикла
        }
    }
    public static boolean CheckNumber(int n){
        System.out.println(" ");
        System.out.println("n = " + n);
        for (int i = 2; i < n - 1; i++) {
            if (n % i == 0){return false;}
        }
        return true;
    }
    public static void display(boolean l,int n){
        System.out.println("Number " + n + " is " + ((l) ? ("") : (" not ")) + "prime");
    }
}
