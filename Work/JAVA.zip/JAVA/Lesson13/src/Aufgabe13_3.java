import java.util.Scanner;

public class Aufgabe13_3 {
    public static void main(String[] args) {
// Задача 3. Пользователь вводит строку. Распечатайте эту строку в обратном порядке.
        Scanner scanner = new Scanner(System.in);
        System.out.print(" Input text: ");
        String n = scanner.nextLine();
        String[] num = new String[n.length()];
        for (int i = 0; i < num.length; i++) {
            num[i] = n.substring(i, i+1);
        }
        printArray(num);
   }
    public static void printArray(String[] arr){
        for (int i = arr.length-1; i >= 0; i--) {
            System.out.print(arr[i] + " ");
        }
    }
}
/*
public static String reverseString(String str) {
  String result = "";
  for (int i = 0; i < str.length(); i++) {
     result = str.charAt(i) + result;
  }
  return result;
}
 */