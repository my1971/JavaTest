import java.util.Scanner;

public class Aufgabe13_3_2 {
    public static void main(String[] args){
// Задача 3. Пользователь вводит строку. Распечатайте эту строку в обратном порядке.
        Scanner scanner = new Scanner(System.in);
        System.out.print(" Input text: ");
        String str = scanner.nextLine();
        str = reverse(str);
        System.out.println("Reversed string is: " + str);
    }
    public static String reverse(String str) {
        return new StringBuilder(str).reverse().toString();
    }
}
