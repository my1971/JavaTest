package practice.nod;

public class Nod {
    public int nod (Integer a, Integer b){
//    Реализовать метод для нахождения наибольшего общего делителя двух натуральных чисел.
//    Метод должен быть покрыт тестами.
//    Использовать Debugger для отладки решения.
        // НОД (9, 24) = 6, НОД (48, 24) = 24, НОД (50, 40) = 10
        Integer nod = 1;
        //Integer a, b;
        // шаг 1 - найти меньшее из данных двух чисел
        Integer min = a;
        if (a < b){
            min = a;
        } else{
            min = b;
        }
        // шаг 2 надо определить НОД
        Integer res = 0;
        while (nod <= min){
            if (a % nod == 0 && b % nod == 0){
                res = nod;
            }
            nod++;
        }
        return res;
    }

}
