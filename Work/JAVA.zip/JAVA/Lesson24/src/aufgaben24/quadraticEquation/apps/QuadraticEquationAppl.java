package aufgaben24.quadraticEquation.apps;
import aufgaben24.quadraticEquation.model.QuadraticEquation;

import static java.lang.System.in;

public class QuadraticEquationAppl {


    public static void main(String[]args){

        QuadraticEquation calc;
        QuadraticEquation calc1 = new QuadraticEquation(20, 4, 2); // нет решений
        QuadraticEquation calc2 = new QuadraticEquation(2, 4, 2); // имеется одно решение
        QuadraticEquation calc3 = new QuadraticEquation(2, 9, 5);  // имеется 2 корня
        Double d1 = calc1.discriminant();

        if (d1<0){
            calc1.display();
        } else if (d1 == 0) {
            calc1.display(calc1.calculation(d1));
        }else {
            calc1.display(calc1.calculation(d1),calc1.calcX2(d1));
        }
        Double d2 = calc2.discriminant();
        if (d2<0){
            calc1.display();
        } else if (d2 == 0) {
            calc1.display(calc1.calculation(d2));
        }else {
            calc1.display(calc1.calculation(d2),calc1.calcX2(d2));
        }
        Double d3 = calc3.discriminant();
        if (d3<0){
            calc1.display();
        } else if (d3 == 0) {
            calc1.display(calc1.calculation(d3));
        }else {
            calc1.display(calc1.calculation(d3),calc1.calcX2(d3));
        }

    }
}
