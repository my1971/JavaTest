package aufgaben24.quadraticEquation.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class QuadraticEquationTest {
    QuadraticEquation calc;

    @BeforeEach
    void setUp() {
        calc = new QuadraticEquation(2, 10, 3);
    }

    @Test
    void discriminant() {
        assertEquals(76, calc.discriminant());
    }

    @Test
    void calculation() {
        assertEquals(-0.320550528229663, calc.calculation(calc.discriminant()));
        if (calc.discriminant() > 0) {
            assertEquals(-4.6794494717703365, calc.calcX2(calc.discriminant()));
        }
    }
}