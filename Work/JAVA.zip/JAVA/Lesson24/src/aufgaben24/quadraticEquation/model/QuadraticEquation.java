package aufgaben24.quadraticEquation.model;

public class QuadraticEquation {
 /*  **Задача 2.**
Оформить решение квадратного уравнения как класс с необходимыми методами, в решении использовать
переменные типа классов-оберток, сделать необходимые тесты.*/

    public Integer a, b, c, d;

    public void display() {
        System.out.println("no solutions - [ D < 0 ]");
    }
    public void display(Double perX) {
        System.out.println("Value [ x ] = " + perX);
    }
    public void display(Double perX1, Double perX2) {
        System.out.println("Value [ x1 ] =" + perX1);
        System.out.println("Value [ x2 ] =" + perX2);
    }
    public Double discriminant() { return (Math.pow(b, 2) - (4 * a * c));}
    public Double calculation(Double perD) {
        if (perD < 0) {
            return null;
        } else if (perD == 0.0) {
            return (double) (-b / (2 * a));
        } else {
            return ((-b + Math.sqrt(perD)) / (2 * a));
        }
    }
    public Double calcX2(Double perD) {return ((-b - Math.sqrt(perD)) / (2 * a));}
    // Generate
    public QuadraticEquation(Integer a, Integer b, Integer c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    public QuadraticEquation() {}

    public Integer getA() {
        return a;
    }

    public void setA(Integer a) {
        this.a = a;
    }

    public Integer getB() {
        return b;
    }

    public void setB(Integer b) {
        this.b = b;
    }

    public Integer getC() {
        return c;
    }

    public void setC(Integer c) {
        this.c = c;
    }

    public Integer getD() {
        return d;
    }

    public void setD(Integer d) {
        this.d = d;
    }
}
