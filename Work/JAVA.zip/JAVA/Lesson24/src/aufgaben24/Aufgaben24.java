package aufgaben24;

public class Aufgaben24 {

}
/*
**Задча 1.**
Прочитать статью, повторить примеры в ней.
https://www.w3schools.com/java/java_wrapper_classes.asp
**Задача 2.**
Оформить решение квадратного уравнения как класс с необходимыми методами, в решении использовать
переменные типа классов-оберток, сделать необходимые тесты.
**Задача 3.(*)**
Напишите приложение для вывода минимальных/максимальных значений заданных примитивных типов.
Типы как объекты String должны браться из аргументов основной функции.
Если в аргументах нет какого-либо типа, приложение должно вывести максимальное/минимальное
значения 7 типов (byte, int, short, long, char, float, double).
Если аргументы содержат неправильный тип, приложение должно вывести сообщение:
<argument> Неверный тип.
w3schools.comw3schools.com
Java Wrapper Classes
W3Schools offers free online tutorials, references and exercises in all the major languages of the web. Covering popular subjects like HTML, CSS, JavaScript, Python, SQL, Java, and many, many more. (6 kB)

 */
