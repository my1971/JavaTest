package aufgaben24;
public class aufgaben24_3 {
/* **Задача 3.(*)**
    Напишите приложение для вывода минимальных/максимальных значений заданных примитивных типов.
    Типы как объекты String должны браться из аргументов основной функции.
    Если в аргументах нет какого-либо типа, приложение должно вывести максимальное/минимальное
    значения 7 типов (byte, int, short, long, char, float, double).
    Если аргументы содержат неправильный тип, приложение должно вывести сообщение:
    <argument> Неверный тип.*/
    public static void main(String[] args){
        String argument;
        for (int i = 0; i <args.length ; i++) {
            argument = args[i];
            switch (argument){
                case ("byte"):
                    System.out.println("byte MAX_VALUE: " + Byte.MAX_VALUE);
                    System.out.println("byte MIN_VALUE: " + Byte.MIN_VALUE);
                    break;
                case ("int"):
                    System.out.println("int MAX_VALUE: " + Integer.MAX_VALUE);
                    System.out.println("int MIN_VALUE: " + Integer.MIN_VALUE);
                    break;
                case ("short"):
                    System.out.println("short MAX_VALUE: " + Short.MAX_VALUE);
                    System.out.println("short MIN_VALUE: " + Short.MIN_VALUE);
                    break;
                case ("long"):
                    System.out.println("long MAX_VALUE: " + Long.MAX_VALUE);
                    System.out.println("long MIN_VALUE: " + Long.MIN_VALUE);
                    break;
                case ("char"):
                    System.out.println("char MAX_VALUE: " + Character.MAX_VALUE);
                    System.out.println("char MIN_VALUE: " + Character.MIN_VALUE);
                    break;
                case ("float"):
                    System.out.println("float MAX_VALUE: " + Float.MAX_VALUE);
                    System.out.println("float MIN_VALUE: " + Float.MIN_VALUE);
                    break;
                case ("double"):
                    System.out.println("double MAX_VALUE: " + Double.MAX_VALUE);
                    System.out.println("double MIN_VALUE: " + Double.MIN_VALUE);
                    break;
                default:
                    System.out.println(argument + " -  Неверный тип.");
                    break;
            }
        }
    }
}
