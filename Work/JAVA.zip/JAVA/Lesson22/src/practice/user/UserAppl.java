package practice.user;

import practice.user.model.User;

public class UserAppl {
    public static void main(String[] args) {
        User user1 = new User("User", "username@mail.ru","aA!12345678");
        System.out.println(user1);
    }
}
