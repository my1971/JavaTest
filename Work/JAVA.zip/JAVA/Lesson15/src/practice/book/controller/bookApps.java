package practice.book.controller;
import practice.book.model.Book;

public class bookApps {
    public static void main(String[] args) {
        Book book1 = new Book("Название", "Автор книги", 2000, 1000000000 );
        Book book2 = new Book("Название2", "Автор книги2", 2000, 1000000002 );
        Book book3 = new Book("Название3", "Автор книги3", 2000, 1000000003 );
        book1.display();
        book2.display();
        book3.display();
        
    }
}
