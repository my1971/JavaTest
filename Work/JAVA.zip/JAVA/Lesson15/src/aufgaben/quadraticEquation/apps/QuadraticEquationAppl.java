package aufgaben.quadraticEquation.apps;
import aufgaben.quadraticEquation.model.QuadraticEquation;

public class QuadraticEquationAppl {

    public static void main(String[]args){
        QuadraticEquation calc1 = new QuadraticEquation(20, 4, 2); // нет решений
        QuadraticEquation calc2 = new QuadraticEquation(2, 4, 2); // имеется одно решение
        QuadraticEquation calc3 = new QuadraticEquation(2, 9, 5);  // имеется 2 корня

        calc1.display();
        calc2.display();
        calc3.display();
    }
}
