import aufgaben.employee.model.Employee;

public class FirmaAppl {

    public static void main(String[]args){
        int per = 4;
        int uniqueN[] = Employee.uniqueNumber(per);
        Employee[] array = new Employee[per];
        array[0] = new Employee(uniqueN[0],"Meik","Tue", "male", 3100.00,1);
        array[1] = new Employee(uniqueN[1],"Elena","Maller", "female", 3150.00,4);
        array[2] = new Employee(uniqueN[2],"Alik","Schramm", "male", 3000.00,3);
        array[3] = new Employee(uniqueN[3],"Mali","Krug", "female", 3300.00,5);
        for (int i = 0; i < per; i++) {array[i].display();}
    }

}
