/*********************************************************************************************************************
 double a = Math.random(); - генерирует случайное число в интервале от [0, 1) - скобки из математики [ => 0 - может быть, ) => 1 - не может быть
 double x = (Math.random() * (b-a) ) + a - генерирует случайное число в интервале от [a, b) (a<b) a - может быть, b - не может быть
 int n = (int)(Math.random() * (b - a + 1) + a) - генерирует случайное целое число в интервале [a, b] a - может быть, b - может быть
 **********************************************************************************************************************/

public class Aufgabe14_1 {
    public static void main(String[] args) {
/*   Задача 1. изменить код задач про:
    -   сумма нечетных чисел в массиве
    -   умножать числа с четными индексами в массиве так, чтобы использовались операторы break или continue.*/

        int num[] = fillArray(10); // заполнение массива 10 Indexes (генерирует случайное число)
        System.out.println("*******************************************************************************");
        System.out.println(" / Sum of odd numbers in Array = " + sumOddInArray(num));
        System.out.println("*******************************************************************************");
        System.out.println(" / Sum Array even index = " +  sumInArray(num));
        System.out.println("*******************************************************************************");
    }
    public static int sumOddInArray (int[] num){
        int perSum = 0;
        for (int i = 0; i < num.length; i++) {
            if (num[i] % 2 == 0){ // проверка числа
                continue;
            }else {
                perSum = perSum + num[i];
                System.out.print(i + ") " + num[i] + "; " );
            }
        }
        return perSum;
    }
    public static int sumInArray (int[] num){
        int perSum = 0;
        for (int i = 0; i < num.length; i++) {
            if (i % 2 != 0){ // проверка индекса на не четность
                continue;
            } else {
                perSum = perSum + num[i];
                System.out.print(i + ") " + num[i] + "; " );
            }
        }
        return perSum;
    }
    public static int[] fillArray(int x) { // заполнение массива (генерирует случайное число)
        int[] arr = new int[x];
        int a = 1, b = 100;
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * (b - a + 1) + a);
        }
        return arr;
    }
}
