package auto_aplikation;

public class AutoAppl {
}
