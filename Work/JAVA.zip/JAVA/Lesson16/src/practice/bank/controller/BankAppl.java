package practice.bank.controller;
import practice.bank.model.BankAccount;


public class BankAppl {
    public static void main(String[] args) {
        BankAccount user1 = new BankAccount(00001, "Dmitriy", "Volkbank", 101,100000);
        BankAccount user2 = new BankAccount(00002, "User2", "Bank2", 10002);
        BankAccount user3 = new BankAccount(00003,  "Bank3", 1003);

        user1.display();
        user2.display();
        user3.display();
        user1.deposit(500);
        user1.display();
        user1.withdraw(1000);
        user1.display();

    }
}
