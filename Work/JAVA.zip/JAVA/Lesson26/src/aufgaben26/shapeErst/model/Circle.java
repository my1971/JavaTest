package aufgaben26.shapeErst.model;

public class Circle extends Shape{
    Integer r; // радиус круга (S = π × r2 , P = d*π = 2*r*π.)

    @Override
    public double calcArea() {
        double s = (Math.pow(r,2) * 3.14);
        System.out.println("Площадь  круга = " + s);
        return s;
    }

    @Override
    public double calcPerimeter() {
        double p = (2* r * 3.14);
        System.out.println("Периметр круга = " + p);
        return p;
    }
    public Circle(int id, String shapeName, Integer r) {
        super(id, shapeName);
        this.r = r;
    }
}
