package aufgaben26.shapeErst.model;

public abstract class  Shape {
 /*   Task 2.
    Create an abstract class Shape with field type double and abstract methods calcArea and calcPerimeter.
    Create classes Circle, Triangle, Square that extend the Shape class and implement abstract methods.
    Write a FigureAppl class with a main method.
    In the method, create an array of shapes.
    Add two circles to the array, one triangle and one square.
    Calculate the total area and total perimeter
    of all shapes from an array of shapes.
    Задача 2.
    Создайте абстрактный класс Shape с типом поля double и абстрактными методами calcArea и calcPerimeter.
    Создать классы Circle, Triangle, Square, расширяющие класс Shape и реализующие абстрактные методы.
    Напишите класс FigureAppl с методом main. В методе создайте массив фигур.
    Добавьте в массив два круга, один треугольник и один квадрат.
    Рассчитайте общую площадь и общий периметр всех фигур из массива фигур.*/
    protected final int id;
    protected String shapeName;

    public Shape(int id, String shapeName) {
        this.id = id;
        this.shapeName = shapeName;
    }

    public abstract double calcArea();
    public abstract double calcPerimeter();

    public int getId() {
        return id;
    }

    public String getShapeName() {
        return shapeName;
    }

    public void setShapeName(String shapeName) {
        this.shapeName = shapeName;
    }
}
