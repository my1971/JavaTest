package aufgaben26;

public class Aufgaben26 {
}
/*
Task 1. Read the article, repeat the example from it: https://www.w3schools.com/java/java_abstract.asp#:~:text=Abstract%20Classes%20and%20Methods&text=Abstract%20class%3A%20is%20a%20restricted,the%20subclass%20(inherited%20from ).
Задча 1. Прочитать статью, повторить пример из нее: https://www.w3schools.com/java/java_abstract.asp#:~:text=Abstract%20Classes%20and%20Methods&text=Abstract%20class%3A%20is%20a%20restricted,the%20subclass%20(inherited%20from).

Task 2.
        Create an abstract class Shape with field type double and abstract methods calcArea and calcPerimeter.
        Create classes Circle, Triangle, Square that extend the Shape class and implement abstract methods.
        Write a FigureAppl class with a main method. In the method, create an array of shapes.
        Add two circles to the array, one triangle and one square. Calculate the total area and total perimeter
        of all shapes from an array of shapes.


Задача 2.
        Создайте абстрактный класс Shape с типом поля double и абстрактными методами calcArea и calcPerimeter.
        Создать классы Circle, Triangle, Square, расширяющие класс Shape и реализующие абстрактные методы.
        Напишите класс FigureAppl с методом main. В методе создайте массив фигур. Добавьте в массив два круга,
        один треугольник и один квадрат. Рассчитайте общую площадь и общий периметр всех фигур из массива фигур.

Task 3.(*) Calculate the total area of the circles from task 2.
Задача 3.(*) Рассчитайте общую площадь кругов из задачи 2.
 */