package aufgaben26.shape;

import aufgaben26.shape.model.Circle;
import aufgaben26.shape.model.Shape;
import aufgaben26.shape.model.Square;
import aufgaben26.shape.model.Triangle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ShapeTest {
    Shape[] arrShape = new Shape[4]; //Массив состоящий из объектов, каждый обект - это фигура

    @BeforeEach
    void setUp() {
        arrShape[0] = new Circle(1, "Shape", 2.0);
        arrShape[1] = new Circle(2, "Shape", 3.0);
        arrShape[2] = new Triangle(3, "Triangle", 3.0);
        arrShape[3] = new Square(4, "Square", 4.0);
    }

    @Test
    void calcArea() {
        assertEquals(12.56, arrShape[0].calcArea());
        assertEquals(28.26, arrShape[1].calcArea());
        assertEquals(3.8971143170299736, arrShape[2].calcArea());
        assertEquals(16.0, arrShape[3].calcArea());
    }

    @Test
    void calcPerimeter() {
        assertEquals(12.56, arrShape[0].calcPerimeter());
        assertEquals(18.84, arrShape[1].calcPerimeter());
        assertEquals(1.5, arrShape[2].calcPerimeter());
        assertEquals(16.0, arrShape[3].calcPerimeter());
    }

    @Test
    void totelArea() {
        assertEquals(60.717114317029974, Shape.totelArea(arrShape));
    }

    @Test
    void totelPerimetery() {
        assertEquals(48.9, Shape.totelPerimetery(arrShape));
    }

    @Test
    void totelCircle() {
        assertEquals(40.82, Shape.totelCircle(arrShape));
    }
}