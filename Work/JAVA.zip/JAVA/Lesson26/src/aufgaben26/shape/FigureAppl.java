package aufgaben26.shape;

import aufgaben26.shape.model.Circle;
import aufgaben26.shape.model.Shape;
import aufgaben26.shape.model.Square;
import aufgaben26.shape.model.Triangle;

public class FigureAppl {
    public static void main(String[] args) {
        Shape[] arrShape = new Shape[4]; //Массив состоящий из объектов, каждый обект - это фигура
        arrShape[0] = new Circle(1,"Shape",2.0);
        arrShape[1] = new Circle(2,"Shape",3.0);
        arrShape[2] = new Triangle(3, "Triangle",3.0);
        arrShape[3] = new Square(4,"Square",4.0);


        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь = " + Shape.totelArea(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общий периметр = " + Shape.totelPerimetery(arrShape));
        System.out.println("------------------------------------------------------");
        System.out.println("Общая площадь круга = " + Shape.totelCircle(arrShape));
        System.out.println("------------------------------------------------------");
    }
}

//        Add two circles круг  (S = π × r2 , P = d*π = 2*r*π.)
//        one triangle треугольник (P = (a+b+c)/2; S = Math.sqrt(p*(p-a)*(p-b)*p-c))
//        one square. квадрат S = a*a; P = 4a.

 /* Напишите класс FigureAppl с методом main. В методе создайте массив фигур. Добавьте в массив два круга,
    один треугольник и один квадрат. Рассчитайте общую площадь и общий периметр всех фигур из массива фигур.*/



//  Employee[] firma = new Employee[7]; //Массив состоящий из объектов, каждый обект - это сотрудник
//  firma[0] = new Manager(100,"Jhon", "Smith",174, 5000, 5);
//  firma[1] = new SalesManager(101,"Bread", "Pit",174, 300000, 0.1);
//  firma[2] = new SalesManager(102,"Julia", "Roberts",174, 300000, 0.1);
//  firma[3] = new Worker(103,"Robert", "Douny Jr",80, 20);