package practice;

public class SalesManager extends Employee{
    private double salesValue;
    private double persent;

    public SalesManager(int id, String firstNAme, String lastName, double haurs, double salesValue, double persent) {
        super(id, firstNAme, lastName, haurs);
        this.salesValue = salesValue;
        this.persent = persent;
    }

    public double getSalesValue() {
        return salesValue;
    }

    public void setSalesValue(double salesValue) {
        this.salesValue = salesValue;
    }

    public double getPersent() {
        return persent;
    }

    public void setPersent(double persent) {
        this.persent = persent;
    }

    @Override
    public double calcSalary() {
        double salary = salesValue * persent;
        return salary;
    }
}
