import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Aufgabe4Win {
    public static void main(String[] args) throws Exception{
// Задача 4 (*) Написать программу, которая принимает с клавиатуры номер месяца и год и выводит
// на экран название месяца и количество дней в нем. (повторение условного оператора)

        JFrame frameVV = new JFrame();
        frameVV.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frameVV.setSize(1150,500);
        frameVV.setLayout(null);
        frameVV.setVisible(true);
        JOptionPane.showMessageDialog(null, "Wrong month number, input again...");
        metodLine("Displays the name of the month and the number of days in it." ,0, frameVV);
        JOptionPane.showMessageDialog(null, "Wrong month number, input again...");
        metodLine("In inputted year days" , 60, frameVV);
        boolean bool = true;
        String monthName = "";
        int month = 0;
        while (bool){
            monthName = JOptionPane.showInputDialog(null,"Input month number:");
            if (monthName == null){return;}
            month = Integer.parseInt((monthName.trim()));
            if (month >0 & month < 13){
                switch (month){
                    case 1 :
                        monthName = "January";
                        break;
                    case 2 :
                        monthName = "February";
                        break;
                    case 3 :
                        monthName = "March";
                        break;
                    case 4 :
                        monthName = "April";
                        break;
                    case 5 :
                        monthName = "May";
                        break;
                    case 6:
                        monthName = "June";
                        break;
                    case 7 :
                        monthName = "July";
                        break;
                    case 8 :
                        monthName = "August";
                        break;
                    case 9 :
                        monthName = "September";
                        break;
                    case 10 :
                        monthName = "October";
                        break;
                    case 11 :
                        monthName = "November";
                        break;
                    case 12 :
                        monthName = "December";
                        break;
                    default:
                        System.out.println("Wrong input!");
                        break;
                }
                JOptionPane.showMessageDialog(null, "You choosed: " + monthName );
 //               metodLine("You inputted the month of " + monthName, 30, frame);
                metodLine("You inputted the month of ", 30, frameVV);
                bool = false;
            }else {
                JOptionPane.showMessageDialog(null, "Wrong month number, input again...");
            }
        }
        String yearStr = JOptionPane.showInputDialog(null,"Input year:");
        int year = Integer.parseInt(yearStr);
        int yearQuantity = (year % 4 == 0) ? 366 : 365;
 //       metodLine("In inputted year " + yearQuantity + " days" , 60, frame);
        metodLine("In inputted year days" , 60, frameVV);
    }
    public static int metodLine (String perLine, int perL, JFrame frameVV){
        JLabel label = new JLabel(perLine); // определяется строка для вывода на экран
        label.setBounds(20,perL,1400,100);
        label.setFont(new Font(null,Font.PLAIN,25));
        frameVV.add(label);  // Вывод на экран
        JOptionPane.showMessageDialog(null, "Ok..");
        return 0;
    }

}