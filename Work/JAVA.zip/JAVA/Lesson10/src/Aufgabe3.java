import java.util.Scanner;

// код с проверкой на ошибочный ввод числа (текст, ноль недопустимы)
public class Aufgabe3 {
    public static void main(String[] args) throws Exception  {
//Написать метод, определяющий максимум из трех натуральных чисел. Числа вводит пользователь с клавиатуры.
// Метод должен быть защищен от ввода отрицательных чисел. */
        System.out.println("triangle");
        int number1 = metodNumberCheck("Input the first  number: ");
        int number2 = metodNumberCheck("Input the second number: ");
        int number3 = metodNumberCheck("Input the third  number: ");
        int maxNumber = Math.max(number1, number2);
        maxNumber = Math.max(maxNumber, number3);
        System.out.println(maxNumber);
//        int[] age = {2, 6, 16, 54};
//        System.out.println(NumberUtils.max(age));

    }
    public static int metodNumberCheck(String perLine) throws Exception{
        boolean perBool = true;
        Scanner sc = new Scanner(System.in);
        int perNum = 0;
        String perStr = "";
        while (perBool == true){
            System.out.print(perLine);
            try {
                perStr = sc.nextLine();
                perNum = Integer.parseInt(perStr.trim());
                if (perNum > 0){
                    System.out.println("-------------------------------------------");
                    return perNum;
                } else {
                    System.out.println("The number cannot be: [" + perStr + "] is not correct");
                }
            } catch (NumberFormatException nfe){
                System.out.println("The number: [" + perStr + "] is not correct");
            }
        }
        return 0;
    }
}

