package practice.library;

import practice.library.model.Book;
import practice.library.model.Library;

public class LibraryApplArc {
    public static void main(String[] args) {

        Library library = new Library(1000);
        library.addBook(new Book("War and Peace", "George Orwell", 1990,2000000000000L));
        library.addBook(new Book("Anna Karenina", "Lev Tolstoi", 1995,2000000000001L));
        library.addBook(new Book("1984", "George Orwell", 1985,2000000000002L));
        library.addBook(new Book("Anna Karenina4", "Lev Tolstoi12", 1985,2000000000003L));
        library.addBook(new Book("1984", "George Orwell", 1985,2000000000004L));
        library.addBook(new Book("Anna Karenina6", "Lev Tolstoi", 1985,2000000000005L));

        System.out.println(library.getSize());

        Book bookFinded =  library.findBook(2000000000001L);
        System.out.println(bookFinded);

        System.out.println(library.findBook(2000000000001L));

        System.out.println(library.findBookTitle("War and Peace"));
        System.out.println();

        Book[] books; // создаем массив типа Book

        books = new Book[6];
        // создаем конкретные объекты класса Book
        books[0] = new Book("War and Peace", "Lev Tolstoi", 1990,2000000000000L);
        books[1] = new Book("Anna Karenina", "Lev Tolstoi", 1995,2000000000001L);
        books[2] = new Book("451", "Ray Bredberry", 1965,2000000000002L);
        books[3] = new Book("1984", "Lev Tolstoi12", 1985,2000000000003L);
        books[4] = new Book("1984", "George Orwell", 1985,2000000000003L);
        books[5] = new Book("1984", "Lev Tolstoi", 1985,2000000000003L);

        // Поиск книг автора Lev Tolstoi

        System.out.println("Find books of Lev Tolstoi");
        //System.out.println(library.findBookAuthor("Lev Tolstoi", books));
        Book[] booksF; // создаем массив типа Book
        booksF = library.findBookAuthor("Lev Tolstoi", books);
        for (int i = 0; i < booksF.length; i++) {
            System.out.println(booksF[i]);
        }
        Book[] booksF1; // создаем массив типа Book
        booksF1 = library.findBookAuthor1("Lev Tolstoi", books);
        for (int i = 0; i < booksF1.length; i++) {
            System.out.println(booksF1[i]);
        }
        // удаление книги из библиотеки
        System.out.println("Removed book:");
        System.out.println(library.removeBook(2000000000000L, books));

        System.out.println("Library size: "  + library.getSize());
        // печать массива книг
        for (int i = 0; i < library.getSize(); i++) {
            System.out.println(books[i]);
        }
    }
}