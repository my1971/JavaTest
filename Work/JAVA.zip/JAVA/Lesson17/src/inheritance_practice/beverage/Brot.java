package inheritance_practice.beverage;

public class Brot extends Beverage{
    String type;
    public Brot(String title, String packing, int quantity) {
        super(title, packing, quantity);
    }

    // Метод для закупки
    // мы переопределили родительский метод
    public void toBuy(String title, String packing, int quantity,String type){
        super.tobay(title,packing,quantity);
        this.type = type;
    }

    // что в кладовке
    public void displayStock(){
        super.displayStock();
        System.out.println("This is " + type + " brot.");

    }

    public Brot(String title, String packing, int quantity, String type) {
        super(title, packing, quantity);
        this.type = type;
    }

    public Brot() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Brot(String type) {
        this.type = type;
    }
}
