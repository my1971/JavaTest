package aufgaben.dictionary;

public class Dictionary extends Book{
    public String translation;

    // Constructor und Special method (конструктор специальный метод)
    public void display(String word, String translation){
        System.out.println("Слово : " + word + " - translated : " + translation);
    }
    public Dictionary(String word) {
        super(word);
    }
    // Constructor und Special method (конструктор специальный метод)
    public Dictionary(String word, String translation) {
        super(word);
        this.translation = translation;
    }

    public Dictionary() { }

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }
}
