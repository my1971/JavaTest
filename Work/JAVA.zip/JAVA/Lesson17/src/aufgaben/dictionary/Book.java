package aufgaben.dictionary;

public class Book {
    /* Task 2.  Create a Dictionary class that extends the Book class. Suggest a set of fields for it and override
            the display method. In the BookAppl class, in the main method, create some dictionaries and print
            information about them to the console.
Задача 2.   Создайте класс Dictionary, который расширяет класс Book. Предложите для него набор полей и
            переопределите метод display. В классе BookAppl в методе main создайте несколько словарей и
            выведите информацию о них в консоль.*/
    public String Word; //Слово

    // Constructor und Special method (конструктор специальный метод)

    public Book(String word) {
        Word = word;
    }
    public Book() { }
    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }
}
