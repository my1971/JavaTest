package aufgaben;

public class aufgaben {
}
/*  Task 1. Create a class Pet (pets) with fields:
            type (cat, dog, ...)
            weight
            living conditions (at home, on the street)
            Create child classes Cat and Dog with additional fields: name, breed, age. Create an eat, sleep
            method for both classes and a run method (to walk) for the Dog class. Create a voice method that
            emits "Meow!" for the Cat class and and "Wow-wow!" for the Dog class. Create a HouseAppl that has
            a main method. Settle in the house 2 dogs and 3 cats. Simulate life in this house during the day.
    Задача 1. Создайте класс Pet (домашние животные) с полями:
            тип (кошка, собака, ...)
            вес
            условия проживания (дома, на улице)
            Создайте дочерние классы Cat и Dog c дополнительными полями: имя, порода, возраст. Создайте метод eat,
            sleep для обоих классов и метод run (гулять) для класса Dog. Создайте метод voice, который выдает "Мяу!"
            для класса Cat и и "Гав-гав!" для класса Dog. Создайте HouseAppl, в котором есть метод main.
             Поселите в доме 2 собаки и 3 кошки. Смоделируйте жизнь в этом доме в течение дня.*/

/* Task 2.  Create a Dictionary class that extends the Book class. Suggest a set of fields for it and override
            the display method. In the BookAppl class, in the main method, create some dictionaries and print
            information about them to the console.
Задача 2.   Создайте класс Dictionary, который расширяет класс Book. Предложите для него набор полей и
            переопределите метод display. В классе BookAppl в методе main создайте несколько словарей и
            выведите информацию о них в консоль.*/

 /*Task 3. ()* read the article and repeat the steps described in it (code)
Задача 3. ()* прочитать статью и повторить описанные в ней действия (код)
 https://vertex-academy.com/tutorials/ru/pravila-nasledovaniya-v-java/
  */