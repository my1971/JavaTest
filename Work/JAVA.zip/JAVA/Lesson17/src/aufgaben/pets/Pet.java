package aufgaben.pets;

public class Pet {
    /*  Task 1. Create a class Pet (pets) with fields:
            type (cat, dog, ...)
            weight
            living conditions (at home, on the street)
            Create child classes Cat and Dog with additional fields: name, breed, age. Create an eat, sleep
            method for both classes and a run method (to walk) for the Dog class. Create a voice method that
            emits "Meow!" for the Cat class and and "Wow-wow!" for the Dog class. Create a HouseAppl that has
            a main method. Settle in the house 2 dogs and 3 cats. Simulate life in this house during the day.
    Задача 1. Создайте класс Pet (домашние животные) с полями:
            тип (кошка, собака, ...)
            вес
            условия проживания (дома, на улице)
            Создайте дочерние классы Cat и Dog c дополнительными полями: имя, порода, возраст. Создайте метод eat,
            sleep для обоих классов и метод run (гулять) для класса Dog. Создайте метод voice, который выдает "Мяу!"
            для класса Cat и и "Гав-гав!" для класса Dog. Создайте HouseAppl, в котором есть метод main.
             Поселите в доме 2 собаки и 3 кошки. Смоделируйте жизнь в этом доме в течение дня.*/
    String type; // (cat, dog, ...)
    int weight; 
    String livingConditions; // (at home, on the street)

    // Constructor und Special method (конструктор специальный метод)
    
//    final class Pet {
//    }
    public Pet(String type, int weight, String livingConditions) {
        this.type = type;
        this.weight = weight;
        this.livingConditions = livingConditions;
    }

    public Pet() {
    }
    //Gets und Sets

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getLivingConditions() {
        return livingConditions;
    }

    public void setLivingConditions(String livingConditions) {
        this.livingConditions = livingConditions;
    }

    public void eat() {
    }
}
