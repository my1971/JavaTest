package aufgaben.pets;

public class Cat extends Pet {
    String name; // имя
    String  breed; // порода
    int age; // возраст
    // Constructor und Special method (конструктор специальный метод)
    public Cat(String type, int weight, String livingConditions) {
        super(type, weight, livingConditions);
    }
    public void eat(){
        System.out.println("The " + type + breed + " "  + name + " eat.");
    }
    public void sleep(){
        System.out.println("The " + type + breed + " "  + name + " sleep!");
    }
    public void voice(){
        System.out.println("The " + type+ breed + " "  + name + " speak 'Meow!'");
    }
    public void display(String type, int weight, String livingConditions, String name, String breed, int age){
        super.setType(type);
        super.setWeight(weight);
        super.setLivingConditions(livingConditions);
        setName(name);
        setBreed(breed);
        setAge(age);
        System.out.println("====================================================================================");
        System.out.println("The " + type + " " + breed + " - " + name + " (weight - " + weight +
                " / age - " + age + " / lives - " + livingConditions + " /");
        eat();
        sleep();
        voice();
    }
    public Cat(String type, int weight, String livingConditions, String name, String breed, int age) {
        super(type, weight, livingConditions);
        this.name = name;
        this.breed = breed;
        this.age = age;
    }

    public Cat() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
