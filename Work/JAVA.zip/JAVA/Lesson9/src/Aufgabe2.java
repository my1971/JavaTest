import java.util.Scanner;

public class Aufgabe2 {
    public static void main(String[] args) {
// Задача 2. Вводится положительное целое число, найдите сумму его цифр.
        Scanner sc = new Scanner(System.in);
        System.out.println("Input number: ");
        int perN = sc.nextInt();
        String perSt = Integer.toString(perN);
        int perL = perSt.length();
        int i=0;
        int perSum = 0;
        String perLine = "";
        while (i <perL){
            perSum = perSum + Integer.parseInt (perSt.substring(i,i+1));
            if (i <perL-1){perLine = perLine + ((perSt.substring(i,i+1))+ " + ");}
            else {perLine = perLine + ((perSt.substring(i,i+1))+ " = ");}
            i++;
        } //end of while
        System.out.println("Summ number: " + perLine + perSum);
    }
}
