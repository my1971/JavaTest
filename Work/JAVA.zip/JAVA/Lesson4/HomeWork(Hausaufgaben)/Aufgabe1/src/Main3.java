public class Main3 {
    public static void main(String[] args) {
        System.out.println("Погода за неделю");
        int PerDay1 = 15, PerDay2 = 17, PerDay3 = 14, PerDay4 = 18,
                PerDay5 = 20, PerDay6 = 13, PerDay7 = 20;
        System.out.println("Температура в понедельник  - " + PerDay1);
        System.out.println("Температура во вторник  - " + PerDay2);
        System.out.println("Температура в среду  - " + PerDay3);
        System.out.println("Температура в четверг  - " + PerDay4);
        System.out.println("Температура в пятницу  - " + PerDay5);
        System.out.println("Температура в субботу  - " + PerDay6);
        System.out.println("Температура в воскресенье  - " + PerDay7);
        double[] PerMas = {PerDay1, PerDay2, PerDay3, PerDay4, PerDay5, PerDay6, PerDay7};

        if (PerMas.length > 0) {
            int PerSum = 0;
            for (int j = 0; j < PerMas.length; j++) {
                PerSum += PerMas[j];
            }
            double PerAverage  = 0;
            PerAverage = PerSum / PerMas.length;
            System.out.println("Средняя температура за неделю составляет : " + PerAverage);
        }
    }
}

/*
        double x1 = 16;
        double x2 = 2.25;
        double x3 = 0.25;
        double x4 = 88.675;

        System.out.printf("sqrt(%.3f) = %.3f%n", x1, Math.sqrt(x1));
        System.out.printf("sqrt(%.3f) = %.3f%n", x2, Math.sqrt(x2));
        System.out.printf("sqrt(%.3f) = %.3f%n", x3, Math.sqrt(x3));
        System.out.printf("sqrt(%.3f) = %.3f%n", x4, Math.sqrt(x4));
*/