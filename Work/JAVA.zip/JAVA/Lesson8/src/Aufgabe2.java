import java.util.Scanner;

public class Aufgabe2 {
    public static void main(String[] args) {

        System.out.println("бот, который помогает выбрасывать мусор в баки разных цветов");
/*Задача 2.
Используя оператор switch ... case написать бот, который помогает выбрасывать мусор в баки разных цветов:
    -   упаковки в желтый бак
    -   пищевые отходы в коричневый бак
    -   бумага в зеленый бак
    -   прочие отходы в черный бак*/

        Scanner sc = new Scanner(System.in);
        System.out.println("chose operation (Input number):  1 - упаковки, 2 - пищевые отходы, 3 - бумага, 4 - прочие отходы ");
        int perOperation = sc.nextInt();
        switch (perOperation){
            case 1 :
                System.out.println("упаковки в желтый бак");
                break;
            case 2 :
                System.out.println("пищевые отходы в коричневый бак");
                break;
            case 3 :
                System.out.println("бумага в зеленый бак");
                break;
            case 4 :
                System.out.println("прочие отходы в черный бак");
                break;
            default:
                System.out.println("Wrong input!");
                break;
        }
    }
}
