import java.awt.*;
import java.util.Scanner;

import static java.util.Scanner.*;

public class switchPractiks {
    public static void main(String[] args) {

        System.out.println("Superman and his choice");
/*Практикум: Задача 1. Богатырь приехал к камню с выбором трех путей - налево, направо или прямо.
 Считайте с клавиатуры выбор богатыря и сообщите ему его судьбу: left - loose your horse, right -
 loose your honor, forward - loose your head. Использовать сравнение строк st.equals(), st -
 это имя переменной типа String*/
     //   Scanner sc = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        System.out.println("left - loose your horse, right -\n" +
                " loose your honor, forward - loose your head.");
        System.out.println("What is your choice?");

        String perChoice = sc.next(); // считываем строку, которую написал пользователь
        // st.equals("Значение") - так проверяется равенство String
        if (perChoice.equals("left")){
            System.out.println("You lose your horse!");
        }else if (perChoice.equals("right")) {
            System.out.println("You lose your honar!");
        } else if (perChoice.equals("forward")){
            System.out.println("You lose your head!");
        }else {
            System.out.println("Wrong input!");
        }

    }
}