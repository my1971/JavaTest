import java.util.Scanner;

// код с проверкой на ошибочный ввод числа (текст, ноль недопустимы)
public class Aufgabe3 {
    public static void main(String[] args) throws Exception {
        /* Сделайте расчет покупки товаров со скидками. Стоимость, количество товаров и скидку на них вводит пользователь.
        Товар А стоит X руб и на него скидка D%, а товар B стоит Y руб и на него скидка С%.
        Клиент взял N товаров A и M товаров B. Программа не должна допускать ввода отрицательных чисел.
        Выведите итоговую стоимость покупки и полученной скидки.*/
        System.out.println("Buying goods with discounts");
        System.out.println("==================================================================");
        double  perX = metodNumberCheck("Input cost of first  Goods: ",true);
        double  perN = metodNumberCheck("Input quantity of first  Goods: ",true);
        double  perD = metodNumberCheck("Input discount of first  Goods: ",false);
        double  perY = metodNumberCheck("Input cost of second  Goods: ",true);
        double  perM = metodNumberCheck("Input quantity of second  Goods: ",true);
        double  perC = metodNumberCheck("Input discount of second  Goods: ",false);
        System.out.printf("First  Goods cost:  %.2f quantity - %.2f total - %.2f",perX, perN, (perX * perN));
        System.out.println("");
        System.out.printf("Discount of first  Goods:  %.2f total with discount- %.2f"
                , perD, ((perX * perN)*((100-perD)/100)));
        System.out.println("");
        System.out.printf("First  Goods cost:  %.2f quantity - %.2f total - %.2f",perY, perM, (perY * perM));
        System.out.println("");
        System.out.printf("Discount of first  Goods:  %.2f total with discount- %.2f"
                , perC, ((perY * perM)*((100-perC)/100)));
        System.out.println("");
        System.out.println("==================================================================");
    }
    public static double metodNumberCheck(String perLine, boolean PerLog) throws Exception {
        boolean perBool = true;
        Scanner sc = new Scanner(System.in);
        double perNum = 0;
        String perStr = "";
        while (perBool == true) {
            System.out.print(perLine);
            try {
                perStr = sc.nextLine();
                perNum = Integer.parseInt(perStr.trim());
                if (((!PerLog) & (perNum > 0) & (perNum < 100)) || ((perNum > 0) & (PerLog))) {
                    System.out.println("------------------------------------------------------------------");
                    return perNum;
                } else {
                    System.out.println("The number cannot be: [" + perStr + "] is not correct");
                }
            } catch (NumberFormatException nfe) {
                System.out.println("The number: [" + perStr + "] is not correct");
                System.out.print(String.format("\033[%dA", 1)); // Move cursor up by 1 line
                System.out.print("\033[2K"); // Erase the line            }
            }
        }
        return 0;
    }
}