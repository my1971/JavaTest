import java.util.Scanner;

// код с проверкой на ошибочный ввод числа (текст, ноль недопустимы)
public class Aufgabe4 {
    public static void main(String[] args) throws Exception  {
/* Написать программу, определяющую является ли год високосным. Для того, чтобы быть високосным год
   должен: делится без остатка на 4 и либо не должен делится без остатка на 100 либо если он делится
   на 100, то он должен делится также на 400. */

        System.out.println("является ли год високосным");
        int perYear = metodNumberCheck("Input the year: ");
        if (perYear %100==0 && perYear %400 ==0 ){
             System.out.println("Это високосный год. Количество дней в году: 366");
        } else if (perYear % 4 == 0 && perYear % 100 > 0){
             System.out.println("Это високосный год. Количество дней в году: 366");
        } else if (perYear % 100 == 0){
             System.out.println("Это не високосный год. Количество дней в году: 365");
        } else {
             System.out.println("то не високосный год. Количество дней в году: 365");
        };
    }
    public static int metodNumberCheck(String perLine) throws Exception{
        boolean perBool = true;
        Scanner sc = new Scanner(System.in);
        int perNum = 0;
        String perStr = "";
        while (perBool == true){
            System.out.print(perLine);
            try {
                perStr = sc.nextLine();
                perNum = Integer.parseInt(perStr.trim());
                if (perNum > 0){
                    System.out.println("-------------------------------------------");
                    return perNum;
                } else {
                    System.out.println("The number cannot be: [" + perStr + "] is not correct");
                }
            } catch (NumberFormatException nfe){
                System.out.println("The number: [" + perStr + "] is not correct");
            }
        }
        return 0;
    }
}

