import java.util.Scanner;

// код с проверкой на ошибочный ввод числа (текст, ноль недопустимы)
public class Aufgabe2 {
    public static void main(String[] args) throws Exception {
        // Дополнить задачу о сумме углов треугольника контролем, что вводимые углы не больше 90 градусов.
        System.out.println("Exercise about sum corners of a triangle");
        System.out.println("===========================================");
        int perCorner1 = metodNumberCheck("Input the first  corner of the triangle: ", 0);
        int perCorner2 = metodNumberCheck("Input the second corner of the triangle: ", perCorner1);
        char perChar = 186;
        System.out.println("The first  corner of the triangle: " + perCorner1 + perChar);
        System.out.println("The second  corner of the triangle: " + perCorner2 + perChar);
        System.out.println("The third  corner of the triangle: " + (180 - (perCorner1 + perCorner2)) + perChar);
        System.out.println("===========================================");
    }
    public static int metodNumberCheck(String perLine, int per1) throws Exception {
        boolean perBool = true;
        Scanner sc = new Scanner(System.in);
        int perNum = 0;
        String perStr = "";
        while (perBool == true) {
            System.out.print(perLine);
            try {
                perStr = sc.nextLine();
                perNum = Integer.parseInt(perStr.trim());
                if (((perNum > 0) & (perNum <= 90) & (per1 == 0)) || ((perNum > 0)
                        & (perNum < 90) & (per1 > 0)) || ((perNum == 90) & (per1 < 90))) {
                    System.out.println("-------------------------------------------");
                    return perNum;
                } else {
                    System.out.println("The number cannot be: [" + perStr + "] is not correct");
                }
            } catch (NumberFormatException nfe) {
                System.out.println("The number: [" + perStr + "] is not correct");
                System.out.print(String.format("\033[%dA", 1)); // Move cursor up by 1 line
                System.out.print("\033[2K"); // Erase the line            }
            }
        }
        return 0;
    }
}